const { createApp } = Vue;
const API_BASE_URL = 'http://127.0.0.1:5000/api';

// 標準化姓名函數
function normalizeName(name) {
 if (!name) return name;
 
 const nameStr = String(name).trim();
 
 // 將 郭任? 改為 郭任群
 if (nameStr.startsWith('郭任') && nameStr.length === 3) {
   // 如果第三個字不是群，就改為群
   if (nameStr[2] !== '群') {
     console.log(`姓名修正: '${nameStr}' -> '郭任群'`);
     return '郭任群';
   }
 }
 
 return nameStr;
}

createApp({
 data() {
   return {
     selectedItems: [],
     toast: { show: false, message: '', type: 'success' }
   };
 },
 
 async mounted() {
   await this.loadSelectedItems();
 },
 
 methods: {
   goBack() {
     window.history.back();
   },
   
   async loadSelectedItems() {
     const selectedItemsJson = localStorage.getItem('selectedItems');
     if (selectedItemsJson) {
       const items = JSON.parse(selectedItemsJson);
       
       // 批量查詢所有需要的 PO No.
       const poNumbers = items.map(item => item.poNo).filter(po => po);
       const userAndEprData = await this.fetchUserAndEprData(poNumbers);
       
       this.selectedItems = items.map((item, index) => {
         const poNo = item.poNo;
         const userData = userAndEprData[poNo] || { user: '查無此資訊', eprNo: '查無此資訊' };
         
         // 根據條件設定狀態
         const processedItem = {
           ...item,
           // 從後台資料設定 User 和 ePR No.
           user: userData.user,
           eprNo: userData.eprNo,
           // 修正取件者姓名
           pickupPerson: normalizeName(item.pickupPerson),
           totalQuantity: item.totalQuantity || item.quantity || '',
           remarks: item.remarks || '設備修改請, 請 User 提供照片結案',
           // 預設狀態
           materialStatus: 'pending',
           receivedStatus: 'pending', 
           photoStatus: 'pending'
         };
         
         // 檢查取件者欄位來決定領料狀態（使用修正後的姓名）
         const pickupPerson = processedItem.pickupPerson || '';
         
         // 檢查是否包含 "K7" 或 "智能櫃" 或符合 "D(任意字母)-1(數字)" 格式
         if (this.shouldSetMaterialStatus(pickupPerson)) {
           processedItem.materialStatus = 'completed'; // 未領料打V
         } else {
           // 檢查收料日期是否有正常數值來決定已領料狀態
           if (this.hasValidIssueDate(item.issueDate)) {
             processedItem.receivedStatus = 'completed'; // 已領料打V
           }
         }
         
         return processedItem;
       });
     }
   },
   
   async fetchUserAndEprData(poNumbers) {
     try {
       console.log('發送查詢請求，PO Numbers:', poNumbers);
       
       // 呼叫後台API來查詢 User 和 ePR No.
       const response = await fetch(`${API_BASE_URL}/get-user-epr-data`, {
         method: 'POST',
         headers: {
           'Content-Type': 'application/json'
         },
         body: JSON.stringify({ poNumbers: poNumbers })
       });
       
       if (!response.ok) {
         throw new Error('無法取得用戶和ePR資料');
       }
       
       const result = await response.json();
       console.log('後台返回的資料:', result);
       
       return result;
       
     } catch (error) {
       console.error('查詢用戶和ePR資料時發生錯誤:', error);
       // 如果API失敗，回傳預設值
       const fallbackData = {};
       poNumbers.forEach(poNo => {
         fallbackData[poNo] = { user: '查無此資訊', eprNo: '查無此資訊' };
       });
       return fallbackData;
     }
   },
   
   shouldSetMaterialStatus(pickupPerson) {
     if (!pickupPerson || pickupPerson === '-') return false;
     
     // 檢查是否包含 "K7" 或 "智能櫃"
     if (pickupPerson.includes('K7') || pickupPerson.includes('智能櫃')) {
       return true;
     }
     
     // 檢查是否符合 "D(任意英文字母)-(數字)" 格式
     const pattern = /D[A-Za-z]-\d+/;
     if (pattern.test(pickupPerson)) {
       return true;
     }
     
     return false;
   },
   
   hasValidIssueDate(issueDate) {
     if (!issueDate || issueDate === '-' || issueDate === '') return false;
     
     // 檢查是否為有效的日期格式
     const datePattern = /^\d{4}[-/]\d{1,2}[-/]\d{1,2}$|^\d{1,2}[-/]\d{1,2}[-/]\d{4}$/;
     
     if (datePattern.test(issueDate)) {
       const date = new Date(issueDate);
       return !isNaN(date.getTime()) && date.getFullYear() > 1900;
     }
     
     return false;
   },
   
   formatPoItem(poItem) {
     if (!poItem) return '-';
     return parseInt(poItem, 10).toString();
   },
   
   toggleStatus(item, statusType) {
     if (statusType === 'materialStatus') {
       item.materialStatus = item.materialStatus === 'completed' ? 'pending' : 'completed';
     } else if (statusType === 'receivedStatus') {
       item.receivedStatus = item.receivedStatus === 'completed' ? 'pending' : 'completed';
     } else if (statusType === 'photoStatus') {
       item.photoStatus = item.photoStatus === 'provided' ? 'pending' : 'provided';
     }
   },
   
   
   async startSending() {
     try {
       // 準備要發送的資料
       const dataToSend = {
         action: 'save_changes',
         timestamp: new Date().toISOString(),
         data: this.selectedItems
       };
       
       // 發送到後台
       const response = await fetch(`${API_BASE_URL}/save-mail`, {
         method: 'POST',
         headers: {
           'Content-Type': 'application/json'
         },
         body: JSON.stringify(dataToSend)
       });
       
       if (!response.ok) {
         throw new Error('保存失敗');
       }
       
       const result = await response.json();
       console.log('後台回應:', result);
       
       // 保存到本地
       localStorage.setItem('selectedItems', JSON.stringify(this.selectedItems));
       
       this.showToast('修改已保存到後台', 'success');
       
     } catch (error) {
       console.error('保存到後台失敗:', error);
       // 仍然保存到本地
       localStorage.setItem('selectedItems', JSON.stringify(this.selectedItems));
       this.showToast('後台保存失敗，已保存到本地', 'error');
     }
   },
   
   showToast(message, type = 'success') {
     this.toast = { show: true, message, type };
     setTimeout(() => (this.toast.show = false), 3000);
   }
 }
}).mount('#app');