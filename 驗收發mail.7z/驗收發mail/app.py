from flask import Flask, request, jsonify
from flask_cors import CORS
from bs4 import BeautifulSoup
import re
import json
import traceback
import logging
import quopri
from urllib.parse import unquote
import pandas as pd
import os

# 設定 logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)  # 允許跨域請求

# CSV 檔案路徑（請根據實際路徑調整）
BUYER_DETAIL_CSV = 'Buyer_detail.csv'
PLANNED_PURCHASE_CSV = 'Planned_Purchase_Request_List.csv'

# 載入 CSV 資料
buyer_detail_df = None
planned_purchase_df = None

def load_csv_data():
    """載入 CSV 資料"""
    global buyer_detail_df, planned_purchase_df
    
    try:
        if os.path.exists(BUYER_DETAIL_CSV):
            # 處理包含逗號的資料，使用更嚴格的 CSV 解析
            buyer_detail_df = pd.read_csv(
                BUYER_DETAIL_CSV, 
                encoding='utf-8',
                quotechar='"',  # 處理引號包圍的欄位
                skipinitialspace=True,  # 跳過初始空白
                na_values=['', 'NaN', 'nan', 'NULL', 'null']  # 定義空值
            )
            logger.info(f"成功載入 {BUYER_DETAIL_CSV}, 共 {len(buyer_detail_df)} 筆資料")
            
            # 顯示欄位和前幾筆資料供檢查
            logger.info(f"Buyer_detail 欄位: {list(buyer_detail_df.columns)}")
            logger.info("Buyer_detail 前5筆完整資料:")
            for idx in range(min(5, len(buyer_detail_df))):
                row = buyer_detail_df.iloc[idx]
                logger.info(f"  第{idx+1}筆完整資料:")
                for col_idx, col_name in enumerate(buyer_detail_df.columns[:10]):  # 只顯示前10個欄位
                    logger.info(f"    欄位{col_idx}: {col_name} = {row.iloc[col_idx]}")
                logger.info("    ...")
            
            # 檢查可能的 PO No. 和 ePR No. 欄位
            logger.info("分析可能的 PO No. 和 ePR No. 欄位:")
            for idx, col in enumerate(buyer_detail_df.columns):
                sample_values = buyer_detail_df[col].dropna().head(3).tolist()
                logger.info(f"  欄位{idx} '{col}': {sample_values}")
            
        else:
            logger.warning(f"找不到檔案: {BUYER_DETAIL_CSV}")
            
        if os.path.exists(PLANNED_PURCHASE_CSV):
            planned_purchase_df = pd.read_csv(
                PLANNED_PURCHASE_CSV,
                encoding='utf-8',
                quotechar='"',
                skipinitialspace=True,
                na_values=['', 'NaN', 'nan', 'NULL', 'null']
            )
            logger.info(f"成功載入 {PLANNED_PURCHASE_CSV}, 共 {len(planned_purchase_df)} 筆資料")
            
            # 顯示欄位和前幾筆資料供檢查
            logger.info(f"Planned_Purchase 欄位: {list(planned_purchase_df.columns)}")
            logger.info("Planned_Purchase 前3筆資料:")
            for idx in range(min(3, len(planned_purchase_df))):
                row = planned_purchase_df.iloc[idx]
                logger.info(f"  第{idx+1}筆 - PO: {row.get('PO No.')}, ePR: {row.get('ePR No.')}, 需求者: {row.get('需求者')}")
                
        else:
            logger.warning(f"找不到檔案: {PLANNED_PURCHASE_CSV}")
            
    except Exception as e:
        logger.error(f"載入 CSV 檔案時發生錯誤: {str(e)}")
        logger.error(traceback.format_exc())

def normalize_name(name):
    """標準化姓名，處理特殊字符問題"""
    if not name or pd.isna(name):
        return name
    
    name_str = str(name).strip()
    
    # 將 郭任? 改為 郭任群
    if name_str.startswith('郭任') and len(name_str) == 3:
        # 如果第三個字是問號或其他特殊字符，統一改為群
        if name_str[2] not in ['群']:  # 如果不是群字，就改為群
            logger.info(f"姓名修正: '{name_str}' -> '郭任群'")
            return '郭任群'
    
    return name_str

def query_user_by_po_no(po_no):
    """根據 PO No. 查詢需求者"""
    try:
        if planned_purchase_df is None:
            logger.warning("planned_purchase_df 未載入")
            return None
            
        # 轉換 po_no 為字串進行比較
        po_no_str = str(po_no).strip()
        logger.info(f"查詢需求者，PO No: '{po_no_str}'")
        
        # 檢查 CSV 中的欄位名稱
        logger.info(f"Planned_Purchase CSV 欄位: {list(planned_purchase_df.columns)}")
        
        # 嘗試不同的欄位名稱匹配
        po_column = None
        user_column = None
        
        for col in planned_purchase_df.columns:
            if 'PO' in col and 'No' in col:
                po_column = col
            if '需求者' in col:
                user_column = col
        
        if po_column is None or user_column is None:
            logger.warning(f"找不到對應欄位 - PO欄位: {po_column}, 需求者欄位: {user_column}")
            return None
        
        # 清理和轉換 PO No. 欄位
        planned_purchase_df[po_column] = planned_purchase_df[po_column].astype(str).str.strip()
        
        # 查詢資料
        result = planned_purchase_df[planned_purchase_df[po_column] == po_no_str]
        
        logger.info(f"查詢結果數量: {len(result)}")
        
        if not result.empty:
            user = result.iloc[0][user_column]
            # 標準化姓名
            normalized_user = normalize_name(user)
            logger.info(f"找到 PO {po_no} 的需求者: {user} -> {normalized_user}")
            return normalized_user
        else:
            # 如果精確匹配失敗，嘗試部分匹配
            logger.info(f"精確匹配失敗，嘗試部分匹配...")
            partial_result = planned_purchase_df[planned_purchase_df[po_column].str.contains(po_no_str, na=False)]
            if not partial_result.empty:
                user = partial_result.iloc[0][user_column]
                normalized_user = normalize_name(user)
                logger.info(f"部分匹配找到 PO {po_no} 的需求者: {user} -> {normalized_user}")
                return normalized_user
            
            # 顯示前幾筆資料供除錯
            logger.info(f"前5筆 PO No. 資料: {planned_purchase_df[po_column].head().tolist()}")
            
    except Exception as e:
        logger.error(f"查詢需求者時發生錯誤 (PO: {po_no}): {str(e)}")
        logger.error(traceback.format_exc())
    
    return None

def query_epr_no_by_po_no(po_no):
    """根據 PO No. 查詢 ePR No. - 主要從 Buyer_detail.csv 查詢"""
    try:
        po_no_str = str(po_no).strip()
        logger.info(f"查詢 ePR No.，PO No: '{po_no_str}'")
        
        # 主要從 Buyer_detail.csv 查詢（這裡有完整的資料）
        if buyer_detail_df is not None:
            logger.info(f"從 Buyer_detail 查詢 (共 {len(buyer_detail_df)} 筆資料)")
            
            po_column = 'PO No.'
            epr_column = 'ePR No.'
            
            if po_column in buyer_detail_df.columns and epr_column in buyer_detail_df.columns:
                # 處理浮點數格式的 PO No.
                # 將查詢的 PO No. 轉換為數字進行比較
                try:
                    po_no_numeric = float(po_no_str)
                    logger.info(f"將 PO No. 轉換為數字: {po_no_numeric}")
                    
                    # 查找匹配的記錄 - 使用數字比較
                    result = buyer_detail_df[
                        (buyer_detail_df[po_column].notna()) &  # 不是空值
                        (buyer_detail_df[po_column] == po_no_numeric)  # 數字匹配
                    ]
                    
                    logger.info(f"數字匹配查詢到 {len(result)} 筆結果")
                    
                    if not result.empty:
                        epr_no = result.iloc[0][epr_column]
                        logger.info(f"找到的 ePR No. 原始值: '{epr_no}', 類型: {type(epr_no)}")
                        
                        if pd.notna(epr_no) and str(epr_no).strip() not in ['', 'nan', 'NaN']:
                            try:
                                # 轉換 ePR No. 為整數字串
                                if isinstance(epr_no, (int, float)):
                                    epr_result = str(int(epr_no))
                                else:
                                    epr_result = str(epr_no).strip()
                                
                                logger.info(f"✓ 在 Buyer_detail 找到 PO {po_no} 的 ePR No.: {epr_result}")
                                return epr_result
                            except (ValueError, TypeError) as e:
                                logger.error(f"ePR No. 轉換失敗: {e}")
                                epr_result = str(epr_no).strip()
                                logger.info(f"✓ 使用原始字串格式 ePR No.: {epr_result}")
                                return epr_result
                        else:
                            logger.warning(f"Buyer_detail 中找到記錄但 ePR No. 為空: '{epr_no}'")
                    else:
                        logger.warning(f"在 Buyer_detail 中未找到 PO {po_no}")
                        # 顯示可用的 PO No. 供對比
                        valid_pos = buyer_detail_df[buyer_detail_df[po_column].notna()][po_column].head(10).tolist()
                        logger.info(f"Buyer_detail 中的有效 PO No. 樣本: {valid_pos}")
                        
                except ValueError as e:
                    logger.error(f"PO No. 轉換為數字失敗: {e}")
                    return None
            else:
                logger.error(f"Buyer_detail 找不到必要欄位 - PO欄位: {po_column}, ePR欄位: {epr_column}")
        else:
            logger.error("Buyer_detail.csv 未載入！")
        
        # 如果 Buyer_detail 找不到，才嘗試 Planned_Purchase（備用）
        logger.info("Buyer_detail 查詢失敗，嘗試 Planned_Purchase 作為備用")
        if planned_purchase_df is not None:
            logger.info(f"從 Planned_Purchase 查詢 (共 {len(planned_purchase_df)} 筆資料)")
            
            po_column = 'PO No.'
            epr_column = 'ePR No.'
            
            if po_column in planned_purchase_df.columns and epr_column in planned_purchase_df.columns:
                try:
                    po_no_numeric = float(po_no_str)
                    result = planned_purchase_df[
                        (planned_purchase_df[po_column].notna()) &
                        (planned_purchase_df[po_column] == po_no_numeric)
                    ]
                    
                    if not result.empty:
                        epr_no = result.iloc[0][epr_column]
                        if pd.notna(epr_no) and str(epr_no).strip() not in ['', 'nan', 'NaN']:
                            epr_result = str(int(float(epr_no))) if isinstance(epr_no, (int, float)) else str(epr_no).strip()
                            logger.info(f"✓ 在 Planned_Purchase 找到 PO {po_no} 的 ePR No.: {epr_result}")
                            return epr_result
                except ValueError:
                    pass
                
    except Exception as e:
        logger.error(f"查詢 ePR No. 時發生錯誤 (PO: {po_no}): {str(e)}")
        logger.error(traceback.format_exc())
    
    logger.error(f"✗ 最終未找到 PO {po_no} 的 ePR No.")
    return None

class MHTMLParser:
    """MHTML 文件解析器"""
    
    def __init__(self):
        pass
    
    def parse_mhtml_file(self, file_content):
        """解析 MHTML 文件並提取表格資料"""
        try:
            logger.info("開始解析 MHTML 文件")
            
            # 提取 HTML 內容
            html_content = self.extract_html_from_mhtml(file_content)
            
            # 使用 BeautifulSoup 解析 HTML
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # 尋找資料表格
            table = self.find_data_table(soup)
            
            if not table:
                raise Exception("找不到資料表格")
            
            # 解析表格資料
            parsed_data = self.extract_table_data(table)
            
            logger.info(f"成功解析 {len(parsed_data)} 筆資料")
            return parsed_data
            
        except Exception as e:
            logger.error(f"解析 MHTML 文件時發生錯誤: {str(e)}")
            raise e
    
    def extract_html_from_mhtml(self, mhtml_content):
        """從 MHTML 內容中提取 HTML 部分"""
        try:
            # MHTML 文件包含多個部分，我們需要找到 HTML 部分
            # 通常 HTML 內容在 Content-Type: text/html 之後
            
            # 尋找 HTML 內容的開始位置
            html_start = mhtml_content.find('<!DOCTYPE html>')
            if html_start == -1:
                html_start = mhtml_content.find('<html')
            
            if html_start == -1:
                raise Exception("找不到 HTML 內容")
            
            # 尋找 HTML 內容的結束位置
            html_end = mhtml_content.find('</html>', html_start)
            if html_end != -1:
                html_end += 7  # 包含 </html>
                html_content = mhtml_content[html_start:html_end]
            else:
                # 如果找不到結束標籤，取從開始到下一個邊界
                boundary_pattern = r'------MultipartBoundary--[a-zA-Z0-9]+----'
                match = re.search(boundary_pattern, mhtml_content[html_start:])
                if match:
                    html_content = mhtml_content[html_start:html_start + match.start()]
                else:
                    html_content = mhtml_content[html_start:]
            
            return html_content
            
        except Exception as e:
            logger.error(f"提取 HTML 內容時發生錯誤: {str(e)}")
            raise e
    
    def find_data_table(self, soup):
        """尋找包含資料的表格"""
        # 嘗試多種選擇器來找到表格
        selectors = [
            'table[id*="GridView1"]',
            'table.table-bordered',
            'table[cellspacing="0"]',
            'table[rules="all"]',
            'table[border="1"]'
        ]
        
        for selector in selectors:
            table = soup.select_one(selector)
            if table:
                logger.info(f"使用選擇器 '{selector}' 找到表格")
                return table
        
        # 如果都找不到，嘗試找所有表格並選擇最大的
        tables = soup.find_all('table')
        if tables:
            # 選擇行數最多的表格
            largest_table = max(tables, key=lambda t: len(t.find_all('tr')))
            logger.info(f"選擇最大的表格，共有 {len(largest_table.find_all('tr'))} 行")
            return largest_table
        
        return None
    
    def extract_table_data(self, table):
        """提取表格資料"""
        parsed_data = []
        
        # 找到所有資料行（跳過表頭）
        rows = table.find_all('tr')
        
        # 分析表頭來確定欄位位置
        header_row = None
        for row in rows:
            if '收料號碼' in row.get_text() or 'RT No' in row.get_text():
                header_row = row
                break
        
        # 處理資料行
        for i, row in enumerate(rows):
            try:
                cells = row.find_all(['td', 'th'])
                
                # 跳過表頭行和空行
                if len(cells) < 10:
                    continue
                
                # 檢查是否為資料行（包含 checkbox 或資料）
                if not self.is_data_row(cells):
                    continue
                
                # 提取資料
                data = self.extract_row_data(cells, i)
                
                if data and data.get('rtNo'):  # 確保有必要的資料
                    parsed_data.append(data)
                    
            except Exception as e:
                logger.warning(f"解析第 {i} 行時發生錯誤: {str(e)}")
                continue
        
        return parsed_data
    
    def is_data_row(self, cells):
        """判斷是否為資料行"""
        # 檢查第一個 cell 是否包含 checkbox
        first_cell = cells[0] if cells else None
        if first_cell and first_cell.find('input', {'type': 'checkbox'}):
            return True
        
        # 或者檢查是否包含實際資料（RT No 格式）
        if len(cells) > 1:
            second_cell_text = cells[1].get_text(strip=True)
            if re.match(r'^\d{10}$', second_cell_text):  # RT No 格式
                return True
        
        return False
    
    def extract_row_data(self, cells, row_index):
        """提取單行資料"""
        try:
            # 根據表格結構提取資料
            data = {
                'id': row_index,
                'rtNo': self.extract_cell_text(cells[1]),
                'itemNo': self.extract_cell_text(cells[2]),
                'poNo': self.extract_cell_text(cells[3]),
                'poItem': self.extract_cell_text(cells[4]),
                'assetClass': self.extract_cell_text(cells[6]),
                'description': self.extract_cell_text(cells[7]),
                'quantity': self.extract_cell_text(cells[8]),
                'issueDate': self.extract_cell_text(cells[9]),
                'pickupPerson': self.extract_cell_text(cells[10]),
                'extendDueDate': self.extract_cell_text(cells[11]) if len(cells) > 11 else '',
                'status': 'pending'
            }
            
            # 解析科目指派（第5欄）
            item_assign_cell = cells[5]
            spans = item_assign_cell.find_all('span')
            if len(spans) >= 2:
                assign_code = spans[0].get_text(strip=True)
                assign_name = spans[1].get_text(strip=True).lstrip()
                
                # 解碼科目指派名稱
                assign_name = self.decode_quoted_printable(assign_name)
                
                data['itemAssign'] = assign_code
                data['itemAssignName'] = assign_name
            else:
                cell_text = item_assign_cell.get_text(strip=True)
                # 解碼整個儲存格內容
                cell_text = self.decode_quoted_printable(cell_text)
                
                if '.' in cell_text:
                    parts = cell_text.split('.', 1)
                    data['itemAssign'] = parts[0].strip()
                    data['itemAssignName'] = parts[1].strip()
                else:
                    data['itemAssign'] = cell_text
                    data['itemAssignName'] = ''
            
            return data
            
        except Exception as e:
            logger.error(f"提取行資料時發生錯誤: {str(e)}")
            return None
    
    def extract_cell_text(self, cell):
        """提取儲存格文字內容並處理編碼問題"""
        if not cell:
            return ''
        
        # 優先從 span 中提取
        span = cell.find('span')
        if span:
            text = span.get_text(strip=True)
        else:
            # 否則直接提取文字
            text = cell.get_text(strip=True)
        
        # 處理 Quoted-Printable 編碼
        text = self.decode_quoted_printable(text)
        
        return text
    
    def decode_quoted_printable(self, text):
        """解碼 Quoted-Printable 編碼的文字"""
        if not text:
            return text
        
        try:
            # 檢查是否包含 Quoted-Printable 編碼標記
            if '=' in text and re.search(r'=[0-9A-Fa-f]{2}', text):
                # 先處理 HTML 實體編碼
                text = text.replace('&amp;', '&')
                
                # 解碼 Quoted-Printable
                decoded_bytes = quopri.decodestring(text.encode('ascii'))
                
                # 嘗試多種編碼方式解碼
                for encoding in ['utf-8', 'big5', 'gb2312', 'cp950']:
                    try:
                        decoded_text = decoded_bytes.decode(encoding)
                        logger.info(f"成功使用 {encoding} 解碼: '{text}' -> '{decoded_text}'")
                        return decoded_text
                    except UnicodeDecodeError:
                        continue
                
                # 如果所有編碼都失敗，返回原文
                logger.warning(f"無法解碼文字: {text}")
                return text
            
            return text
            
        except Exception as e:
            logger.error(f"解碼文字時發生錯誤 '{text}': {str(e)}")
            return text

@app.route('/api/parse-mhtml', methods=['POST'])
def parse_mhtml():
    """處理 MHTML 文件上傳和解析"""
    try:
        # 檢查是否有檔案
        if 'file' not in request.files:
            return jsonify({'error': '沒有上傳檔案'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': '沒有選擇檔案'}), 400
        
        # 檢查檔案格式
        if not file.filename.lower().endswith(('.mhtml', '.mht')):
            return jsonify({'error': '檔案格式不正確，請上傳 MHTML 格式檔案'}), 400
        
        # 讀取檔案內容
        file_content = file.read().decode('utf-8', errors='ignore')
        
        logger.info(f"收到檔案: {file.filename}, 大小: {len(file_content)} 字元")
        
        # 創建解析器並解析檔案
        parser = MHTMLParser()
        parsed_data = parser.parse_mhtml_file(file_content)
        
        # 輸出解析結果到後台日誌
        logger.info("=" * 50)
        logger.info("解析結果:")
        logger.info(f"檔案名稱: {file.filename}")
        logger.info(f"解析筆數: {len(parsed_data)}")
        logger.info("-" * 30)
        
        for i, item in enumerate(parsed_data, 1):
            logger.info(f"第 {i} 筆:")
            logger.info(f"  RT No: {item.get('rtNo')}")
            logger.info(f"  項次: {item.get('itemNo')}")
            logger.info(f"  PO No: {item.get('poNo')}")
            logger.info(f"  科目指派: {item.get('itemAssign')} - {item.get('itemAssignName')}")
            logger.info(f"  品名: {item.get('description')}")
            logger.info(f"  數量: {item.get('quantity')}")
            logger.info(f"  取件者: {item.get('pickupPerson')}")
            logger.info("-" * 30)
        
        logger.info("=" * 50)
        
        # 返回解析結果
        return jsonify({
            'success': True,
            'filename': file.filename,
            'count': len(parsed_data),
            'data': parsed_data
        })
        
    except Exception as e:
        error_msg = str(e)
        logger.error(f"處理請求時發生錯誤: {error_msg}")
        logger.error(traceback.format_exc())
        return jsonify({'error': error_msg}), 500

@app.route('/api/get-user-epr-data', methods=['POST'])
def get_user_epr_data():
    """根據PO號碼查詢對應的User和ePR No."""
    try:
        data = request.get_json()
        po_numbers = data.get('poNumbers', [])
        
        logger.info(f"收到查詢請求，PO 號碼: {po_numbers}")
        logger.info(f"buyer_detail_df 狀態: {'已載入' if buyer_detail_df is not None else '未載入'}")
        logger.info(f"planned_purchase_df 狀態: {'已載入' if planned_purchase_df is not None else '未載入'}")
        
        if buyer_detail_df is not None:
            logger.info(f"Buyer_detail 資料筆數: {len(buyer_detail_df)}")
            logger.info(f"Buyer_detail 欄位: {list(buyer_detail_df.columns)}")
            logger.info(f"Buyer_detail 前3筆 PO No.: {buyer_detail_df.iloc[:3]['PO No.'].tolist() if 'PO No.' in buyer_detail_df.columns else '找不到PO No.欄位'}")
        
        if planned_purchase_df is not None:
            logger.info(f"Planned_purchase 資料筆數: {len(planned_purchase_df)}")
            logger.info(f"Planned_purchase 欄位: {list(planned_purchase_df.columns)}")
            logger.info(f"Planned_purchase 前3筆 PO No.: {planned_purchase_df.iloc[:3]['PO No.'].tolist() if 'PO No.' in planned_purchase_df.columns else '找不到PO No.欄位'}")
        
        result = {}
        
        for po_no in po_numbers:
            logger.info(f"開始處理 PO: {po_no}")
            
            # 查詢需求者和 ePR No.
            user = query_user_by_po_no(po_no)
            epr_no = query_epr_no_by_po_no(po_no)
            
            result[str(po_no)] = {
                'user': user if user else '查無此資訊',
                'eprNo': epr_no if epr_no else '查無此資訊'
            }
            
            logger.info(f"PO {po_no} 最終結果: User={result[str(po_no)]['user']}, ePR={result[str(po_no)]['eprNo']}")
        
        logger.info(f"回傳完整結果: {result}")
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"查詢User和ePR資料時發生錯誤: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({'error': str(e)}), 500

@app.route('/api/save-mail-changes', methods=['POST', 'OPTIONS'])  # 改為連字號
def save_mail_changes():
    if request.method == 'OPTIONS':
        response = jsonify({'status': 'ok'})
        response.headers.add('Access-Control-Allow-Origin', '*')
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type')
        response.headers.add('Access-Control-Allow-Methods', 'POST, OPTIONS')
        return response
    
    try:
        data = request.get_json()
        print(f"收到郵件修改資料: {json.dumps(data, indent=2, ensure_ascii=False)}")
        
        # 在這裡處理保存邏輯
        logger.info(f"保存 {len(data.get('data', []))} 筆修改資料")
        
        return jsonify({
            "status": "success",
            "message": "資料已保存",
            "timestamp": data.get('timestamp'),
            "saved_items_count": len(data.get('data', []))
        })
        
    except Exception as e:
        logger.error(f"保存失敗: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@app.route('/api/send-mail', methods=['POST', 'OPTIONS'])  # 新增此路由
def send_mail():
    if request.method == 'OPTIONS':
        response = jsonify({'status': 'ok'})
        response.headers.add('Access-Control-Allow-Origin', '*')
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type')
        response.headers.add('Access-Control-Allow-Methods', 'POST, OPTIONS')
        return response
    
    try:
        data = request.get_json()
        print(f"收到郵件發送請求: {json.dumps(data, indent=2, ensure_ascii=False)}")
        
        items = data.get('items', [])
        logger.info(f"準備發送 {len(items)} 個項目的郵件")
        
        # 在這裡處理郵件發送邏輯
        for item in items:
            logger.info(f"項目: PO={item.get('poNo')}, User={item.get('user')}, Status=未領料:{item.get('materialStatus')}, 已領料:{item.get('receivedStatus')}, 照片:{item.get('photoStatus')}")
        
        return jsonify({
            'status': 'success',
            'message': '郵件發送成功',
            'sent_count': len(items),
            'timestamp': data.get('timestamp')
        })
        
    except Exception as e:
        logger.error(f"郵件發送失敗: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500
    
    
@app.route('/api/health', methods=['GET'])
def health_check():
    """健康檢查端點"""
    return jsonify({'status': 'ok', 'message': 'MHTML 解析服務運行正常'})

if __name__ == '__main__':
    logger.info("啟動 MHTML 解析服務...")
    
    # 載入 CSV 資料
    load_csv_data()
    
    app.run(debug=True, host='0.0.0.0', port=5000)