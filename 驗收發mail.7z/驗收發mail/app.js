const { createApp } = Vue;
const API_BASE_URL = 'http://localhost:5000/api';

// 等待所有腳本載入完成
function waitForSwal() {
  return new Promise((resolve) => {
    const checkSwal = () => {
      if (typeof Swal !== 'undefined') {
        console.log('✅ SweetAlert2 已載入');
        resolve(true);
      } else {
        console.log('⏳ 等待 SweetAlert2 載入...');
        setTimeout(checkSwal, 100);
      }
    };
    checkSwal();
  });
}

// 安全的 SweetAlert2 包裝函數
async function showAlert(options) {
  await waitForSwal();
  
  if (typeof Swal !== 'undefined') {
    console.log('🎯 顯示 SweetAlert2 彈窗');
    return await Swal.fire(options);
  } else {
    console.error('❌ SweetAlert2 載入失敗，使用備用方案');
    const message = options.text || options.html?.replace(/<[^>]*>/g, '') || options.title || '操作完成';
    alert(message);
    return { isConfirmed: true };
  }
}

// 等待 DOM 和所有腳本載入完成
document.addEventListener('DOMContentLoaded', async () => {
  await waitForSwal();
  
  createApp({
    data() {
      return {
        // 驗收資料
        acceptanceData: [],
        // 已上傳檔案
        uploadedFiles: [],
        // 處理狀態
        isProcessing: false,
        isCleaningUp: false,
        // 拖拽狀態
        isDragging: false,
        // Toast 通知
        toast: { show: false, message: '', type: 'success' }
      }
    },
    
    computed: {
      hasData() {
        return this.acceptanceData.length > 0;
      },
      
      // 待驗收數量
      getPendingCount() {
        return this.acceptanceData.filter(item => item.status === 'pending').length;
      },
      
      // 已驗收數量
      getApprovedCount() {
        return this.acceptanceData.filter(item => item.status === 'approved').length;
      },
      
      // 已發信數量
      getSentCount() {
        return this.acceptanceData.filter(item => item.status === 'sent').length;
      },

        isAllSelected() {
            return this.acceptanceData.length > 0 && this.acceptanceData.every(item => item.selected);
        },
    },
    
    methods: {
      goBack() {
        // 返回上一頁的邏輯
        window.history.back();
      },
      
      handleDrop(e) {
        e.preventDefault();
        this.isDragging = false;
        this.handleFiles(e.dataTransfer.files);
      },
      
      handleFileSelect(e) {
        this.handleFiles(e.target.files);
      },
      
      async handleFiles(fileList) {
        const files = Array.from(fileList);
        if (files.length === 0) return;
        
        // 檢查檔案格式
        const invalidFiles = files.filter(file => 
          !file.name.toLowerCase().match(/\.(mhtml|mht)$/)
        );
        
        if (invalidFiles.length > 0) {
          this.showToast(`以下檔案格式不正確: ${invalidFiles.map(f => f.name).join(', ')}`, 'error');
          return;
        }
        
        this.isProcessing = true;
        
        try {
          const allParsedData = [];
          const newUploadedFiles = [];
          
          for (const file of files) {
            // 發送到後台解析
            const result = await this.sendFileToBackend(file);
            
            if (result.success && result.data.length > 0) {
              allParsedData.push(...result.data);
              
              newUploadedFiles.push({
                name: file.name,
                size: file.size,
                uploadTime: new Date().toLocaleString('zh-TW'),
                recordCount: result.data.length
              });
            }
          }
          
          this.uploadedFiles.push(...newUploadedFiles);
          this.acceptanceData = allParsedData;
          
          if (allParsedData.length > 0) {
            this.showToast(`成功解析 ${allParsedData.length} 筆驗收資料`, 'success');
          } else {
            this.showToast('沒有解析到有效資料', 'error');
          }
          
        } catch (error) {
          console.error('檔案處理錯誤:', error);
          this.showToast(`處理失敗: ${error.message}`, 'error');
        } finally {
          this.isProcessing = false;
          // 清空檔案輸入
          if (this.$refs.fileInput) {
            this.$refs.fileInput.value = '';
          }
        }
      },
      
      // 發送檔案到後台
      async sendFileToBackend(file) {
        const formData = new FormData();
        formData.append('file', file);
        
        try {
          const response = await fetch(`${API_BASE_URL}/parse-mhtml`, {
            method: 'POST',
            body: formData
          });
          
          if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || '後台解析失敗');
          }
          
          return await response.json();
          
        } catch (error) {
          console.error('後台解析錯誤:', error);
          throw error;
        }
      },
      
      // 狀態管理方法
      approveItem(item) {
        item.status = 'approved';
        this.showToast(`${item.rtNo} 已核准`, 'success');
      },
      
      rejectItem(item) {
        item.status = 'rejected';
        this.showToast(`${item.rtNo} 已拒絕`, 'error');
      },
      
      async sendSingleNotification(item) {
        try {
          // 模擬發信 API 呼叫
          await new Promise(resolve => setTimeout(resolve, 1000));
          item.status = 'sent';
          this.showToast(`${item.rtNo} 通知已發送`, 'success');
        } catch (error) {
          this.showToast('發信失敗', 'error');
        }
      },
      
    selectAll(e) {
        const isChecked = e.target.checked;
        this.acceptanceData.forEach(item => {
        item.selected = isChecked;
        });
    },
      
    selectAllItems() {
        // 檢查當前是否全部選中
        const allSelected = this.acceptanceData.every(item => item.selected);
        const newSelectState = !allSelected;
        
        // 更新所有項目的選中狀態
        this.acceptanceData.forEach(item => {
        item.selected = newSelectState;
        });
        
        // 同步更新表頭的 checkbox 狀態
        this.$nextTick(() => {
        const headerCheckbox = document.querySelector('table thead input[type="checkbox"]');
        if (headerCheckbox) {
            headerCheckbox.checked = newSelectState;
        }
        });
        
        const selectedCount = this.acceptanceData.filter(item => item.selected).length;
        if (selectedCount > 0) {
        this.showToast(`已選擇 ${selectedCount} 個項目`, 'success');
        } else {
        this.showToast('已取消所有選擇', 'info');
        }
    },
    
  // 添加一個計算屬性來檢查是否全選（可選，用於更好的狀態管理）
  // ... 其他方法保持不變 ...

      async sendMail() {
        const selectedItems = this.acceptanceData.filter(item => item.selected);
        if (selectedItems.length === 0) {
          this.showToast('請先選擇要發MAIL的項目', 'error');
          return;
        }
      // 將選中的項目保存到 localStorage，以便新頁面使用
        localStorage.setItem('selectedItems', JSON.stringify(selectedItems));
        
        // 跳轉到郵件發送頁面
        window.location.href = 'send_mail.html';
      },
      
      resetData() {
        this.acceptanceData = [];
        this.uploadedFiles = [];
        this.showToast('已重置，可重新上傳', 'info');
      },
      
      exportResults() {
        // 匯出邏輯
        this.showToast('功能開發中', 'info');
      },
      
      // 取得狀態文字
      getStatusText(status) {
        const statusMap = {
          'pending': '待驗收',
          'approved': '已核准',
          'rejected': '已拒絕',
          'sent': '已發信'
        };
        return statusMap[status] || '未知';
      },
      
      // 取得科目指派樣式
      getAssignTypeClass(assignType) {
        const classes = {
          'K': 'bg-orange-100 text-orange-800',
          'R': 'bg-green-100 text-green-800',
          'A': 'bg-blue-100 text-blue-800',
          'I': 'bg-purple-100 text-purple-800',
          'O': 'bg-yellow-100 text-yellow-800',
          'H': 'bg-red-100 text-red-800',
          'T': 'bg-indigo-100 text-indigo-800'
        };
        return classes[assignType] || 'bg-gray-100 text-gray-800';
      },
      
      // 格式化檔案大小
      formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
      },
      
      // Rule 說明功能
      async showRuleExplanation() {
        await showAlert({
          icon: 'info',
          title: 'Rule 說明 - 驗收發信管理系統',
          html: `
            <div style="text-align: left; max-height: 80vh; overflow-y: auto;">
                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; border-left: 4px solid #007bff; margin-bottom: 25px;">
                    <h4 style="color: #007bff; margin: 0 0 15px 0; font-size: 18px;">📋 系統功能說明</h4>
                    <p style="margin: 0; color: #495057; line-height: 1.8; font-size: 15px;">
                        本系統用於管理驗收清單的狀態，包括核准、拒絕和自動發信通知功能。
                        支援批量操作和詳細的狀態追蹤管理。
                    </p>
                </div>
                
                <div style="background: #e8f5e8; padding: 20px; border-radius: 8px; border-left: 4px solid #28a745; margin-bottom: 25px;">
                    <h4 style="color: #28a745; margin: 0 0 20px 0; font-size: 18px;">🔄 操作流程</h4>
                    <ol style="margin: 0; padding-left: 25px; color: #495057; line-height: 2; font-size: 15px;">
                        <li><strong>上傳檔案：</strong>拖曳或點擊上傳 MHTML 驗收清單</li>
                        <li><strong>解析資料：</strong>系統自動解析表格內容</li>
                        <li><strong>狀態管理：</strong>逐一核准或拒絕驗收項目</li>
                        <li><strong>批量操作：</strong>可選擇多個項目進行批量處理</li>
                        <li><strong>自動發信：</strong>核准後可發送通知給相關人員</li>
                    </ol>
                </div>
                
                <!-- 操作說明圖片區域 -->
                <div style="background: #e7f3ff; padding: 20px; border-radius: 8px; border-left: 4px solid #17a2b8; margin-bottom: 25px;">
                    <h4 style="color: #0c5460; margin: 0 0 20px 0; font-size: 18px;">🖼️ 操作說明圖解</h4>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <!-- 圖片1 -->
                        <div style="background: white; border: 1px solid #ddd; border-radius: 8px; padding: 15px; text-align: center;">
                            <div style="aspect-ratio: 4/3; background: #f0f0f0; border: 2px dashed #ccc; border-radius: 6px; margin-bottom: 10px; display: flex; align-items: center; justify-content: center; color: #666;">
                                <div>
                                    <i style="font-size: 48px; color: #aaa; margin-bottom: 10px;" class="fas fa-image"></i>
                                    <p style="margin: 0; font-size: 14px;">操作說明圖 1</p>
                                    <p style="margin: 5px 0 0 0; font-size: 12px; color: #999;">驗收狀態管理流程</p>
                                </div>
                            </div>
                            <p style="margin: 0; font-size: 13px; color: #666;">點擊此處上傳第一張說明圖片</p>
                        </div>
                        
                        <!-- 圖片2 -->
                        <div style="background: white; border: 1px solid #ddd; border-radius: 8px; padding: 15px; text-align: center;">
                            <div style="aspect-ratio: 4/3; background: #f0f0f0; border: 2px dashed #ccc; border-radius: 6px; margin-bottom: 10px; display: flex; align-items: center; justify-content: center; color: #666;">
                                <div>
                                    <i style="font-size: 48px; color: #aaa; margin-bottom: 10px;" class="fas fa-image"></i>
                                    <p style="margin: 0; font-size: 14px;">操作說明圖 2</p>
                                    <p style="margin: 5px 0 0 0; font-size: 12px; color: #999;">發信通知設定</p>
                                </div>
                            </div>
                            <p style="margin: 0; font-size: 13px; color: #666;">點擊此處上傳第二張說明圖片</p>
                        </div>
                    </div>
                    <p style="margin: 15px 0 0 0; font-size: 13px; color: #17a2b8; text-align: center;">
                        💡 將圖片檔案直接拖放到上方區域，或點擊區域選擇圖片
                    </p>
                </div>
                
                <div style="background: #fff3cd; padding: 20px; border-radius: 8px; border-left: 4px solid #ffc107; margin-bottom: 25px;">
                    <h4 style="color: #856404; margin: 0 0 15px 0; font-size: 18px;">🎯 狀態說明</h4>
                    <ul style="margin: 0; padding-left: 25px; color: #495057; line-height: 2; font-size: 15px;">
                        <li><strong>待驗收：</strong>剛上傳未處理的項目</li>
                        <li><strong>已核准：</strong>通過驗收的項目</li>
                        <li><strong>已拒絕：</strong>不通過驗收的項目</li>
                        <li><strong>已發信：</strong>已發送通知的項目</li>
                    </ul>
                </div>
                
                <div style="background: #e7f3ff; padding: 20px; border-radius: 8px; border-left: 4px solid #17a2b8; margin-bottom: 25px;">
                    <h4 style="color: #0c5460; margin: 0 0 15px 0; font-size: 18px;">⚙️ 批量操作</h4>
                    <ul style="margin: 0; padding-left: 25px; color: #495057; line-height: 2; font-size: 15px;">
                        <li>使用全選功能快速選擇所有項目</li>
                        <li>批量核准功能可一次核准多個項目</li>
                        <li>批量發信功能可同時發送多個通知</li>
                        <li>支援混合選擇和個別處理</li>
                    </ul>
                </div>
                
                <div style="background: #f8d7da; padding: 20px; border-radius: 8px; border-left: 4px solid #dc3545;">
                    <h4 style="color: #721c24; margin: 0 0 15px 0; font-size: 18px;">⚠️ 注意事項</h4>
                    <ul style="margin: 0; padding-left: 25px; color: #495057; line-height: 2; font-size: 15px;">
                        <li>檔案大小限制：50MB</li>
                        <li>支援格式：.mhtml 和 .mht</li>
                        <li>已發信的項目無法再次操作</li>
                        <li>建議先核准再發信，確保流程正確</li>
                        <li>系統會自動記錄所有操作歷程</li>
                        <li>說明圖片支援 JPG、PNG、GIF 格式</li>
                    </ul>
                </div>
            </div>
          `,
          confirmButtonText: '我知道了',
          confirmButtonColor: '#007bff',
          width: '900px',
          customClass: {
            popup: 'rule-explanation-popup'
          }
        });
      },
      
      // Toast 通知
      showToast(message, type = 'success') {
        this.toast = { show: true, message, type };
        setTimeout(() => (this.toast.show = false), 3000);
      }
    }
  }).mount('#app');
  
});