# app.py - Flask 後端主程式
from flask import Flask, request, jsonify
from flask_cors import CORS
from werkzeug.utils import secure_filename
import os
import re
import base64
import quopri
from datetime import datetime
import hashlib
from bs4 import BeautifulSoup
import email
from email import policy
from email.parser import BytesParser
import json
import traceback
import logging

app = Flask(__name__)
CORS(app)

# 設定日誌
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# 設定
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB 檔案大小限制
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['PROCESSED_FOLDER'] = 'processed'
app.config['ALLOWED_EXTENSIONS'] = {'mhtml', 'mht'}

# 確保資料夾存在
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['PROCESSED_FOLDER'], exist_ok=True)

def allowed_file(filename):
    """檢查檔案是否為允許的格式"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def generate_unique_filename(original_name, new_name):
    """生成唯一的檔名"""
    # 取得副檔名
    ext = original_name.rsplit('.', 1)[1].lower()
    
    # 如果新檔名沒有副檔名，加上原始副檔名
    if not new_name.endswith(f'.{ext}'):
        new_name = f"{new_name}.{ext}"
    
    # 生成唯一識別碼
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    unique_id = hashlib.md5(f"{new_name}{timestamp}".encode()).hexdigest()[:8]
    
    # 組合最終檔名
    name_without_ext = new_name.rsplit('.', 1)[0]
    final_name = f"{name_without_ext}_{unique_id}.{ext}"
    
    return secure_filename(final_name)

class MHTMLParser:
    """MHTML 檔案解析器"""
    
    def __init__(self, file_path):
        self.file_path = file_path
        self.boundary = None
        self.parts = []
        self.html_content = None
        self.metadata = {}
        self.gridview_data = None
        
    def parse(self):
        """解析 MHTML 檔案"""
        try:
            with open(self.file_path, 'rb') as f:
                # 使用 email 模組解析 MHTML
                try:
                    msg = BytesParser(policy=policy.default).parse(f)
                except Exception as e:
                    logger.error(f"Email parser error: {str(e)}")
                    # 如果 email 解析失敗，嘗試直接讀取為 HTML
                    f.seek(0)
                    content = f.read()
                    self.html_content = content.decode('utf-8', errors='ignore')
                    
                    if self.html_content:
                        result = self._extract_html_info()
                        gridview_data = self._parse_gridview()
                        if gridview_data:
                            result['gridview_data'] = gridview_data
                        return result
                    return {'error': f'無法解析檔案: {str(e)}'}
                
                # 提取基本資訊
                self.metadata['subject'] = msg.get('Subject', '')
                self.metadata['date'] = msg.get('Date', '')
                self.metadata['from'] = msg.get('From', '')
                self.metadata['content_type'] = msg.get_content_type()
                
                # 處理多部分內容
                if msg.is_multipart():
                    self._parse_multipart(msg)
                else:
                    # 單一部分 MHTML
                    content = msg.get_payload(decode=True)
                    if content:
                        self.html_content = content.decode('utf-8', errors='ignore')
                
                # 解析 HTML 內容
                if self.html_content:
                    result = self._extract_html_info()
                    
                    # 特別處理 GridView 表格
                    gridview_data = self._parse_gridview()
                    if gridview_data:
                        result['gridview_data'] = gridview_data
                    
                    return result
                    
            return self.metadata
            
        except Exception as e:
            logger.error(f"解析錯誤: {str(e)}")
            logger.error(traceback.format_exc())
            return {'error': str(e)}
    
    def _parse_multipart(self, msg):
        """解析多部分 MHTML"""
        for part in msg.walk():
            content_type = part.get_content_type()
            
            # 尋找 HTML 內容
            if content_type == 'text/html':
                content = part.get_payload(decode=True)
                if content:
                    self.html_content = content.decode('utf-8', errors='ignore')
                    
            # 收集其他資源
            elif not part.is_multipart():
                self.parts.append({
                    'content_type': content_type,
                    'content_location': part.get('Content-Location', ''),
                    'content_id': part.get('Content-ID', ''),
                    'size': len(part.get_payload())
                })
    
    def _extract_html_info(self):
        """從 HTML 內容提取資訊"""
        soup = BeautifulSoup(self.html_content, 'html.parser')
        
        # 提取標題
        title_tag = soup.find('title')
        self.metadata['title'] = title_tag.string if title_tag else ''
        
        # 提取 meta 標籤
        meta_tags = {}
        for meta in soup.find_all('meta'):
            name = meta.get('name') or meta.get('property')
            content = meta.get('content')
            if name and content:
                meta_tags[name] = content
            
            # 特別處理 charset
            if meta.get('charset'):
                self.metadata['encoding'] = meta.get('charset')
            elif meta.get('http-equiv', '').lower() == 'content-type':
                content = meta.get('content', '')
                if 'charset=' in content:
                    self.metadata['encoding'] = content.split('charset=')[-1].strip()
        
        self.metadata['meta_tags'] = meta_tags
        
        # 提取連結
        links = []
        for link in soup.find_all('link'):
            links.append({
                'rel': link.get('rel', []),
                'href': link.get('href', ''),
                'type': link.get('type', '')
            })
        self.metadata['links'] = links
        
        # 提取圖片
        images = []
        for img in soup.find_all('img'):
            images.append({
                'src': img.get('src', ''),
                'alt': img.get('alt', ''),
                'width': img.get('width', ''),
                'height': img.get('height', '')
            })
        self.metadata['images'] = images
        
        # 統計資訊
        self.metadata['statistics'] = {
            'total_parts': len(self.parts),
            'image_count': len(images),
            'link_count': len(links),
            'meta_count': len(meta_tags),
            'html_size': len(self.html_content) if self.html_content else 0
        }
        
        # 提取 Open Graph 資訊
        og_data = {}
        for key in ['title', 'description', 'url', 'image', 'type', 'site_name']:
            og_tag = soup.find('meta', {'property': f'og:{key}'})
            if og_tag:
                og_data[key] = og_tag.get('content', '')
        
        if og_data:
            self.metadata['open_graph'] = og_data
        
        # 提取文字內容摘要（前500字）
        text_content = soup.get_text(strip=True)
        self.metadata['content_preview'] = text_content[:500] if text_content else ''
        
        return self.metadata
    
    def _parse_gridview(self):
        """解析 GridView 表格資料"""
        if not self.html_content:
            return None
        
        try:
            soup = BeautifulSoup(self.html_content, 'html.parser')
            
            # 尋找 GridView Wrapper
            wrapper = soup.find('div', {'id': 'ContentPlaceHolder1_GridView2Wrapper'})
            if not wrapper:
                logger.debug("No GridView wrapper found")
                return None
            
            gridview_data = {
                'headers': [],
                'rows': [],
                'statistics': {}
            }
            
            # 解析表頭
            header_table = wrapper.find('table', {'id': 'ContentPlaceHolder1_GridView2Copy'})
            if header_table:
                header_row = header_table.find('tr', {'id': lambda x: x and 'HeaderCopy' in x})
                if header_row:
                    for th in header_row.find_all('th'):
                        # 清理表頭文字
                        header_text = th.get_text(strip=True)
                        header_text = header_text.replace('\n', ' ').replace('\r', '')
                        # 分離中英文
                        if 'br' in str(th):
                            parts = [t.strip() for t in th.strings]
                            header_dict = {
                                'zh': parts[0] if len(parts) > 0 else '',
                                'en': parts[1] if len(parts) > 1 else '',
                                'full': header_text
                            }
                        else:
                            header_dict = {
                                'zh': header_text,
                                'en': '',
                                'full': header_text
                            }
                        gridview_data['headers'].append(header_dict)
            
            # 解析資料行
            data_table = wrapper.find('table', {'id': 'ContentPlaceHolder1_GridView2'})
            if data_table:
                # 找所有的 tr，排除表頭
                all_rows = data_table.find_all('tr')
                data_rows = []
                
                for row in all_rows:
                    # 跳過表頭行（通常有特定的 style 或 id）
                    if row.get('id') and 'Header' in row.get('id', ''):
                        continue
                    if row.get('style') and 'display: none' in row.get('style', ''):
                        continue
                    # 確保有 td 元素
                    if row.find_all('td'):
                        data_rows.append(row)
                
                for row in data_rows:
                    row_data = []
                    cells = row.find_all('td')
                    
                    for idx, td in enumerate(cells):
                        cell_data = {
                            'value': '',
                            'inputs': [],
                            'spans': []
                        }
                        
                        # 提取 input 元素
                        inputs = td.find_all('input')
                        for inp in inputs:
                            input_data = {
                                'type': inp.get('type', ''),
                                'name': inp.get('name', ''),
                                'id': inp.get('id', ''),
                                'title': inp.get('title', ''),
                                'src': inp.get('src', '')
                            }
                            # 標記按鈕類型，不依賴外部圖片
                            if input_data['src']:
                                if 'edit' in input_data['src'].lower() or '編輯' in input_data.get('title', ''):
                                    input_data['button_type'] = 'edit'
                                elif 'delete' in input_data['src'].lower() or '刪除' in input_data.get('title', ''):
                                    input_data['button_type'] = 'delete'
                                else:
                                    input_data['button_type'] = 'unknown'
                            
                            cell_data['inputs'].append(input_data)
                        
                        # 提取 span 元素
                        spans = td.find_all('span')
                        for span in spans:
                            span_text = span.get_text(strip=True)
                            cell_data['spans'].append({
                                'id': span.get('id', ''),
                                'class': span.get('class', []),
                                'text': span_text
                            })
                            if not cell_data['value']:  # 使用第一個 span 的文字作為值
                                cell_data['value'] = span_text
                        
                        # 如果沒有 span，取整個 td 的文字
                        if not cell_data['value']:
                            cell_data['value'] = td.get_text(strip=True)
                        
                        row_data.append(cell_data)
                    
                    # 將資料行加入結果
                    if row_data:
                        # 建立結構化的資料物件
                        structured_row = {}
                        for i, header in enumerate(gridview_data['headers']):
                            if i < len(row_data):
                                # 建立更安全的欄位名稱
                                if header.get('en'):
                                    field_name = re.sub(r'[^a-zA-Z0-9_]', '_', header['en'].lower())
                                else:
                                    field_name = f'field_{i}'
                                structured_row[field_name] = row_data[i]['value']
                        
                        # 加入原始資料和結構化資料
                        gridview_data['rows'].append({
                            'raw_data': row_data,
                            'structured_data': structured_row
                        })
            
            # 統計資訊
            gridview_data['statistics'] = {
                'total_columns': len(gridview_data['headers']),
                'total_rows': len(gridview_data['rows']),
                'has_data': len(gridview_data['rows']) > 0
            }
            
            # 提取特定欄位的摘要（如果存在）
            if gridview_data['rows']:
                summary = {}
                # 提取一些關鍵欄位作為摘要
                key_fields = ['po_no', 'description', 'qty', 'amount', 'status']
                for field in key_fields:
                    values = []
                    for row in gridview_data['rows']:
                        if field in row['structured_data']:
                            values.append(row['structured_data'][field])
                    if values:
                        summary[field] = values
                gridview_data['summary'] = summary
            
            return gridview_data
            
        except Exception as e:
            logger.error(f"GridView parsing error: {str(e)}")
            logger.error(traceback.format_exc())
            return None

@app.route('/api/upload-mhtml', methods=['POST'])
def upload_mhtml():
    """處理 MHTML 檔案上傳"""
    try:
        # 檢查是否有檔案
        if 'file' not in request.files:
            logger.error("No file in request")
            return jsonify({'success': False, 'error': '沒有檔案被上傳'}), 400
        
        file = request.files['file']
        new_name = request.form.get('newName', '')
        
        # 檢查檔案是否為空
        if file.filename == '':
            logger.error("Empty filename")
            return jsonify({'success': False, 'error': '沒有選擇檔案'}), 400
        
        # 檢查檔案格式
        if not allowed_file(file.filename):
            logger.error(f"Invalid file type: {file.filename}")
            return jsonify({'success': False, 'error': '不支援的檔案格式'}), 400
        
        # 生成新的唯一檔名
        if new_name:
            filename = generate_unique_filename(file.filename, new_name)
        else:
            filename = generate_unique_filename(file.filename, file.filename)
        
        logger.info(f"Processing file: {filename}")
        
        # 儲存檔案到上傳資料夾
        upload_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(upload_path)
        
        # 移動並重新命名檔案到處理資料夾
        processed_path = os.path.join(app.config['PROCESSED_FOLDER'], filename)
        
        # 如果目標檔案已存在，先刪除
        if os.path.exists(processed_path):
            os.remove(processed_path)
        
        os.rename(upload_path, processed_path)
        
        # 解析 MHTML 檔案
        parser = MHTMLParser(processed_path)
        extracted_info = parser.parse()
        
        # 檢查是否有解析錯誤
        if 'error' in extracted_info:
            logger.error(f"Parser error: {extracted_info['error']}")
            # 即使有錯誤，還是返回部分資訊
        
        # 加入檔案資訊
        file_stats = os.stat(processed_path)
        extracted_info.update({
            'original_filename': file.filename,
            'saved_filename': filename,
            'file_size': file_stats.st_size,
            'upload_time': datetime.now().isoformat(),
            'file_path': processed_path
        })
        
        # 格式化檔案大小
        size = file_stats.st_size
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024.0:
                extracted_info['file_size_formatted'] = f"{size:.2f} {unit}"
                break
            size /= 1024.0
        
        # 如果有 GridView 資料，另外儲存為 JSON
        if 'gridview_data' in extracted_info and extracted_info['gridview_data']:
            json_filename = filename.rsplit('.', 1)[0] + '_gridview.json'
            json_path = os.path.join(app.config['PROCESSED_FOLDER'], json_filename)
            
            try:
                with open(json_path, 'w', encoding='utf-8') as f:
                    json.dump(extracted_info['gridview_data'], f, ensure_ascii=False, indent=2)
                
                extracted_info['gridview_json_file'] = json_filename
                logger.info(f"GridView data saved to: {json_filename}")
            except Exception as e:
                logger.error(f"Failed to save GridView JSON: {str(e)}")
        
        return jsonify({
            'success': True,
            'message': '檔案上傳並解析成功',
            'data': extracted_info
        })
        
    except Exception as e:
        logger.error(f"上傳錯誤: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': f'處理檔案時發生錯誤: {str(e)}'
        }), 500

@app.route('/api/list-files', methods=['GET'])
def list_files():
    """列出所有已處理的檔案"""
    try:
        files = []
        for filename in os.listdir(app.config['PROCESSED_FOLDER']):
            if allowed_file(filename):
                file_path = os.path.join(app.config['PROCESSED_FOLDER'], filename)
                file_stats = os.stat(file_path)
                
                # 格式化檔案大小
                size = file_stats.st_size
                size_formatted = size
                for unit in ['B', 'KB', 'MB', 'GB']:
                    if size < 1024.0:
                        size_formatted = f"{size:.2f} {unit}"
                        break
                    size /= 1024.0
                
                files.append({
                    'filename': filename,
                    'size': file_stats.st_size,
                    'size_formatted': size_formatted,
                    'modified_time': datetime.fromtimestamp(file_stats.st_mtime).isoformat()
                })
        
        # 按修改時間排序（最新的在前）
        files.sort(key=lambda x: x['modified_time'], reverse=True)
        
        return jsonify({
            'success': True,
            'files': files,
            'total': len(files)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/parse-file/<filename>', methods=['GET'])
def parse_existing_file(filename):
    """重新解析已存在的檔案"""
    try:
        file_path = os.path.join(app.config['PROCESSED_FOLDER'], secure_filename(filename))
        
        if not os.path.exists(file_path):
            return jsonify({'success': False, 'error': '檔案不存在'}), 404
        
        # 解析檔案
        parser = MHTMLParser(file_path)
        extracted_info = parser.parse()
        
        return jsonify({
            'success': True,
            'data': extracted_info
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/delete-file/<filename>', methods=['DELETE'])
def delete_file(filename):
    """刪除檔案"""
    try:
        file_path = os.path.join(app.config['PROCESSED_FOLDER'], secure_filename(filename))
        
        if os.path.exists(file_path):
            os.remove(file_path)
            return jsonify({'success': True, 'message': '檔案已刪除'})
        else:
            return jsonify({'success': False, 'error': '檔案不存在'}), 404
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    """健康檢查端點"""
    return jsonify({
        'status': 'healthy',
        'server': 'Flask MHTML Parser',
        'version': '1.0.0',
        'timestamp': datetime.now().isoformat()
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)