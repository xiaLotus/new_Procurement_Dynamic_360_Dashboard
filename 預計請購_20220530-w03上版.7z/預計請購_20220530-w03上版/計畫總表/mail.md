### Mail 當前缺失(Or 狀態)
| 序號 | 問題 | 解法 (Or 狀態) |
| :--- | :--- | :--- |
| 1 | 寄 Mail 時會寄到兩封。 | None。<br><br>懷疑是 Notes本身的問題，已經過測試，如果在CC時加上`ASEK_ASSYIII_CIM_AS`又加上`自己`的 Notes，會同時寄出兩封，當前無解|

 