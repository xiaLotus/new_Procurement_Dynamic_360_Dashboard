# normal 為除去超急件的發送 mail 通道
# urgent 專門為超急件開的 mail 通道