import datetime
import json
import os
import re
from flask import Flask, jsonify, request
from flask_cors import CORS
import pandas as pd
from ldap3 import Server, Connection, ALL, NTLM # type: ignore
from ldap3.core.exceptions import LDAPException, LDAPBindError # type: ignore
import uuid
from filelock import FileLock
from werkzeug.utils import secure_filename
import glob
import logging
import shutil
import numpy as np

BACKEND_DATA = r"D:\Data\Backend_Access_Management\Backend_data.json"
VENDER_FILE_PATH = f'static/data/vender.ini'

app = Flask(__name__)
CORS(app)
CSV_FILE = "static/data/Planned_Purchase_Request_List.csv"
JSON_FILE = f"static/data/money.json"
BUYER_FILE = f"static/data/Buyer_detail_updated.csv"

def read_json_file():
    try:
        with open(JSON_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}  # 如果文件不存在，返回空字典


def clean_value(val):
    try:
        if isinstance(val, str) and val.endswith(".0"):
            return str(int(float(val)))
        return str(val) if val is not None else ""
    except Exception:
        return str(val)


def authenticate_user(username, password):
    try:
        # server = Server('ldap://KHADDC02.kh.asegroup.com', get_info = ALL)
        # 使用 NTLM
        user = f'kh\\{username}'
        password = f'{password}'

        # print("帳號: ", username, " 密碼: ", password)
        # 建立連接
        # conn = Connection(server, user = user, password = password, authentication = NTLM)

        # 嘗試綁定
        # if conn.bind():
            # app.logger.info(f"User {username} login successful.")
        return True
        # else:
        #     # app.logger.warning(f"Login failed for user {username}: {conn.last_error}")
        #     return False
    except Exception as e:
        # app.logger.error(f"Error during authentication for user {username}: {e}")
        return False

@app.route("/api/getAllLoginer", methods=["POST"])
def getAllLoginer():
    try:
        data = request.get_json()
        user_id = data.get("username")
        print(user_id)

        with open("Backend_data.json", "r", encoding="utf-8-sig") as f:
            items = json.load(f)

        for item in items:
            if str(item.get("工號", "")).strip() == user_id:
                return jsonify({"name": "Username Find"})
            
        return jsonify({"error": "Item not found"}), 404

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    if not data:
        return jsonify({'message': '未提供登入資訊'}), 400
    
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()
    
    if authenticate_user(username, password):
        return jsonify({'message': '登入成功'})
    return jsonify({'message': '帳號或密碼錯誤'}), 401


@app.route("/data")
def get_data():
    df = pd.read_csv(CSV_FILE, encoding="utf-8-sig", dtype=str)

    # ✅ 確保欄位齊全
    expected_columns = [
        "Id", "開單狀態", "WBS", "請購順序", "需求者", "請購項目", "需求原因",
        "總金額", "需求日", "已開單日期", "ePR No.", "進度追蹤超連結", "備註"
    ]
    for col in expected_columns:
        if col not in df.columns:
            df[col] = ""

    # ✅ 確保有 Id 欄，補 UUID
    if "Id" not in df.columns:
        df.insert(0, "Id", [str(uuid.uuid4()) for _ in range(len(df))])
        df.to_csv(CSV_FILE, index=False, encoding="utf-8-sig")
    else:
        df["Id"] = df["Id"].fillna("").astype(str).str.strip()
        missing_ids = df["Id"] == ""
        df.loc[missing_ids, "Id"] = [str(uuid.uuid4()) for _ in range(missing_ids.sum())]
        if missing_ids.any():
            df.to_csv(CSV_FILE, index=False, encoding="utf-8-sig")

    # ✅ 清洗欄位資料格式
    df["ePR No."] = df["ePR No."].apply(lambda x: "" if pd.isna(x) or x == 0 else str(int(float(x))))
    df["總金額"] = pd.to_numeric(df["總金額"], errors="coerce").fillna(0)
    df["總金額"] = df["總金額"].apply(lambda x: "" if x == 0 else int(x))
    df = df.fillna("")

    return jsonify(df.to_dict(orient="records"))



import traceback

@app.route('/api/unordered-count')
def get_unordered_count():
    import pandas as pd
    import os

    if not os.path.exists(CSV_FILE) or os.path.getsize(CSV_FILE) == 0:
        return jsonify({
            "count_X": 0,
            "count_V": 0,
            "monthly_expenses": {}
        })

    try:
        df = pd.read_csv(CSV_FILE, encoding="utf-8-sig", dtype=str)
        df = df.fillna("")

        count_X = df[df["開單狀態"] != "V"].shape[0]
        count_V = df[df["開單狀態"] == "V"].shape[0]

        df_unordered = df[df["開單狀態"] != "V"].copy()

        # ✅ 加這一行，過濾掉非法的需求日
        df_unordered["需求日"] = df_unordered["需求日"].astype(str).str.replace("/", "", regex=False)
        df_unordered = df_unordered[df_unordered["需求日"].str.match(r'^\d{8}$')].copy()

        df_unordered["總金額"] = pd.to_numeric(df_unordered["總金額"], errors="coerce").fillna(0)
        df_unordered["需求日"] = df_unordered["需求日"].astype(str)
        df_unordered["月份"] = df_unordered["需求日"].str.slice(0, 6)

        monthly_sums = df_unordered.groupby("月份")["總金額"].sum().sort_index()
        monthly_expenses = {month: int(round(amount, 2)) for month, amount in monthly_sums.items()}

        print(monthly_expenses)

        return jsonify({
            "count_X": count_X,
            "count_V": count_V,
            "monthly_expenses": monthly_expenses
        })

    except Exception as e:
        traceback.print_exc()  
        return jsonify({
            "count_X": 0,
            "count_V": 0,
            "monthly_expenses": {},
            "error": str(e)
        }), 500


@app.route('/api/getrestofmoney', methods = ['GET'])
def getrestofmoney():
    budget = read_json_file()
    # 獲取當前的日期和時間
    current_date = datetime.datetime.now()

    # 獲取當年的年份和當前月份
    current_year = current_date.year
    current_month = current_date.month
    current_year = str(current_date.year)
    current_month = str(current_date.month)

    data = budget.get("預算", {}).get(current_year, {}).get(current_month, {})
    current_budget = data.get('當月請購預算', 0)
    additional_budget = data.get('當月追加預算', 0)

    return jsonify({
        '當月請購預算': current_budget,
        '當月追加預算': additional_budget
    })




@app.route('/api/budget_months', methods=['GET'])
def get_budget_months():
    """
    獲取所有可用的預算月份選項和對應的預算金額
    """
    try:
        budget = read_json_file()
        print(f"📊 讀取預算資料: {budget}")
        
        budget_list = []
        
        # 從預算資料中提取所有年份和月份，並計算預算
        budget_data = budget.get("預算", {})
        
        for year in budget_data.keys():
            year_data = budget_data[year]
            for month in year_data.keys():
                # 格式化為 YYYYMM 格式
                month_padded = str(month).zfill(2)
                year_month = f"{year}{month_padded}"
                
                # 獲取該月份的預算資料
                month_budget_data = year_data[month]
                current_budget = month_budget_data.get('當月請購預算', 0)
                additional_budget = month_budget_data.get('當月追加預算', 0)
                total_budget = current_budget + additional_budget
                
                # 建立月份和預算的對應資料
                budget_info = {
                    'month': year_month,
                    'money': total_budget,
                    '當月請購預算': current_budget,
                    '當月追加預算': additional_budget
                }
                
                budget_list.append(budget_info)
                # print(f"💰 {year_month}: 請購={current_budget:,}, 追加={additional_budget:,}, 總計={total_budget:,}")
        
        # 按月份排序，最新的在前
        budget_list.sort(key=lambda x: x['month'], reverse=True)
        
        print(f"📅 完整預算清單: {budget_list}")
        
        return jsonify({
            'success': True,
            'budget_list': budget_list,
            'count': len(budget_list)
        })
        
    except Exception as e:
        print(f"❌ 獲取預算月份錯誤: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500
    

@app.route('/api/uploadMoney', methods=['POST'])
def uploadMoney():
    try:
        data = request.get_json()
        year = data.get('currentYear')
        month = data.get('currentMonth')
        current_budget = data.get('currentBudget')
        additional_budget = data.get('additionalBudget')

        budget_data = read_json_file()  # 讀原始 JSON 資料
        print("budget_data: ", budget_data)

        # 檢查年度
        if "預算" not in budget_data:
            budget_data["預算"] = {}

        if str(year) not in budget_data["預算"]:
            budget_data["預算"][str(year)] = {}

        # 更新該月份資料
        budget_data["預算"][str(year)][str(month)] = {
            "當月請購預算": current_budget,
            "當月追加預算": additional_budget
        }

        # ✅ 正確寫入更新後的資料
        with open(JSON_FILE, 'w', encoding='utf-8') as f:
            json.dump(budget_data, f, ensure_ascii=False, indent=4)

        return jsonify({'message': '資料提交成功'}), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 400


@app.route('/api/requesters', methods=['GET'])
def get_requesters():
    try:
        with open("config.cfg", "r", encoding="utf-8-sig") as f:
            lines = f.readlines()
            names = [line.strip() for line in lines if line.strip()]  
            # print("requesters: ", names)
            return jsonify(names)
    except Exception as e:
        return jsonify({"error": str(e)}), 500



@app.route('/api/admins', methods=['GET'])
def get_admins():
    try:
        with open("Backend_data.json", "r", encoding="utf-8-sig") as f:
            data = json.load(f)
            seen = set()
            names = []
            for entry in data:
                if entry["請購網頁後台"] == 'O':
                    name = entry["工號"]
                    if name not in seen:
                        seen.add(name)
                        names.append(name)
            # print("admins: ", names)
            return jsonify(names)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/add", methods = ['POST'])
def add_new_item():
    try:
        data = request.get_json()
        main_data = {k: v for k, v in data.items() if k != 'tableRows'}
        table_rows = data.get('tableRows', [])

        print("主資料：", main_data)
        
        if not data:
            return jsonify({'status': 'error', 'message': '無效的 JSON 請求'}), 400

        df = pd.read_csv(CSV_FILE, encoding="utf-8-sig", dtype=str)

        # 確保所有欄位一致
        # new_row = {col: data.get(col, "") for col in df.columns}

        new_row = {col: clean_value(main_data.get(col, "")) for col in df.columns}

        if isinstance(new_row["需求日"], str) and "/" in new_row["需求日"]:
            new_row['需求日'] = new_row["需求日"].replace("/", "")

        if isinstance(new_row["已開單日期"], str) and "/" in new_row["已開單日期"]:
            new_row['已開單日期'] = new_row["已開單日期"].replace("/", "")

        def safe_float_to_int64(value):
            try:
                return str(int(float(value)))
            except (ValueError, TypeError, OverflowError):
                return ""

        # ✨ 要轉換的欄位（避免 int32 溢位）
        numeric_fields = ["請購順序", "總金額", "需求日", "已開單日期", "ePR No."]
        for field in numeric_fields:
            if field in new_row:
                new_row[field] = safe_float_to_int64(new_row[field])

        new_row["Id"] = str(uuid.uuid4())  # 自動產生唯一 ID

        df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
        print(new_row)
        # 儲存回 CSV
        df.to_csv(CSV_FILE, index=False, encoding="utf-8-sig")

        # 寫入另一張表
        print("表格列：", table_rows)
        DETAIL_CSV_FILE = "static/data/Buyer_detail.csv"  # 建議存另一份 CSV 檔

        detail_columns = [
            "Id", "開單狀態", "交貨驗證", "User", "ePR No.", "PO No.",
            "Item", "品項", "規格", "數量", "總數", "單價", "總價", "備註", "字數",
            "isEditing", "backup", "_alertedItemLimit", "Delivery Date 廠商承諾交期",
            "SOD Qty 廠商承諾數量", "驗收數量", "拒收數量", "發票月份", "WBS", "需求日"
        ]

        # 處理後的資料列（每筆 row 補上主資料 ID，欄位順序統一）
        cleaned_rows = []
        for row in table_rows:
            cleaned_row = {"Id": new_row["Id"]}  # 主表 Id
            for col in detail_columns[1:-2]:  # 不含 isEditing, backup，這兩個手動補
                cleaned_row[col] = row.get(col, "")
            cleaned_row["isEditing"] = "False"
            cleaned_row["backup"] = "{}"
            cleaned_rows.append(cleaned_row)
            
        # 如果檔案已存在就 append，否則建立新檔
        if os.path.exists(DETAIL_CSV_FILE):
            df_detail = pd.read_csv(DETAIL_CSV_FILE, encoding="utf-8-sig", dtype=str)
            df_detail = pd.concat([df_detail, pd.DataFrame(cleaned_rows)], ignore_index=True)
        else:
            df_detail = pd.DataFrame(cleaned_rows, columns=detail_columns)

        # 寫入 CSV
        df_detail.to_csv(DETAIL_CSV_FILE, index=False, columns=detail_columns, encoding="utf-8-sig")

        return jsonify({'status': 'success', 'message': '資料新增成功'}), 200

    except Exception as e:
        print("新增錯誤：", e)
        return jsonify({'status': 'error', 'message': str(e)}), 500
    



@app.route('/update', methods=['POST'])
def update_data():
    new_data = request.json
    if not isinstance(new_data, dict):
        return jsonify({"message": "請求內容不是有效的 JSON"}), 400
    print(new_data)
    main_data = {k: v for k, v in new_data.items() if k != "tableRows"} # type: ignore
    detail_data = new_data.get("tableRows", []) # type: ignore
    
    if main_data is None:
        return jsonify({"message": "請求內容不是有效的 JSON"}), 400
    
    target_id = str(main_data.get("Id", "")).strip()
    if not target_id:
        return jsonify({"message": "缺少 Id"}), 400
    
    try:
        df = pd.read_csv(CSV_FILE, dtype=str)
        df.fillna("", inplace=True)

        # 找到對應列
        df["Id"] = df["Id"].astype(str).str.strip()
        match_idx = df.index[df["Id"] == target_id].tolist()
        if not match_idx:
            return jsonify({"message": "找不到對應資料"}), 404
        idx = match_idx[0]

        # 處理日期欄位格式
        if isinstance(new_data.get("需求日"), str):
            main_data["需求日"] = main_data["需求日"].replace("/", "")
        if isinstance(new_data.get("已開單日期"), str):
            main_data["已開單日期"] = main_data["已開單日期"].replace("/", "")

        # 更新欄位
        for col in df.columns:
            df.at[idx, col] = str(main_data.get(col, ""))

            # 清洗資料（包含去除 .0 與斜線）
        for col in df.columns:
            val = main_data.get(col, "")
            val = clean_value(val)
            if col in ["需求日", "已開單日期"] and isinstance(val, str):
                val = val.replace("/", "")
            df.at[idx, col] = val

        # 若 ePR No. 存在 → 補連結欄位
        if main_data.get('ePR No.'):
            df.at[idx, "進度追蹤超連結"] = f"https://khwfap.kh.asegroup.com/ePR/PRQuery/QueryPR?id={main_data['ePR No.']}"


        df.to_csv(CSV_FILE, index=False, encoding="utf-8-sig")
       
    
        detail_file = "static/data/Buyer_detail.csv"
        if os.path.exists(detail_file):
            df_detail = pd.read_csv(detail_file, encoding="utf-8-sig", dtype=str)
            df_detail = df_detail[df_detail["Id"] != target_id]
        else:
            df_detail = pd.DataFrame()

        # 加入新的細項資料
        if detail_data:
            new_rows = pd.DataFrame(detail_data)
            new_rows["Id"] = target_id  # 加入對應主表 Id
            df_detail = pd.concat([df_detail, new_rows], ignore_index=True)

        # 儲存
        df_detail.to_csv(detail_file, index=False, encoding="utf-8-sig")
        
        return jsonify({"message": "更新成功"}), 200

    except Exception as e:
        print("錯誤：", e)
        return jsonify({"message": "資料更新失敗"}), 500



@app.route('/api/get-username-info', methods=['POST'])
def get_username_info():
    try:
        data = request.get_json()
        emp_id = data.get("emp_id", "").strip()  # 工號

        if not emp_id:
            return jsonify({"error": "缺少工號"}), 400

        with open("Backend_data.json", "r", encoding="utf-8-sig") as f:
            users = json.load(f)

        for entry in users:
            if entry.get("工號", "").strip() == emp_id:
                return jsonify({
                    "name": entry.get("姓名", "").strip(),
                    "班別": entry.get("班別", "").strip()
                })

        return jsonify({"error": "查無此工號"}), 404

    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
    
@app.route('/api/checkeEPRno', methods=['POST'])
def check_epr_no():
    try:
        epr_no = request.get_json()
        if not isinstance(epr_no, str):
            return jsonify({'error': 'Invalid ePR No. format'}), 400

        df = pd.read_csv(CSV_FILE, dtype=str)  # 讀取所有欄位為字串避免轉型問題
        exists = epr_no in df['ePR No.'].dropna().tolist()

        return jsonify({'exists': exists})
    except Exception as e:
        print(f"❌ 錯誤: {e}")
        return jsonify({'error': '檢查失敗'}), 500


@app.route('/api/check-edit-permission', methods=['POST'])
def check_edit_permission():
    try:
        data = request.get_json()
        current_user = data.get("currentUser", "").strip()
        target_id = data.get("id", "").strip()

        if not current_user or not target_id:
            return jsonify({"allowed": False, "error": "缺少必要參數"}), 400
        
        # 讀取 admin 工號列表
        with open("Backend_data.json", "r", encoding="utf-8-sig") as f:
            backend_data = json.load(f)
            admin_ids = [
                entry.get("工號", "").strip()
                for entry in backend_data
                if entry.get("請購網頁後台") == "O"
            ]

        is_admin = current_user in admin_ids

        # 查詢該 ID 對應的需求者
        df = pd.read_csv(CSV_FILE, encoding="utf-8-sig", dtype=str)
        df.fillna("", inplace=True)
        df["Id"] = df["Id"].astype(str).str.strip()

        matched_row = df[df["Id"] == target_id]
        if matched_row.empty:
            return jsonify({"allowed": False, "error": "找不到對應資料"}), 404

        row = matched_row.iloc[0]
        requester = row.get("需求者", "").strip()

        with open("Backend_data.json", "r", encoding="utf-8-sig") as f:
            backend_data = json.load(f)
        
        requester_id = ""
        for entry in backend_data:
            if entry.get("姓名", "").strip() == requester:
                requester_id = entry.get("工號", "").strip()
                break

        print(f"使用者: {current_user}, 工號: {requester_id}, 是否為 admin: ", is_admin)

        if requester_id == current_user:
            return jsonify({"allowed": True})

        return jsonify({"allowed": is_admin})

    except Exception as e:
        print("權限檢查失敗：", e)
        return jsonify({"allowed": False, "error": str(e)}), 500




@app.route("/api/get_detail/<id>", methods=["GET"])
def get_detail_by_id(id):
    try:
        detail_file = "static/data/Buyer_detail.csv"
        if not os.path.exists(detail_file):
            return jsonify([])  # 沒有資料回傳空陣列

        df = pd.read_csv(detail_file, encoding="utf-8-sig", dtype=str)
        df.fillna("", inplace=True)

        # 篩選出指定 Id 的細項資料
        detail_rows = df[df["Id"] == id].to_dict(orient="records")
        return jsonify(detail_rows)
    
    except Exception as e:
        print("讀取細項資料錯誤：", e)
        return jsonify({"error": str(e)}), 500



@app.route("/getItemName", methods=["POST"])
def get_item_name():
    try:
        data = request.get_json()
        user_id = data.get("username")
        user_name = data.get("NeedPerson")
        print(user_id, user_name)

        with open("Backend_data.json", "r", encoding="utf-8-sig") as f:
            items = json.load(f)

        for item in items:
            if str(item.get("工號", "")).strip() == user_id:
                return jsonify({"name": item.get("姓名", "")})
            
        return jsonify({"error": "Item not found"}), 404

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/delete', methods=['POST'])
def delete_entry():
    data = request.json
    if data is None:
        return jsonify({"message": "請求內容不是有效的 JSON"}), 400
    
    target_id = str(data.get("Id", "")).strip()
    if not target_id:
        return jsonify({"status": "error", "message": "缺少 Id 欄位"}), 400

    df = pd.read_csv(CSV_FILE, encoding="utf-8-sig", dtype=str)
    # 取消 eprno的欄位

    new_df = df[df['Id'] != target_id]

    if len(new_df) == len(df):
        return jsonify({"status": "error", "message": "找不到符合條件的資料"})

    new_df.to_csv(CSV_FILE, index=False, encoding="utf-8-sig")

    detail_file = "static/data/Buyer_detail.csv" 
    if os.path.exists(detail_file):
        df_detail = pd.read_csv(detail_file, encoding="utf-8-sig", dtype=str)
        df_detail = df_detail[df_detail["Id"] != target_id]
        df_detail.to_csv(detail_file, index=False, encoding="utf-8-sig")

    return jsonify({"status": "success", "message": "已成功刪除"})

# 預計請購 更新目前狀態
@app.route("/api/Status-upload", methods=["POST"])
def upload():
    if 'file' not in request.files:
        return jsonify({'status': 'fail', 'msg': 'No file uploaded'}), 400

    file = request.files['file']
    filename = file.filename
    if filename != "download.csv":
        return jsonify({'status': 'Fail', 'filename': filename}), 400
    filename = f"status_{uuid.uuid4().hex}.csv"
    filepath = os.path.join('uploads', str(filename))
    file.save(filepath)

    lock = FileLock(f"{CSV_FILE}.lock")

    def clean_nan_value(val):
        if pd.isna(val) or str(val).strip().lower() in ['nan', 'none']:
            return ""
        return str(val).strip()
    
    with lock:
        try:

            df = pd.read_csv(filepath)
            updates = []
            for _, row in df.iterrows():
                epr_no = str(row.get('E-PR號碼           ', '')).strip()
                status = clean_nan_value(row.get('狀態', ''))
                stage = clean_nan_value(row.get('簽核中關卡', ''))

                if epr_no and epr_no != 'nan':
                    updates.append({
                        'epr_no': epr_no,
                        '狀態': status,
                        '簽核中關卡': stage
                    })
                    
            Planned_Purchase_Request_List_df = pd.read_csv(CSV_FILE)
            updated_count = 0
            no_change_count = 0

            # non_null_count = Planned_Purchase_Request_List_df['ePR No.'].notna().sum()


            for update in updates:
                epr = update['epr_no']
                new_status = update['狀態']
                new_stage = update['簽核中關卡']
            
                match = Planned_Purchase_Request_List_df['ePR No.'] == int(epr)
                if match.any():
                    idx = Planned_Purchase_Request_List_df[match].index[0]
                    
                    # 取得目前值
                    old_status = clean_nan_value(Planned_Purchase_Request_List_df.at[idx, 'Status'])
                    old_stage = clean_nan_value(Planned_Purchase_Request_List_df.at[idx, '簽核中關卡'])
                    
                    # 只有在真的有變更時才更新
                    if old_status != new_status or old_stage != new_stage:
                        Planned_Purchase_Request_List_df.at[idx, 'Status'] = new_status
                        Planned_Purchase_Request_List_df.at[idx, '簽核中關卡'] = new_stage
                        updated_count += 1
                    else:
                        no_change_count += 1

                    
            def safe_float_to_int64(val):
                try:
                    if pd.isna(val):
                        return ""
                    return str(int(float(val)))
                except:
                    return str(val).strip()
                
            numeric_fields = ["請購順序", "總金額", "需求日", "已開單日期", "ePR No."]
            for field in numeric_fields:
                if field in Planned_Purchase_Request_List_df.columns:
                    Planned_Purchase_Request_List_df[field] = Planned_Purchase_Request_List_df[field].apply(safe_float_to_int64)

            # 清理所有欄位
            for col in Planned_Purchase_Request_List_df.columns:
                Planned_Purchase_Request_List_df[col] = Planned_Purchase_Request_List_df[col].apply(clean_nan_value)

            Planned_Purchase_Request_List_df.to_csv(CSV_FILE, index=False, encoding='utf-8-sig', na_rep="")
        except Exception as e:
            print("Exception: ", e)


    with lock:
        try:
            df_update = pd.read_csv(filepath, dtype=str)

            # 提取更新資料
            po_updates = []
            for _, row in df_update.iterrows():
                epr_no = str(row.get('E-PR號碼           ', '')).strip()
                sap_po  = str(row.get('SAP PO', '')).strip() 
                if epr_no and sap_po:
                    po_updates.append({
                        'epr_no': epr_no,
                        'po_no': sap_po
                    })
            df_detail = pd.read_csv(BUYER_FILE, dtype=str)

            if "PO No." not in df_detail.columns:
                df_detail["PO No."] = ""


            updated = 0
            nochange = 0

            for upd in po_updates:
                epr = upd['epr_no']
                new_po = upd['po_no']

                # ePR No. 轉成 int → str 避免格式不同
                try:
                    epr_str = str(int(float(epr)))
                except:
                    epr_str = str(epr).strip()

                match_idx = df_detail.index[df_detail['ePR No.'] == epr_str].tolist()

                if match_idx:
                    for idx in match_idx:
                        old_po = str(df_detail.at[idx, 'PO No.']).strip()

                        if old_po != new_po:
                            df_detail.at[idx, 'PO No.'] = new_po
                            updated += 1
                        else:
                            nochange += 1

            # 寫回 Buyer_detail.csv
            df_detail.to_csv(BUYER_FILE, index=False, encoding="utf-8-sig")
            return jsonify({'status': 'success', 'updated_count': updated_count})

        except Exception as e:
            return jsonify({'status': 'Fail', 'reason': e})




# 路徑(報告路徑)
@app.route('/upload_report', methods=['POST'])
def upload_report():
    file = request.files.get('file')
    folder = request.form.get('folder')
    username = request.form.get('work_username')

    if not file:
        return jsonify(success=False, message='無檔案')
    if not folder:
        return jsonify(success=False, message='資料夾名稱為空')
    if not username:
        return jsonify(success=False, message='缺少 username')

    filename = file.filename or ''
    if filename == '':
        return jsonify(success=False, message='檔案名稱為空')

    try:
        save_path = os.path.join(
            r'\\cim300\FT01_CIM\FT01_4000\11.RR班人員-ePR請購管理',
            username,
            folder
        )
        os.makedirs(save_path, exist_ok=True)
        file.save(os.path.join(save_path, filename))
        return jsonify(success=True, message='已上傳')
    except Exception as e:
        print('❌ 儲存錯誤：', e)
        return jsonify(success=False, message=str(e))



# 路徑(報告路徑)
@app.route('/upload_acceptancereport', methods=['POST'])
def upload_acceptancereport():
    file = request.files.get('file')
    folder = request.form.get('folder')
    username = request.form.get('work_username')

    if not file:
        return jsonify(success=False, message='無檔案')
    if not folder:
        return jsonify(success=False, message='資料夾名稱為空')
    if not username:
        return jsonify(success=False, message='缺少 username')

    filename = file.filename or ''
    if filename == '':
        return jsonify(success=False, message='檔案名稱為空')

    try:
        save_path = os.path.join(
            r'\\cim300\FT01_CIM\FT01_4000\11.RR班人員-ePR請購管理',
            username,
            r"=已結單=",
            folder
        )
        os.makedirs(save_path, exist_ok=True)
        file.save(os.path.join(save_path, filename))
        return jsonify(success=True, message='已上傳')
    except Exception as e:
        print('❌ 儲存錯誤：', e)
        return jsonify(success=False, message=str(e))

# 取得英文名字
@app.route('/api/getUsername', methods=['POST'])
def get_username():
    try:
        data = request.get_json()
        username = data.get("username")
        print("收到需求者名字：", username)


        with open("Backend_data.json", "r", encoding="utf-8-sig") as f:
            backend_data = json.load(f)

        matched = next((entry for entry in backend_data if entry["姓名"] == username), None)
        
        if matched and "Notes_ID" in matched:
            try:
                name = matched["Notes_ID"].split("_")[0]
            except:
                name = matched["Notes_ID"].split("@")[0]

            return jsonify({"name": name})
        else:
            return jsonify({"name": "查無使用者"}), 404
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/sendmail', methods=['POST']) 
def sendmail():
    try:
        data = request.get_json()
        with open("Backend_data.json", "r", encoding="utf-8-sig") as f:
            backend_data = json.load(f)

        mail_data = data.get("data", {})
        recipient_clean = mail_data.get("需求者", "").strip()  
        mail_name = ''
        matched = next(
            (entry for entry in backend_data if entry.get("姓名", "").strip() == recipient_clean),
            None
        )

        if matched and "Notes_ID" in matched:
            mail_name = matched["Notes_ID"]

        raw_cc = data.get("cc", "")  

        cc_names = [name.strip() for name in raw_cc.split(",") if name.strip()]

        cc_list = [name.replace(" ", "_") + "@aseglobal.com" for name in cc_names]

        cc_string = ",".join(cc_list)

        if data["data"]["請購順序"] == "1":
            print("正在導入超急件模組...")
            from MailFunction.urgent import send_mail
            print("開始執行超急件郵件發送...")
            try:
                print(data["data"], '\n', data["recipient"], '\n', mail_name, '\n', cc_string)
                send_mail(data["data"], data["recipient"], mail_name, cc_string)
                print("超急件郵件發送完成")
            except Exception as urgent_error:
                print(f"❌ 超急件郵件發送錯誤: {str(urgent_error)}")
                import traceback
                print("完整錯誤追蹤:")
                traceback.print_exc()
                raise urgent_error
        else:
            print("正在導入一般郵件模組...")
            from MailFunction.normail import send_mail
            print("開始執行一般郵件發送...")
            try:
                print(data["data"], '\n', data["recipient"], '\n', mail_name, '\n', cc_string)
                send_mail(data["data"], data["recipient"], mail_name, cc_string)
                print("一般郵件發送完成")
            except Exception as normal_error:
                print(f"❌ 一般郵件發送錯誤: {str(normal_error)}")
                import traceback
                print("完整錯誤追蹤:")
                traceback.print_exc()
                raise normal_error

        print("準備返回成功響應")
        return jsonify({"success": True, "message": "郵件發送成功"}), 200
        
    except Exception as e:
        print(f"❌ 主函數錯誤: {str(e)}")
        import traceback
        print("完整錯誤追蹤:")
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500
    
@app.route('/update_for_mail', methods=['POST'])
def update_for_mail():
    new_data = request.json
    print("收到的資料:", new_data)
    
    if new_data is None:
        return jsonify({"message": "沒有收到資料"}), 400
    
    try:
        df = pd.read_csv(CSV_FILE, dtype=str)
        df.fillna("", inplace=True)

        # 找到對應列
        df["Id"] = df["Id"].astype(str).str.strip()
        target_id = str(new_data['Id']).strip()
        
        print(f"尋找 Id: {target_id}")
        
        # 找到符合條件的列
        mask = df["Id"] == target_id
        
        if not mask.any():
            print(f"找不到 Id 為 {target_id} 的資料")
            return jsonify({"message": "找不到對應的資料"}), 404
        
        print(f"找到對應資料，開始更新...")
        
        # 更新資料
        for key, value in new_data.items():
            if key in df.columns:
                df.loc[mask, key] = str(value) if value is not None else ""
                print(f"更新 {key}: {value}")
        
        # 儲存到 CSV
        df.to_csv(CSV_FILE, index=False, encoding="utf-8-sig")
        print("資料已儲存")
        
        return jsonify({"message": "更新成功"}), 200

    except Exception as e:
        print("錯誤：", e)
        import traceback
        traceback.print_exc()
        return jsonify({"message": "資料更新失敗"}), 500


# 罐頭訊息   - 。(前購單：，詳如附件)需求工程師：(CT4:)，合作開發：
@app.route('/api/get_phone', methods=['POST'])
def get_phone():
    data = request.get_json()
    name = data.get("name", "")
    with open('static/data/phone.json', 'r', encoding='utf-8-sig') as f:
        phone_data = json.load(f)

    phone_number = phone_data.get(name, "未知")

    return jsonify({"phone": phone_number})


# 廠商
@app.route('/api/venders', methods=['GET'])
def get_venders():
    """讀取 vender.ini 並返回供應商列表"""
    try:
        if os.path.exists(VENDER_FILE_PATH):
            with open(VENDER_FILE_PATH, 'r', encoding='utf-8') as f:
                venders = [line.strip() for line in f.readlines() if line.strip()]
            return jsonify(venders)
        else:
            return jsonify([])
    except Exception as e:
        print(e)
        return jsonify({'error': str(e)}), 500


@app.route('/api/venders', methods=['POST'])
def add_vender():
    """新增供應商到 vender.ini"""
    try:
        data = request.get_json()
        new_vender = data.get('vender', '').strip()

        if not new_vender:
            return jsonify({'error': '供應商名稱不能是空的'}), 400

        # 讀取現有清單，避免重複
        existing = []
        if os.path.exists(VENDER_FILE_PATH):
            with open(VENDER_FILE_PATH, 'r', encoding='utf-8') as f:
                existing = [line.strip() for line in f.readlines() if line.strip()]

        if new_vender in existing:
            return jsonify({'message': '供應商已存在'}), 200

        # 追加寫入
        with open(VENDER_FILE_PATH, 'a', encoding='utf-8') as f:
            f.write(new_vender + '\n')

        return jsonify({'message': '新增成功', 'vender': new_vender}), 201

    except Exception as e:
        print(e)
        return jsonify({'error': str(e)}), 500


# eHub 處理
@app.route("/api/save_csv", methods=["POST", "OPTIONS"])
def save_csv():
    if request.method == "OPTIONS":
        return jsonify({"status": "ok"}), 200

    data = request.get_json(silent=True) or {}
    content = data.get("content", "")

    from io import StringIO
    df_all = pd.read_csv(StringIO(content), dtype=str).fillna("")

    # 先處理 Item → 一律補成4位數
    if "PO Item 採購單項次" in df_all.columns:
        df_all["PO Item 採購單項次"] = (
            df_all["PO Item 採購單項次"]
            .str.strip()
            .apply(lambda x: str(int(float(x))) if x.replace('.', '', 1).isdigit() else x)
            .apply(lambda x: x.zfill(4) if x.isdigit() else x)
        )

    # 確認有必要欄位
    if "PO NO 採購單號碼" not in df_all.columns:
        return jsonify({"status": "error", "msg": "❌ 缺少 PO NO 採購單號碼 欄位！"}), 400

    # 抓出所有不同的 PO NO
    unique_po_nos = df_all["PO NO 採購單號碼"].dropna().unique()

    # ✅ 第一步：分群儲存 uploads/{po_no}.csv
    saved_files = []
    for po_no in unique_po_nos:
        po_no_clean = str(po_no).strip()
        group_df = df_all[df_all["PO NO 採購單號碼"] == po_no_clean]

        upload_path = f"uploads/{po_no_clean}.csv"
        group_df.to_csv(upload_path, index=False, encoding="utf-8-sig")

        saved_files.append({
            "po_no": po_no_clean,
            "rows": len(group_df),
            "file": upload_path
        })
        print(f"✅ 已儲存 {upload_path} ({len(group_df)} 筆資料)")

    # ✅ 第二步：載入 Buyer_detail.csv (比對用)
    df_buyer = pd.read_csv(BUYER_FILE, encoding="utf-8-sig", dtype=str, on_bad_lines="skip").fillna("")
    df_buyer["PO No."] = df_buyer["PO No."].str.strip()
    df_buyer["Item"] = (
        df_buyer["Item"]
        .str.replace(r"\.0$", "", regex=True)
        .str.strip()
        .apply(lambda x: x.zfill(4) if x.isdigit() else x)
    )

    def clean_name(x: str) -> str:
        return str(x).replace("\n", "").replace("\r", "").replace("<br>", "").strip()

    df_buyer["品項_clean"] = df_buyer["品項"].apply(clean_name)
    buyer_id_lookup = {
        (row["PO No."], row["Item"]): row.get("Id", "")
        for _, row in df_buyer.iterrows()
    }
    # ✅ 最後要回傳的結果，依照 po_no 分組
    all_group_results = []

    # ✅ 第三步：逐一打開 uploads/{po_no}.csv 去比對
    for file_info in saved_files:
        po_no = file_info["po_no"]
        csv_path = file_info["file"]

        # 打開剛剛儲存的這個 po_no CSV
        df_po = pd.read_csv(csv_path, encoding="utf-8-sig", dtype=str).fillna("")
        df_po["PO Item 採購單項次"] = df_po["PO Item 採購單項次"].str.zfill(4)

        # 這個 po_no 相關的 Buyer_detail 資料
        buyer_related = df_buyer[df_buyer["PO No."].str.contains(po_no, regex=False, na=False)].copy()

        matched_list = []
        conflict_list = []

        # 逐筆比對
        for _, row in df_po.iterrows():
            item = row["PO Item 採購單項次"]
            desc = clean_name(row.get("Description 品名", ""))
            delivery = row["Delivery Date 廠商承諾交期"]
            qty = row["SOD Qty 廠商承諾數量"]

            # 先用品項比對
            same_name_match = buyer_related[buyer_related["品項_clean"] == desc]

            if not same_name_match.empty:
                buyer_row = same_name_match.iloc[0]
                # ✅ 品項相同 → 檢查 Item 是否一致
                buyer_item = same_name_match.iloc[0]["Item"]
                buyer_desc = clean_name(same_name_match.iloc[0]["品項"])
                buyer_id = buyer_row.get("Id", "")

                # 更新交期 & 數量
                df_buyer.loc[same_name_match.index, "Delivery Date 廠商承諾交期"] = delivery
                df_buyer.loc[same_name_match.index, "SOD Qty 廠商承諾數量"] = qty

                if buyer_item == item:
                    buyer_id = buyer_id_lookup.get((po_no, buyer_item), "")
                    # ✅ 品項 & Item 都一致
                    matched_list.append({
                        "id": buyer_id,
                        "po_no": po_no,
                        "item": item,
                        "buyer_description": buyer_desc,
                        "po_description": desc or buyer_desc,
                        "delivery_date": delivery,
                        "sod_qty": qty,
                        "status": "✅ 相同",
                        "diff_type": "none"
                    })
                else:
                    # ⚠️ 品項相同，但 Item 不同
                    buyer_id = buyer_id_lookup.get((po_no, buyer_item), "")
                    conflict_list.append({
                        "id": '',
                        "po_no": po_no,
                        "item": item,
                        "buyer_description": buyer_desc,
                        "po_description": desc or buyer_desc,
                        "old_item": buyer_item,
                        "delivery_date": delivery,
                        "sod_qty": qty,
                        "status": f"⚠️ Item 不相同 (舊 {buyer_item} → 新 {item})",
                        "diff_type": "item"
                    })

            else:
                # 改用 Item 比對
                buyer_match_by_item = buyer_related[buyer_related["Item"] == item]

                if not buyer_match_by_item.empty:
                    # ✅ Item 相同但品項不同 → 品名不相同
                    buyer_desc = clean_name(buyer_match_by_item.iloc[0]["品項"])
                    df_buyer.loc[buyer_match_by_item.index, "Delivery Date 廠商承諾交期"] = delivery
                    df_buyer.loc[buyer_match_by_item.index, "SOD Qty 廠商承諾數量"] = qty
                    buyer_id = buyer_id_lookup.get((po_no, item), "")
                    conflict_list.append({
                        "id": buyer_id,
                        "po_no": po_no,
                        "item": item,
                        "buyer_description": buyer_desc,
                        "po_description": desc,
                        "delivery_date": delivery,
                        "sod_qty": qty,
                        "status": "⚠️ 品名不相同",
                        "diff_type": "desc"
                    })
                else:
                    # ❌ 完全沒找到
                    buyer_id = ''
                    conflict_list.append({
                        "id": buyer_id,
                        "po_no": po_no,
                        "item": item,
                        "buyer_description": None,
                        "po_description": desc,
                        "delivery_date": delivery,
                        "sod_qty": qty,
                        "status": "⚠️ Buyer_detail 沒有這筆資料",
                        "diff_type": "missing"
                    })

        # 把這個 po_no 的結果存進總結果
        all_group_results.append({
            "po_no": po_no,
            "matched": matched_list,
            "conflict": conflict_list
        })
    print(all_group_results)
    # ✅ 最後一次性回傳，前端可以依照 po_no 分組顯示
    return jsonify({
        "status": "ok",
        "groups": all_group_results,
        "saved_files": saved_files
    })


from difflib import SequenceMatcher

def is_po_in_record(row_po_str, target_po):
    """檢查 PO 是否在記錄中（支援 <br /> 分隔的多個 PO）"""
    po_list = re.split(r"<br\s*/?>", str(row_po_str))
    po_list = [po.strip() for po in po_list if po.strip()]
    return target_po.strip() in po_list

def fuzzy_in(text, keyword):
    """模糊比對關鍵字是否在文字中"""
    return keyword.strip() in str(text).strip()

@app.route("/api/save_override_all", methods=["POST"])
def save_override_all():
    """
    Version 31 - 品名優先比對邏輯
    改進：優先以品名相似度為主要比對依據，Item 作為次要參考
    優先順序：同 PO 內的品名高度相似 > Item 相同 > 品名中度相似 > 新增
    """
    data = request.get_json()
    rows = data.get("rows", [])
    confirm_override = data.get("confirm_override", False)  # 是否已確認覆蓋

    if not rows:
        return jsonify({"status": "error", "msg": "❌ 沒有收到任何資料"}), 400

    def clean_text(x):
        """清理文字：移除換行和空白"""
        return str(x).replace("\n", "").replace("\r", "").strip()
    
    def calculate_similarity(text1, text2):
        """計算兩個字串的相似度 (0-100)"""
        text1_clean = clean_text(text1).lower()
        text2_clean = clean_text(text2).lower()
        return SequenceMatcher(None, text1_clean, text2_clean).ratio() * 100
    
    # 處理 pandas int64 轉換問題
    def convert_to_json_serializable(obj):
        """將 pandas 的特殊類型轉換為可序列化的類型"""
        if isinstance(obj, dict):
            return {k: convert_to_json_serializable(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_to_json_serializable(item) for item in obj]
        elif hasattr(obj, 'item'):  # numpy/pandas 數值類型
            return obj.item()
        elif pd.isna(obj):  # NaN 值
            return None
        else:
            return obj

    # 讀取並處理資料
    df_buyer = pd.read_csv(BUYER_FILE, encoding="utf-8-sig", dtype=str, on_bad_lines="skip").fillna("")
    df_buyer["PO No."] = df_buyer["PO No."].str.strip()
    df_buyer["Item"] = (
        df_buyer["Item"]
        .str.replace(r"\.0$", "", regex=True)
        .str.strip()
        .apply(lambda x: x.zfill(4) if x.isdigit() else x)
    )
    
    # 🔴 重要：建立一個只包含狀態為 V 的資料索引
    df_active = df_buyer[df_buyer["開單狀態"] == "V"].copy()
    print(f"總資料筆數: {len(df_buyer)}, 有效資料(狀態=V): {len(df_active)}")

    updated_count = 0
    inserted_count = 0
    failed = []
    need_confirm_items = []  # 需要確認的項目
    matching_output = []  # 比對結果輸出

    new_item = ''
    epr_no = 0
    po_no_new = ''
    
    # 輸出開始訊息
    print("\n" + "="*80)
    print("開始處理資料比對 (Version 31 - 品名優先)")
    print("="*80)

    for row_num, row in enumerate(rows, 1):
        id_ = row.get("id", "").strip()
        po_no_new = row.get("po_no", "").strip()
        item_new = row.get("item", "").strip()
        
        # 確保 item 格式一致（4位數）
        if item_new.isdigit():
            item_new = item_new.zfill(4)
            
        new_delivery = row.get("delivery_date", "").strip()
        new_qty = row.get("sod_qty", "").strip()
        new_desc = row.get("po_description", "").strip()
        new_desc_clean = clean_text(new_desc)

        target_idx = None
        match_reason = ""
        
        # 輸出當前處理項目
        print(f"\n[第 {row_num} 筆]")
        print(f"  新資料 => PO: {po_no_new}, Item: {item_new}")
        print(f"  品名: {new_desc[:50]}{'...' if len(new_desc) > 50 else ''}")
        
        # 🔍 Version 31 核心改變：先找品名相似度，再考慮 Item
        # 步驟1：先在同 PO 內找資料（只找狀態為 V 的）
        po_group = df_active[df_active["PO No."].apply(lambda x: is_po_in_record(x, po_no_new))]
        
        if not po_group.empty:
            print(f"     在 PO {po_no_new} 找到 {len(po_group)} 筆資料")
            
            # 🔥 Version 31：計算所有項目的品名相似度
            similarity_scores = []
            for idx, row_data in po_group.iterrows():
                existing_desc = row_data["品項"]
                existing_item = row_data["Item"]
                similarity = calculate_similarity(new_desc, existing_desc)
                similarity_scores.append({
                    'index': idx,
                    'item': existing_item,
                    'desc': existing_desc,
                    'similarity': similarity,
                    'item_match': (existing_item == item_new),  # 記錄 Item 是否相同
                    'delivery_date': row_data.get("Delivery Date 廠商承諾交期", "")  # 加入交期資訊
                })
            
            # 🔴 Version 31 改進：處理相同 Item 的多筆資料
            # 如果有多筆完全相同的 Item，選擇交期最新的
            item_matches = [s for s in similarity_scores if s['item_match']]
            if len(item_matches) > 1:
                print(f"     發現 {len(item_matches)} 筆相同的 Item {item_new}")
                
                # 將交期轉換為可比較的格式並排序
                for match in item_matches:
                    try:
                        # 嘗試解析日期（支援 YYYY/MM/DD 格式）
                        date_str = match['delivery_date'].strip()
                        if date_str:
                            # 移除可能的時間部分，只保留日期
                            date_str = date_str.split(' ')[0]
                            # 轉換斜線為破折號以便解析
                            date_str = date_str.replace('/', '-')
                            match['parsed_date'] = date_str
                        else:
                            match['parsed_date'] = '1900-01-01'  # 空日期設為最早
                    except:
                        match['parsed_date'] = '1900-01-01'
                    
                    print(f"       - Index {match['index']}: 交期 {match['delivery_date']}")
                
                # 按日期排序，選擇最新的
                item_matches.sort(key=lambda x: x.get('parsed_date', '1900-01-01'), reverse=True)
                newest_match = item_matches[0]
                print(f"     => 選擇最新交期的資料: Index {newest_match['index']} (交期: {newest_match['delivery_date']})")
                
                # 將最新的資料移到 similarity_scores 的最前面
                similarity_scores = [s for s in similarity_scores if not s['item_match']]
                similarity_scores.insert(0, newest_match)
            else:
                # 排序：先按相似度排序，相似度相同時 Item 相同的優先
                similarity_scores.sort(key=lambda x: (x['similarity'], x['item_match']), reverse=True)
            
            # 輸出相似度排名（除錯用）
            print(f"     品名相似度排名：")
            for i, score in enumerate(similarity_scores[:3], 1):  # 顯示前3名
                item_marker = " [Item相同]" if score['item_match'] else ""
                print(f"       {i}. Item {score['item']}: {score['similarity']:.1f}%{item_marker} - {score['desc'][:30]}...")
            
            # 取得最高相似度的項目
            best_match = similarity_scores[0]
            best_similarity = best_match['similarity']
            best_idx = best_match['index']
            best_item = best_match['item']
            best_desc = best_match['desc']
            
            # 🎯 根據相似度和 Item 是否相同來決定處理方式
            if best_similarity >= 95:  # 品名幾乎完全相同
                target_idx = best_idx
                if best_item == item_new:
                    match_reason = "品名完全相同+Item相同"
                    print(f"  ✅ 品名完全相同且 Item 相同（相似度 {best_similarity:.1f}%） => 直接更新")
                else:
                    match_reason = f"品名完全相同(Item:{best_item}→{item_new})"
                    print(f"  ⚠️ 品名完全相同但 Item 不同（{best_item} → {item_new}）")
                    print(f"     品名相似度: {best_similarity:.1f}%")
                    
                    if not confirm_override:
                        print(f"     需要確認是否要更新 Item")
                        
                        need_confirm_items.append({
                            "row": row_num,
                            "po_no": po_no_new,
                            "new_item": item_new,
                            "new_desc": new_desc,
                            "old_item": best_item,
                            "old_desc": best_desc,
                            "similarity": round(best_similarity, 1),
                            "new_delivery": new_delivery,
                            "new_qty": new_qty,
                            "target_index": int(best_idx),
                            "reason": "品名相同但Item不同",
                            "action_type": "update_item_change"
                        })
                        
                        matching_output.append({
                            "row": row_num,
                            "po": po_no_new,
                            "item": f"{best_item}→{item_new}",
                            "match": match_reason,
                            "action": "待確認",
                            "note": f"品名相同但Item不同"
                        })
                        continue
                    else:
                        print(f"     => 已確認，將更新 Item")
                        
            elif best_similarity >= 80:  # 品名高度相似
                target_idx = best_idx
                if best_item == item_new:
                    match_reason = f"品名高度相似+Item相同({best_similarity:.0f}%)"
                    print(f"  ✅ 品名高度相似且 Item 相同（{best_similarity:.1f}%） => 直接更新")
                else:
                    match_reason = f"品名高度相似(Item:{best_item}→{item_new})"
                    print(f"  ⚠️ 品名高度相似但 Item 不同（{best_item} → {item_new}）")
                    print(f"     品名相似度: {best_similarity:.1f}%")
                    print(f"     原品名: {best_desc[:40]}...")
                    print(f"     新品名: {new_desc[:40]}...")
                    
                    if not confirm_override:
                        print(f"     需要確認是否要更新")
                        
                        need_confirm_items.append({
                            "row": row_num,
                            "po_no": po_no_new,
                            "new_item": item_new,
                            "new_desc": new_desc,
                            "old_item": best_item,
                            "old_desc": best_desc,
                            "similarity": round(best_similarity, 1),
                            "new_delivery": new_delivery,
                            "new_qty": new_qty,
                            "target_index": int(best_idx),
                            "reason": "品名高度相似但Item不同",
                            "action_type": "update_high_similarity"
                        })
                        
                        matching_output.append({
                            "row": row_num,
                            "po": po_no_new,
                            "item": f"{best_item}→{item_new}",
                            "match": match_reason,
                            "action": "待確認",
                            "note": f"品名相似{best_similarity:.0f}%"
                        })
                        continue
                    else:
                        print(f"     => 已確認，將更新")
                        
            elif best_similarity >= 60:  # 品名中度相似
                # 檢查是否有 Item 相同的項目
                item_match = next((s for s in similarity_scores if s['item_match']), None)
                
                if item_match and item_match['similarity'] >= 40:
                    # 如果有 Item 相同且相似度不是太低，優先選擇 Item 相同的
                    target_idx = item_match['index']
                    match_reason = f"Item相同+品名相似({item_match['similarity']:.0f}%)"
                    print(f"  ⚠️ 找到 Item 相同的項目，品名相似度 {item_match['similarity']:.1f}%")
                    print(f"     原品名: {item_match['desc'][:40]}...")
                    print(f"     新品名: {new_desc[:40]}...")
                    
                    if not confirm_override:
                        print(f"     需要確認是否要更新")
                        
                        need_confirm_items.append({
                            "row": row_num,
                            "po_no": po_no_new,
                            "new_item": item_new,
                            "new_desc": new_desc,
                            "old_item": item_new,
                            "old_desc": item_match['desc'],
                            "similarity": round(item_match['similarity'], 1),
                            "new_delivery": new_delivery,
                            "new_qty": new_qty,
                            "target_index": int(item_match['index']),
                            "reason": "Item相同但品名差異較大",
                            "action_type": "update_medium_similarity"
                        })
                        
                        matching_output.append({
                            "row": row_num,
                            "po": po_no_new,
                            "item": item_new,
                            "match": match_reason,
                            "action": "待確認",
                            "note": f"品名差異{item_match['similarity']:.0f}%"
                        })
                        continue
                    else:
                        print(f"     => 已確認，將更新")
                else:
                    # 品名中度相似，Item 不同
                    target_idx = best_idx
                    match_reason = f"品名中度相似({best_similarity:.0f}%)"
                    print(f"  ⚠️ 品名中度相似，Item 不同（{best_item} → {item_new}）")
                    print(f"     相似度: {best_similarity:.1f}%")
                    print(f"     原品名: {best_desc[:40]}...")
                    print(f"     新品名: {new_desc[:40]}...")
                    
                    if not confirm_override:
                        print(f"     需要確認")
                        
                        need_confirm_items.append({
                            "row": row_num,
                            "po_no": po_no_new,
                            "new_item": item_new,
                            "new_desc": new_desc,
                            "old_item": best_item,
                            "old_desc": best_desc,
                            "similarity": round(best_similarity, 1),
                            "new_delivery": new_delivery,
                            "new_qty": new_qty,
                            "target_index": int(best_idx),
                            "reason": "品名中度相似",
                            "action_type": "update_medium_similarity",
                            "warning": True
                        })
                        
                        matching_output.append({
                            "row": row_num,
                            "po": po_no_new,
                            "item": f"{best_item}→{item_new}",
                            "match": match_reason,
                            "action": "待確認",
                            "note": f"品名中度相似"
                        })
                        continue
                    else:
                        print(f"     => 已確認，將更新")
                        
            else:  # 相似度 < 60%
                # 檢查是否有 Item 完全相同的
                item_match = next((s for s in similarity_scores if s['item_match']), None)
                
                if item_match:
                    # Item 相同但品名相似度低
                    print(f"  ⚠️ 找到 Item 相同但品名差異很大（相似度 {item_match['similarity']:.1f}%）")
                    print(f"     原品名: {item_match['desc'][:40]}...")
                    print(f"     新品名: {new_desc[:40]}...")
                    
                    if not confirm_override:
                        print(f"     ⚠️⚠️ 品名差異很大！需要確認")
                        
                        need_confirm_items.append({
                            "row": row_num,
                            "po_no": po_no_new,
                            "new_item": item_new,
                            "new_desc": new_desc,
                            "old_item": item_new,
                            "old_desc": item_match['desc'],
                            "similarity": round(item_match['similarity'], 1),
                            "new_delivery": new_delivery,
                            "new_qty": new_qty,
                            "target_index": int(item_match['index']),
                            "reason": "Item相同但品名完全不同",
                            "action_type": "update_low_similarity",
                            "warning": True,
                            "critical": True
                        })
                        
                        matching_output.append({
                            "row": row_num,
                            "po": po_no_new,
                            "item": item_new,
                            "match": f"Item相同(相似度{item_match['similarity']:.0f}%)",
                            "action": "待確認",
                            "note": f"❌品名差異極大"
                        })
                        continue
                    else:
                        target_idx = item_match['index']
                        match_reason = f"Item相同(品名差異大)"
                        print(f"     => 已確認，將強制更新")
                else:
                    # 沒有任何匹配，建議新增
                    target_idx = None
        
        # 步驟2：如果在同 PO 內找不到匹配，詢問是否新增
        if target_idx is None and not po_group.empty:
            print(f"  ⚠️  在 PO {po_no_new} 內找不到相似的品名或相同的 Item")
            print(f"     新Item: {item_new}, 新品名: {new_desc[:40]}...")
            
            if not confirm_override:
                print(f"     需要確認是否要新增為新項目")
                
                # 列出現有的項目供參考
                existing_items = []
                for score in similarity_scores[:5]:  # 顯示前5個相似度最高的
                    existing_items.append({
                        "item": score['item'],
                        "desc": score['desc'][:50],
                        "similarity": round(score['similarity'], 1)
                    })
                
                need_confirm_items.append({
                    "row": row_num,
                    "po_no": po_no_new,
                    "new_item": item_new,
                    "new_desc": new_desc,
                    "existing_items": existing_items,
                    "new_delivery": new_delivery,
                    "new_qty": new_qty,
                    "reason": "無相似項目",
                    "action_type": "add_new"
                })
                
                matching_output.append({
                    "row": row_num,
                    "po": po_no_new,
                    "item": item_new,
                    "match": "無匹配",
                    "action": "待確認",
                    "note": "建議新增"
                })
                continue
            else:
                print(f"     => 已確認，將新增為新項目")
        
        # 步驟3：其他比對方式（ID、模糊比對等）- 只找狀態為 V 的
        if target_idx is None and id_:
            candidates = df_active[df_active["Id"] == id_].copy()
            
            if len(candidates) > 1:
                candidates["品項_clean"] = candidates["品項"].apply(clean_text)
                exact_match = candidates[candidates["品項_clean"] == new_desc_clean]
                if len(exact_match) == 1:
                    target_idx = exact_match.index[0]
                    match_reason = "ID+品項匹配"
                    print(f"  ✅ ID+品項匹配 => 更新資料 (狀態=V)")
            elif len(candidates) == 1:
                target_idx = candidates.index[0]
                match_reason = "ID匹配"
                print(f"  ✅ ID匹配 => 更新資料 (狀態=V)")

        # 步驟4：PO + 品項模糊比對 - 只找狀態為 V 的
        if target_idx is None:
            po_match = df_active[df_active["PO No."].apply(lambda x: is_po_in_record(x, po_no_new))]
            po_match = po_match[po_match["品項"].apply(lambda x: fuzzy_in(x, new_desc_clean))]

            if not po_match.empty:
                target_idx = po_match.index[0]
                match_reason = "PO+品項模糊匹配"
                print(f"  ✅ PO+品項模糊匹配 => 更新資料 (狀態=V)")

        # 📝 如果找到匹配項目，執行更新
        if target_idx is not None:
            # 記錄原始值（用於輸出）
            old_values = {
                "po": df_buyer.at[target_idx, "PO No."],
                "item": df_buyer.at[target_idx, "Item"],
                "delivery": df_buyer.at[target_idx, "Delivery Date 廠商承諾交期"],
                "qty": df_buyer.at[target_idx, "SOD Qty 廠商承諾數量"],
                "desc": df_buyer.at[target_idx, "品項"]
            }
            
            # 執行更新
            df_buyer.at[target_idx, "PO No."] = po_no_new
            df_buyer.at[target_idx, "Item"] = item_new
            df_buyer.at[target_idx, "Delivery Date 廠商承諾交期"] = new_delivery
            df_buyer.at[target_idx, "SOD Qty 廠商承諾數量"] = new_qty
            if new_desc:
                df_buyer.at[target_idx, "品項"] = new_desc
            updated_count += 1
            
            # 輸出變更詳情
            if old_values["po"] != po_no_new:
                print(f"     PO變更: {old_values['po']} → {po_no_new}")
            if old_values["item"] != item_new:
                print(f"     Item變更: {old_values['item']} → {item_new}")
            if old_values["delivery"] != new_delivery:
                print(f"     交期變更: {old_values['delivery']} → {new_delivery}")
            if old_values["qty"] != new_qty:
                print(f"     數量變更: {old_values['qty']} → {new_qty}")
            
            matching_output.append({
                "row": row_num,
                "po": po_no_new,
                "item": item_new if old_values["item"] == item_new else f"{old_values['item']}→{item_new}",
                "match": match_reason,
                "action": "已更新",
                "note": "品名已變更" if old_values["desc"] != new_desc else ""
            })
            continue

        # 🆕 如果都找不到 → 新增資料（但要檢查 PO 是否存在於狀態 V 的資料中）
        po_matches = df_active[df_active["PO No."].apply(lambda x: is_po_in_record(x, po_no_new))]
        if po_matches.empty:
            # 再檢查是否有狀態為 X 的相同 PO
            po_cancelled = df_buyer[
                (df_buyer["開單狀態"] == "X") & 
                (df_buyer["PO No."].apply(lambda x: is_po_in_record(x, po_no_new)))
            ]
            
            if not po_cancelled.empty:
                print(f"  ⚠️  找到 PO {po_no_new} 但狀態為 X（已取消），無法更新")
                failed.append({
                    "row": row_num,
                    "po_no": po_no_new,
                    "item": item_new,
                    "reason": f"PO {po_no_new} 狀態為 X（已取消）"
                })
                
                matching_output.append({
                    "row": row_num,
                    "po": po_no_new,
                    "item": item_new,
                    "match": "PO已取消",
                    "action": "失敗",
                    "note": "狀態為X"
                })
                continue
            else:
                # 🔴 Version 31：PO 完全不存在的情況
                print(f"  ❌ 360表單無此項目：PO {po_no_new}")
                
                failed.append({
                    "row": row_num,
                    "po_no": po_no_new,
                    "item": item_new,
                    "reason": "360表單無此項目"
                })
                
                matching_output.append({
                    "row": row_num,
                    "po": po_no_new,
                    "item": item_new,
                    "match": "無PO",
                    "action": "失敗",
                    "note": "360表單無此項目"
                })
                continue
        
        # 🆔 推測 Id（取首筆）
        possible_ids = po_matches["Id"].dropna().unique().tolist()
        id_ = possible_ids[0] if possible_ids else row.get("id") or row.get("Id", "")
        id_ = str(id_).strip()

        # 👤 取同組第一筆的資訊
        user = po_matches["User"].iloc[0] if not po_matches.empty else ""
        epr_no = po_matches["ePR No."].iloc[0] if not po_matches.empty else ""
        wbs_no = po_matches["WBS"].iloc[0] if not po_matches.empty else ""
        need_day_no = po_matches["需求日"].iloc[0] if not po_matches.empty else ""

        print(f"  🆕 找不到匹配項目 => 新增資料")
        print(f"     新增到 ePR No.: {epr_no}")

        # ➕ 新增新的一筆資料
        new_row = {
            "Id": id_,
            "開單狀態": "V",
            "交貨驗證": "",
            "User": user,
            "ePR No.": epr_no,
            "PO No.": po_no_new,
            "Item": item_new,
            "品項": new_desc,
            "規格": "",
            "數量": new_qty,
            "總數": new_qty,
            "單價": "",
            "總價": "",
            "備註": "",
            "字數": "",
            "isEditing": "False",
            "backup": "{}",
            "_alertedItemLimit": "",
            "Delivery Date 廠商承諾交期": new_delivery,
            "SOD Qty 廠商承諾數量": new_qty,
            "驗收數量": "",
            "拒收數量": "",
            "發票月份": "",
            "WBS": wbs_no,
            "需求日": need_day_no
        }

        # 📌 找這個 id 的最後一筆位置
        same_id_idx = df_buyer[df_buyer["Id"] == id_].index
        insert_pos = same_id_idx[-1] + 1 if len(same_id_idx) > 0 else len(df_buyer)

        # ✨ 插入到原 df_buyer 中指定位置
        df_buyer = pd.concat([
            df_buyer.iloc[:insert_pos],
            pd.DataFrame([new_row]),
            df_buyer.iloc[insert_pos:]
        ], ignore_index=True)
        
        new_item = '新增物件'
        inserted_count += 1
        
        matching_output.append({
            "row": row_num,
            "po": po_no_new,
            "item": item_new,
            "match": "無匹配",
            "action": "已新增",
            "note": f"ePR:{epr_no}"
        })

    # 輸出比對結果摘要
    print("\n" + "="*80)
    print("比對結果摘要 (Version 31 - 品名優先)")
    print("="*80)
    print(f"總處理筆數: {len(rows)}")
    print(f"更新筆數: {updated_count}")
    print(f"新增筆數: {inserted_count}")
    print(f"失敗筆數: {len(failed)}")
    print(f"待確認筆數: {len(need_confirm_items)}")
    
    # 輸出詳細比對表格
    if matching_output:
        print("\n詳細比對結果:")
        print("-"*80)
        print(f"{'筆數':<5} {'PO No.':<15} {'Item':<10} {'比對方式':<20} {'處理':<8} {'備註'}")
        print("-"*80)
        for item in matching_output:
            print(f"{item['row']:<5} {item['po']:<15} {item['item']:<10} {item['match']:<20} {item['action']:<8} {item['note']}")
    
    print("="*80 + "\n")

    # 如果有需要確認的項目，回傳給前端
    if need_confirm_items and not confirm_override:
        # 檢查是否有關鍵確認項（品名完全不同）
        critical_items = [item for item in need_confirm_items if item.get("critical", False)]
        warning_items = [item for item in need_confirm_items if item.get("warning", False)]
        
        # 根據不同的確認原因和動作類型，產生不同的訊息
        action_types = set(item.get("action_type", "") for item in need_confirm_items)
        
        if critical_items:
            msg = f"⚠️ 發現 {len(critical_items)} 個品名完全不同的項目需要特別確認"
        elif "update_low_similarity" in action_types:
            msg = f"❌ 發現 {len(need_confirm_items)} 個品名相似度極低的項目需要確認"
        elif "update_item_change" in action_types:
            msg = f"發現 {len(need_confirm_items)} 個品名相同但Item不同的項目需要確認"
        elif "add_new" in action_types:
            msg = f"發現 {len(need_confirm_items)} 個項目可能需要新增"
        else:
            msg = f"發現 {len(need_confirm_items)} 個需要確認的項目"
        
        return jsonify(convert_to_json_serializable({
            "status": "confirm_needed",
            "msg": msg,
            "items": need_confirm_items,
            "updated": updated_count,
            "inserted": inserted_count,
            "matching_output": matching_output,
            "has_critical": len(critical_items) > 0,
            "has_warning": len(warning_items) > 0
        }))

    # 儲存回檔案
    df_buyer.to_csv(BUYER_FILE, index=False, encoding="utf-8-sig")
    
    # 刪除暫存檔案
    if po_no_new:
        temp_file = f"uploads/{po_no_new}.csv"
        if os.path.exists(temp_file):
            os.remove(temp_file)
    
    # 🔴 檢查是否所有項目都失敗且原因都是「360表單無此項目」
    if failed and len(failed) == len(rows):
        all_not_found = all(f.get("reason") == "360表單無此項目" for f in failed)
        if all_not_found:
            return jsonify(convert_to_json_serializable({
                "status": "not_found",
                "msg": "❌ 360表單無此項目",
                "failed": failed,
                "matching_output": matching_output
            }))
    
    # 回傳結果
    if new_item == '新增物件':
        return jsonify(convert_to_json_serializable({
            "status": "ok",
            "msg": f"有新增的物件(item)需要維護，ePR No. 單號為 {epr_no}。更新 {updated_count} 筆，新增 {inserted_count} 筆",
            "failed": failed,
            "matching_output": matching_output
        }))
    else:
        return jsonify(convert_to_json_serializable({
            "status": "ok",
            "msg": f"✅ 更新 {updated_count} 筆，新增 {inserted_count} 筆",
            "failed": failed,
            "matching_output": matching_output
        }))
    
    

# from difflib import SequenceMatcher

# def is_po_in_record(row_po_str, target_po):
#     """檢查 PO 是否在記錄中（支援 <br /> 分隔的多個 PO）"""
#     po_list = re.split(r"<br\s*/?>", str(row_po_str))
#     po_list = [po.strip() for po in po_list if po.strip()]
#     return target_po.strip() in po_list

# def fuzzy_in(text, keyword):
#     """模糊比對關鍵字是否在文字中"""
#     return keyword.strip() in str(text).strip()

# @app.route("/api/save_override_all", methods=["POST"])
# def save_override_all():
#     """
#     Version 27 - 批次覆蓋更新功能
#     優先順序：同 PO 內的 Item 匹配 > 品名相似 > 新增
#     """
#     data = request.get_json()
#     rows = data.get("rows", [])
#     confirm_override = data.get("confirm_override", False)  # 是否已確認覆蓋

#     if not rows:
#         return jsonify({"status": "error", "msg": "❌ 沒有收到任何資料"}), 400

#     def clean_text(x):
#         """清理文字：移除換行和空白"""
#         return str(x).replace("\n", "").replace("\r", "").strip()
    
#     def calculate_similarity(text1, text2):
#         """計算兩個字串的相似度 (0-100)"""
#         text1_clean = clean_text(text1).lower()
#         text2_clean = clean_text(text2).lower()
#         return SequenceMatcher(None, text1_clean, text2_clean).ratio() * 100
    
#     # 處理 pandas int64 轉換問題
#     def convert_to_json_serializable(obj):
#         """將 pandas 的特殊類型轉換為可序列化的類型"""
#         if isinstance(obj, dict):
#             return {k: convert_to_json_serializable(v) for k, v in obj.items()}
#         elif isinstance(obj, list):
#             return [convert_to_json_serializable(item) for item in obj]
#         elif hasattr(obj, 'item'):  # numpy/pandas 數值類型
#             return obj.item()
#         elif pd.isna(obj):  # NaN 值
#             return None
#         else:
#             return obj

#     # 讀取並處理資料
#     df_buyer = pd.read_csv(BUYER_FILE, encoding="utf-8-sig", dtype=str, on_bad_lines="skip").fillna("")
#     df_buyer["PO No."] = df_buyer["PO No."].str.strip()
#     df_buyer["Item"] = (
#         df_buyer["Item"]
#         .str.replace(r"\.0$", "", regex=True)
#         .str.strip()
#         .apply(lambda x: x.zfill(4) if x.isdigit() else x)
#     )
    
#     # 🔴 重要：建立一個只包含狀態為 V 的資料索引
#     df_active = df_buyer[df_buyer["開單狀態"] == "V"].copy()
#     print(f"總資料筆數: {len(df_buyer)}, 有效資料(狀態=V): {len(df_active)}")

#     updated_count = 0
#     inserted_count = 0
#     failed = []
#     need_confirm_items = []  # 需要確認的項目
#     matching_output = []  # 比對結果輸出

#     new_item = ''
#     epr_no = 0
#     po_no_new = ''
    
#     # 輸出開始訊息
#     print("\n" + "="*80)
#     print("開始處理資料比對 (Version 27)")
#     print("="*80)

#     for row_num, row in enumerate(rows, 1):
#         id_ = row.get("id", "").strip()
#         po_no_new = row.get("po_no", "").strip()
#         item_new = row.get("item", "").strip()
        
#         # 確保 item 格式一致（4位數）
#         if item_new.isdigit():
#             item_new = item_new.zfill(4)
            
#         new_delivery = row.get("delivery_date", "").strip()
#         new_qty = row.get("sod_qty", "").strip()
#         new_desc = row.get("po_description", "").strip()
#         new_desc_clean = clean_text(new_desc)

#         target_idx = None
#         match_reason = ""
        
#         # 輸出當前處理項目
#         print(f"\n[第 {row_num} 筆]")
#         print(f"  新資料 => PO: {po_no_new}, Item: {item_new}")
#         print(f"  品名: {new_desc[:50]}{'...' if len(new_desc) > 50 else ''}")
        
#         # 🔍 在相同 PO 內比對 Item 和品名
#         # 步驟1：先在同 PO 內找資料（只找狀態為 V 的）
#         po_group = df_active[df_active["PO No."].apply(lambda x: is_po_in_record(x, po_no_new))]
        
#         if not po_group.empty:
#             print(f"     在 PO {po_no_new} 找到 {len(po_group)} 筆資料")
            
#             # 1a. 先找 Item 完全相同的
#             item_match = po_group[po_group["Item"] == item_new]
#             if not item_match.empty:
#                 target_idx = item_match.index[0]
#                 old_desc = df_buyer.at[target_idx, "品項"]
                
#                 # 檢查品名相似度
#                 similarity = calculate_similarity(new_desc, old_desc)
                
#                 if similarity >= 80:  # 品名相似度高，可以直接更新
#                     match_reason = "PO+Item匹配(品名相似)"
#                     print(f"  ✅ PO+Item 匹配，品名相似度 {similarity:.1f}% => 更新資料")
#                 elif similarity >= 30:  # 品名有差異但還算相關，需要確認
#                     match_reason = "PO+Item匹配(品名略有差異)"
#                     print(f"  ⚠️  PO+Item 匹配但品名有差異（相似度 {similarity:.1f}%）")
#                     print(f"     原品名: {old_desc[:40]}...")
#                     print(f"     新品名: {new_desc[:40]}...")
                    
#                     if not confirm_override:
#                         print(f"     需要確認是否要覆蓋")
                        
#                         need_confirm_items.append({
#                             "row": row_num,
#                             "po_no": po_no_new,
#                             "new_item": item_new,
#                             "new_desc": new_desc,
#                             "old_item": item_new,
#                             "old_desc": old_desc,
#                             "similarity": round(similarity, 1),
#                             "new_delivery": new_delivery,
#                             "new_qty": new_qty,
#                             "target_index": int(target_idx),
#                             "reason": "品名有差異",
#                             "action_type": "update_different_desc"
#                         })
                        
#                         matching_output.append({
#                             "row": row_num,
#                             "po": po_no_new,
#                             "item": item_new,
#                             "match": match_reason,
#                             "action": "待確認",
#                             "note": f"品名差異(相似度{similarity:.0f}%)"
#                         })
#                         continue
#                     else:
#                         print(f"     => 已確認，將更新品名")
#                 else:  # 相似度 < 30%，品名完全不同，可能是錯誤的比對
#                     print(f"  ❌ PO+Item 匹配但品名完全不同（相似度僅 {similarity:.1f}%）")
#                     print(f"     原品名: {old_desc[:40]}...")
#                     print(f"     新品名: {new_desc[:40]}...")
#                     print(f"     相似度太低，繼續尋找其他匹配...")
                    
#                     # 重設 target_idx，繼續找品名相似的
#                     target_idx = None
            
#             # 1b. 如果 Item 不同，找品名相似的
#             if target_idx is None:
#                 max_similarity = 0
#                 best_match_idx = None
#                 best_match_item = None
                
#                 for idx, row_data in po_group.iterrows():
#                     existing_desc = row_data["品項"]
#                     existing_item = row_data["Item"]
#                     similarity = calculate_similarity(new_desc, existing_desc)
                    
#                     if similarity > max_similarity:
#                         max_similarity = similarity
#                         best_match_idx = idx
#                         best_match_item = existing_item
                
#                 # 如果找到相似品名（相似度 >= 60%）
#                 if max_similarity >= 60:
#                     target_idx = best_match_idx
#                     old_item = best_match_item
#                     old_desc = df_buyer.at[target_idx, "品項"]
                    
#                     if old_item != item_new:
#                         # Item 不同但品名相似，需要確認
#                         match_reason = f"品名相似(相似度{max_similarity:.0f}%)"
#                         print(f"  ⚠️  找到相似品名但 Item 不同（相似度 {max_similarity:.1f}%）")
#                         print(f"     原Item: {old_item} → 新Item: {item_new}")
#                         print(f"     原品名: {old_desc[:40]}...")
#                         print(f"     新品名: {new_desc[:40]}...")
                        
#                         if not confirm_override:
#                             print(f"     需要確認是否要更新 Item")
                            
#                             need_confirm_items.append({
#                                 "row": row_num,
#                                 "po_no": po_no_new,
#                                 "new_item": item_new,
#                                 "new_desc": new_desc,
#                                 "old_item": old_item,
#                                 "old_desc": old_desc,
#                                 "similarity": round(max_similarity, 1),
#                                 "new_delivery": new_delivery,
#                                 "new_qty": new_qty,
#                                 "target_index": int(target_idx),
#                                 "reason": "Item不同但品名相似",
#                                 "action_type": "update_different_item"  # 標記動作類型
#                             })
                            
#                             matching_output.append({
#                                 "row": row_num,
#                                 "po": po_no_new,
#                                 "item": f"{old_item}→{item_new}",
#                                 "match": match_reason,
#                                 "action": "待確認",
#                                 "note": f"品名相似但Item不同"
#                             })
#                             continue
#                         else:
#                             print(f"     => 已確認，將更新 Item 和品名")
#                     else:
#                         # Item 相同且品名相似
#                         match_reason = f"品名相似(相似度{max_similarity:.0f}%)"
#                         print(f"  ✅ 找到相似品名（相似度 {max_similarity:.1f}%） => 更新資料")
        
#         # 步驟2：如果在同 PO 內找不到匹配（Item不同且品名也不相似），詢問是否新增
#         if target_idx is None and not po_group.empty:
#             print(f"  ⚠️  在 PO {po_no_new} 內找不到匹配的 Item 或相似品名")
#             print(f"     新Item: {item_new}, 新品名: {new_desc[:40]}...")
            
#             if not confirm_override:
#                 print(f"     需要確認是否要新增為新項目")
                
#                 # 列出現有的項目供參考
#                 existing_items = []
#                 for idx, row_data in po_group.iterrows():
#                     existing_items.append({
#                         "item": row_data["Item"],
#                         "desc": row_data["品項"][:50]
#                     })
                
#                 need_confirm_items.append({
#                     "row": row_num,
#                     "po_no": po_no_new,
#                     "new_item": item_new,
#                     "new_desc": new_desc,
#                     "existing_items": existing_items[:5],  # 最多顯示5筆
#                     "new_delivery": new_delivery,
#                     "new_qty": new_qty,
#                     "reason": "無匹配項目",
#                     "action_type": "add_new"  # 標記動作類型：新增
#                 })
                
#                 matching_output.append({
#                     "row": row_num,
#                     "po": po_no_new,
#                     "item": item_new,
#                     "match": "無匹配",
#                     "action": "待確認",
#                     "note": "建議新增"
#                 })
#                 continue
#             else:
#                 print(f"     => 已確認，將新增為新項目")
#                 # 繼續執行新增邏輯（會在後面的程式碼處理）
        
#         # 步驟3：其他比對方式（ID、模糊比對等）- 只找狀態為 V 的
#         if target_idx is None and id_:
#             candidates = df_active[df_active["Id"] == id_].copy()
            
#             if len(candidates) > 1:
#                 candidates["品項_clean"] = candidates["品項"].apply(clean_text)
#                 exact_match = candidates[candidates["品項_clean"] == new_desc_clean]
#                 if len(exact_match) == 1:
#                     target_idx = exact_match.index[0]
#                     match_reason = "ID+品項匹配"
#                     print(f"  ✅ ID+品項匹配 => 更新資料 (狀態=V)")
#             elif len(candidates) == 1:
#                 target_idx = candidates.index[0]
#                 match_reason = "ID匹配"
#                 print(f"  ✅ ID匹配 => 更新資料 (狀態=V)")

#         # 步驟4：PO + 品項模糊比對 - 只找狀態為 V 的
#         if target_idx is None:
#             po_match = df_active[df_active["PO No."].apply(lambda x: is_po_in_record(x, po_no_new))]
#             po_match = po_match[po_match["品項"].apply(lambda x: fuzzy_in(x, new_desc_clean))]

#             if not po_match.empty:
#                 target_idx = po_match.index[0]
#                 match_reason = "PO+品項模糊匹配"
#                 print(f"  ✅ PO+品項模糊匹配 => 更新資料 (狀態=V)")

#         # 📝 如果找到匹配項目，執行更新
#         if target_idx is not None:
#             # 記錄原始值（用於輸出）
#             old_values = {
#                 "po": df_buyer.at[target_idx, "PO No."],
#                 "item": df_buyer.at[target_idx, "Item"],
#                 "delivery": df_buyer.at[target_idx, "Delivery Date 廠商承諾交期"],
#                 "qty": df_buyer.at[target_idx, "SOD Qty 廠商承諾數量"],
#                 "desc": df_buyer.at[target_idx, "品項"]
#             }
            
#             # 執行更新
#             df_buyer.at[target_idx, "PO No."] = po_no_new
#             df_buyer.at[target_idx, "Item"] = item_new
#             df_buyer.at[target_idx, "Delivery Date 廠商承諾交期"] = new_delivery
#             df_buyer.at[target_idx, "SOD Qty 廠商承諾數量"] = new_qty
#             if new_desc:
#                 df_buyer.at[target_idx, "品項"] = new_desc
#             updated_count += 1
            
#             # 輸出變更詳情
#             if old_values["po"] != po_no_new:
#                 print(f"     PO變更: {old_values['po']} → {po_no_new}")
#             if old_values["item"] != item_new:
#                 print(f"     Item變更: {old_values['item']} → {item_new}")
#             if old_values["delivery"] != new_delivery:
#                 print(f"     交期變更: {old_values['delivery']} → {new_delivery}")
#             if old_values["qty"] != new_qty:
#                 print(f"     數量變更: {old_values['qty']} → {new_qty}")
            
#             matching_output.append({
#                 "row": row_num,
#                 "po": po_no_new,
#                 "item": item_new if old_values["item"] == item_new else f"{old_values['item']}→{item_new}",
#                 "match": match_reason,
#                 "action": "已更新",
#                 "note": "品名已變更" if old_values["desc"] != new_desc else ""
#             })
#             continue

#         # 🆕 如果都找不到 → 新增資料（但要檢查 PO 是否存在於狀態 V 的資料中）
#         po_matches = df_active[df_active["PO No."].apply(lambda x: is_po_in_record(x, po_no_new))]
#         if po_matches.empty:
#             # 再檢查是否有狀態為 X 的相同 PO
#             po_cancelled = df_buyer[
#                 (df_buyer["開單狀態"] == "X") & 
#                 (df_buyer["PO No."].apply(lambda x: is_po_in_record(x, po_no_new)))
#             ]
            
#             if not po_cancelled.empty:
#                 print(f"  ⚠️  找到 PO {po_no_new} 但狀態為 X（已取消），無法更新")
#                 failed.append({
#                     "row": row_num,
#                     "po_no": po_no_new,
#                     "item": item_new,
#                     "reason": f"PO {po_no_new} 狀態為 X（已取消）"
#                 })
                
#                 matching_output.append({
#                     "row": row_num,
#                     "po": po_no_new,
#                     "item": item_new,
#                     "match": "PO已取消",
#                     "action": "失敗",
#                     "note": "狀態為X"
#                 })
#                 continue
#             else:
#                 print(f"  ❌ 找不到相關的 PO No.：{po_no_new}")
#                 failed.append({
#                     "row": row_num,
#                     "po_no": po_no_new,
#                     "item": item_new,
#                     "reason": f"後台找不到相關的 PO No.：{po_no_new}"
#                 })
                
#                 matching_output.append({
#                     "row": row_num,
#                     "po": po_no_new,
#                     "item": item_new,
#                     "match": "無匹配",
#                     "action": "失敗",
#                     "note": "找不到PO"
#                 })
#                 continue
        
#         # 🆔 推測 Id（取首筆）
#         possible_ids = po_matches["Id"].dropna().unique().tolist()
#         id_ = possible_ids[0] if possible_ids else row.get("id") or row.get("Id", "")
#         id_ = str(id_).strip()

#         # 👤 取同組第一筆的資訊
#         user = po_matches["User"].iloc[0] if not po_matches.empty else ""
#         epr_no = po_matches["ePR No."].iloc[0] if not po_matches.empty else ""
#         wbs_no = po_matches["WBS"].iloc[0] if not po_matches.empty else ""
#         need_day_no = po_matches["需求日"].iloc[0] if not po_matches.empty else ""

#         print(f"  🆕 找不到匹配項目 => 新增資料")
#         print(f"     新增到 ePR No.: {epr_no}")

#         # ➕ 新增新的一筆資料
#         new_row = {
#             "Id": id_,
#             "開單狀態": "V",
#             "交貨驗證": "",
#             "User": user,
#             "ePR No.": epr_no,
#             "PO No.": po_no_new,
#             "Item": item_new,
#             "品項": new_desc,
#             "規格": "",
#             "數量": new_qty,
#             "總數": new_qty,
#             "單價": "",
#             "總價": "",
#             "備註": "",
#             "字數": "",
#             "isEditing": "False",
#             "backup": "{}",
#             "_alertedItemLimit": "",
#             "Delivery Date 廠商承諾交期": new_delivery,
#             "SOD Qty 廠商承諾數量": new_qty,
#             "驗收數量": "",
#             "拒收數量": "",
#             "發票月份": "",
#             "WBS": wbs_no,
#             "需求日": need_day_no
#         }

#         # 📌 找這個 id 的最後一筆位置
#         same_id_idx = df_buyer[df_buyer["Id"] == id_].index
#         insert_pos = same_id_idx[-1] + 1 if len(same_id_idx) > 0 else len(df_buyer)

#         # ✨ 插入到原 df_buyer 中指定位置
#         df_buyer = pd.concat([
#             df_buyer.iloc[:insert_pos],
#             pd.DataFrame([new_row]),
#             df_buyer.iloc[insert_pos:]
#         ], ignore_index=True)
        
#         new_item = '新增物件'
#         inserted_count += 1
        
#         matching_output.append({
#             "row": row_num,
#             "po": po_no_new,
#             "item": item_new,
#             "match": "無匹配",
#             "action": "已新增",
#             "note": f"ePR:{epr_no}"
#         })

#     # 輸出比對結果摘要
#     print("\n" + "="*80)
#     print("比對結果摘要")
#     print("="*80)
#     print(f"總處理筆數: {len(rows)}")
#     print(f"更新筆數: {updated_count}")
#     print(f"新增筆數: {inserted_count}")
#     print(f"失敗筆數: {len(failed)}")
#     print(f"待確認筆數: {len(need_confirm_items)}")
    
#     # 輸出詳細比對表格
#     if matching_output:
#         print("\n詳細比對結果:")
#         print("-"*80)
#         print(f"{'筆數':<5} {'PO No.':<15} {'Item':<10} {'比對方式':<20} {'處理':<8} {'備註'}")
#         print("-"*80)
#         for item in matching_output:
#             print(f"{item['row']:<5} {item['po']:<15} {item['item']:<10} {item['match']:<20} {item['action']:<8} {item['note']}")
    
#     print("="*80 + "\n")

#     # 如果有需要確認的項目，回傳給前端
#     if need_confirm_items and not confirm_override:
#         # 根據不同的確認原因和動作類型，產生不同的訊息
#         action_types = set(item.get("action_type", "") for item in need_confirm_items)
        
#         if "add_new" in action_types:
#             msg = f"發現 {len(need_confirm_items)} 個項目可能需要新增或更新"
#         elif "update_different_desc" in action_types:
#             msg = f"發現 {len(need_confirm_items)} 個品名完全不同的項目需要確認"
#         elif "update_different_item" in action_types:
#             msg = f"發現 {len(need_confirm_items)} 個Item不同但品名相似的項目需要確認"
#         else:
#             msg = f"發現 {len(need_confirm_items)} 個需要確認的項目"
        
#         return jsonify(convert_to_json_serializable({
#             "status": "confirm_needed",
#             "msg": msg,
#             "items": need_confirm_items,
#             "updated": updated_count,
#             "inserted": inserted_count,
#             "matching_output": matching_output
#         }))

#     # 儲存回檔案
#     df_buyer.to_csv(BUYER_FILE, index=False, encoding="utf-8-sig")
    
#     # 刪除暫存檔案
#     if po_no_new:
#         temp_file = f"uploads/{po_no_new}.csv"
#         if os.path.exists(temp_file):
#             os.remove(temp_file)
    
#     # 回傳結果
#     if new_item == '新增物件':
#         return jsonify(convert_to_json_serializable({
#             "status": "ok",
#             "msg": f"有新增的物件(item)需要維護，ePR No. 單號為 {epr_no}。更新 {updated_count} 筆，新增 {inserted_count} 筆",
#             "failed": failed,
#             "matching_output": matching_output
#         }))
#     else:
#         return jsonify(convert_to_json_serializable({
#             "status": "ok",
#             "msg": f"✅ 更新 {updated_count} 筆，新增 {inserted_count} 筆",
#             "failed": failed,
#             "matching_output": matching_output
#         }))
    


# def is_po_in_record(row_po_str, target_po):
#     po_list = re.split(r"<br\s*/?>", str(row_po_str))
#     return target_po.strip() in [po.strip() for po in po_list]
#     # 👇 保留原有的 is_po_in_record 函數（支援多個 PO）
# def is_po_in_record(row_po_str, target_po):
#     """檢查 PO 是否在記錄中（支援 <br /> 分隔的多個 PO）"""
#     po_list = re.split(r"<br\s*/?>", str(row_po_str))
#     po_list = [po.strip() for po in po_list if po.strip()]
#     return target_po.strip() in po_list

# def fuzzy_in(text, keyword):
#     return keyword.strip() in str(text).strip()

# from difflib import SequenceMatcher  # 👈 新增：在檔案開頭 import
# import re  # 👈 新增：用於處理 PO 分割

# @app.route("/api/save_override_all", methods=["POST"])
# def save_override_all():
#     data = request.get_json()
#     rows = data.get("rows", [])
#     confirm_override = data.get("confirm_override", False)  # 是否已確認覆蓋

#     if not rows:
#         return jsonify({"status": "error", "msg": "❌ 沒有收到任何資料"}), 400

#     def clean_text(x):
#         return str(x).replace("\n", "").replace("\r", "").strip()
    
#     def calculate_similarity(text1, text2):
#         """計算兩個字串的相似度 (0-100)"""
#         text1_clean = clean_text(text1).lower()
#         text2_clean = clean_text(text2).lower()
#         return SequenceMatcher(None, text1_clean, text2_clean).ratio() * 100
    
#     # 👇 保留原有的 is_po_in_record 函數（支援多個 PO）
#     def is_po_in_record(row_po_str, target_po):
#         """檢查 PO 是否在記錄中（支援 <br /> 分隔的多個 PO）"""
#         po_list = re.split(r"<br\s*/?>", str(row_po_str))
#         po_list = [po.strip() for po in po_list if po.strip()]
#         return target_po.strip() in po_list
    
#     # 👇 保留原有的 fuzzy_in 函數
#     def fuzzy_in(text, keyword):
#         """模糊比對關鍵字是否在文字中"""
#         return keyword.strip() in str(text).strip()

#     df_buyer = pd.read_csv(BUYER_FILE, encoding="utf-8-sig", dtype=str, on_bad_lines="skip").fillna("")
#     df_buyer["PO No."] = df_buyer["PO No."].str.strip()
#     df_buyer["Item"] = (
#         df_buyer["Item"]
#         .str.replace(r"\.0$", "", regex=True)
#         .str.strip()
#         .apply(lambda x: x.zfill(4) if x.isdigit() else x)
#     )

#     updated_count = 0
#     inserted_count = 0
#     failed = []
#     need_confirm_items = []  # 👈 修改：用於存放需要確認的項目

#     new_item = ''
#     epr_no = 0
#     po_no_new = ''

#     for row in rows:
#         id_ = row.get("id", "").strip()
#         po_no_new = row.get("po_no", "").strip()
#         item_new = row.get("item", "").strip()
#         # 👇 新增：確保 item 格式一致（4位數）
#         if item_new.isdigit():
#             item_new = item_new.zfill(4)
#         new_delivery = row.get("delivery_date", "").strip()
#         new_qty = row.get("sod_qty", "").strip()
#         new_desc = row.get("po_description", "").strip()
#         new_desc_clean = clean_text(new_desc)

#         target_idx = None
        
#         # 👇 新增：步驟1 - 優先用 PO + Item 精確比對
#         exact_match = df_buyer[
#             df_buyer["PO No."].apply(lambda x: is_po_in_record(x, po_no_new))
#         ]
#         exact_match = exact_match[exact_match["Item"] == item_new]
        
#         if not exact_match.empty:
#             # ✅ PO 和 Item 都匹配，直接覆蓋
#             target_idx = exact_match.index[0]
#             df_buyer.at[target_idx, "Delivery Date 廠商承諾交期"] = new_delivery
#             df_buyer.at[target_idx, "SOD Qty 廠商承諾數量"] = new_qty
#             if new_desc:
#                 df_buyer.at[target_idx, "品項"] = new_desc
#             updated_count += 1
#             continue  # 👈 直接處理下一筆
        
#         # 👇 修改：步驟2 - 如果 PO+Item 不完全匹配，找相似品名
#         po_matches = df_buyer[df_buyer["PO No."].apply(lambda x: is_po_in_record(x, po_no_new))]
        
#         if not po_matches.empty:
#             # 👇 新增：計算品名相似度
#             similarities = []
#             for idx, existing_row in po_matches.iterrows():
#                 existing_desc = existing_row["品項"]
#                 similarity = calculate_similarity(new_desc, existing_desc)
                
#                 if similarity >= 60:  # 👈 相似度門檻 60%
#                     similarities.append({
#                         "index": idx,
#                         "old_item": existing_row["Item"],
#                         "old_desc": existing_desc,
#                         "similarity": similarity,
#                         "id": existing_row["Id"]
#                     })
            
#             if similarities:
#                 # 👇 找到相似品名，選擇最相似的
#                 best_match = max(similarities, key=lambda x: x["similarity"])
                
#                 if not confirm_override and best_match["old_item"] != item_new:
#                     # 👇 新增：Item 不同且需要使用者確認
#                     need_confirm_items.append({
#                         "po_no": po_no_new,
#                         "new_item": item_new,
#                         "new_desc": new_desc,
#                         "old_item": best_match["old_item"],
#                         "old_desc": best_match["old_desc"],
#                         "similarity": round(best_match["similarity"], 1),
#                         "new_delivery": new_delivery,
#                         "new_qty": new_qty,
#                         "target_index": best_match["index"],
#                         "id": best_match["id"]
#                     })
#                     continue  # 👈 暫時跳過，等待確認
#                 else:
#                     # 👇 已確認或 Item 相同，執行覆蓋
#                     target_idx = best_match["index"]
#                     df_buyer.at[target_idx, "Item"] = item_new
#                     df_buyer.at[target_idx, "品項"] = new_desc
#                     df_buyer.at[target_idx, "Delivery Date 廠商承諾交期"] = new_delivery
#                     df_buyer.at[target_idx, "SOD Qty 廠商承諾數量"] = new_qty
#                     updated_count += 1
#                     continue
        
#         # 👇 保留原有邏輯：步驟3 - 嘗試根據 Id 精確比對
#         if id_:
#             candidates = df_buyer[df_buyer["Id"] == id_].copy()
            
#             if len(candidates) > 1:
#                 candidates["品項_clean"] = candidates["品項"].apply(clean_text)
#                 exact_match = candidates[candidates["品項_clean"] == new_desc_clean]
#                 if len(exact_match) == 1:
#                     target_idx = exact_match.index[0]
#             elif len(candidates) == 1:
#                 target_idx = candidates.index[0]

#         # 👇 保留原有邏輯：如果還找不到 → 用 PO No. 和 品項模糊比對
#         if target_idx is None:
#             po_match = df_buyer[df_buyer["PO No."].apply(lambda x: is_po_in_record(x, po_no_new))]
#             po_match = po_match[po_match["品項"].apply(lambda x: fuzzy_in(x, new_desc_clean))]

#             if not po_match.empty:
#                 target_idx = po_match.index[0]

#         # 👇 保留原有邏輯：如果仍然找不到 → 以 id 為單位新增資料
#         if target_idx is None:
#             po_matches = df_buyer[df_buyer["PO No."].apply(lambda x: is_po_in_record(x, po_no_new))]
#             if po_matches.empty:
#                 # 👇 修改：不要立即刪除檔案
#                 # os.remove(f"uploads/{po_no_new}.csv")
#                 failed.append({
#                     "po_no": po_no_new,
#                     "item": item_new,
#                     "reason": f"後台找不到相關的 PO No.：{po_no_new}"
#                 })
#                 continue  # 👈 繼續處理其他項目
            
#             # 👇 保留原有的新增邏輯
#             possible_ids = po_matches["Id"].dropna().unique().tolist()
#             id_ = possible_ids[0] if possible_ids else row.get("id") or row.get("Id", "")
#             id_ = str(id_).strip()

#             user = po_matches["User"].iloc[0] if not po_matches.empty else ""
#             epr_no = po_matches["ePR No."].iloc[0] if not po_matches.empty else ""
#             wbs_no = po_matches["WBS"].iloc[0] if not po_matches.empty else ""
#             need_day_no = po_matches["需求日"].iloc[0] if not po_matches.empty else ""

#             new_row = {
#                 "Id": id_,
#                 "開單狀態": "V",
#                 "交貨驗證": "",
#                 "User": user,
#                 "ePR No.": epr_no,
#                 "PO No.": po_no_new,
#                 "Item": item_new,
#                 "品項": new_desc,
#                 "規格": "",
#                 "數量": new_qty,
#                 "總數": new_qty,
#                 "單價": "",
#                 "總價": "",
#                 "備註": "",
#                 "字數": "",
#                 "isEditing": "False",
#                 "backup": "{}",
#                 "_alertedItemLimit": "",
#                 "Delivery Date 廠商承諾交期": new_delivery,
#                 "SOD Qty 廠商承諾數量": new_qty,
#                 "驗收數量": "",
#                 "拒收數量": "",
#                 "發票月份": "",
#                 "WBS": wbs_no,
#                 "需求日": need_day_no
#             }

#             same_id_idx = df_buyer[df_buyer["Id"] == id_].index
#             insert_pos = same_id_idx[-1] + 1 if len(same_id_idx) > 0 else len(df_buyer)

#             df_buyer = pd.concat([
#                 df_buyer.iloc[:insert_pos],
#                 pd.DataFrame([new_row]),
#                 df_buyer.iloc[insert_pos:]
#             ], ignore_index=True)
#             new_item = '新增物件'
#             inserted_count += 1  # 👈 修改：使用 inserted_count
#             continue

#         # 👇 如果找到 target_idx 但還沒處理
#         if target_idx is not None:
#             df_buyer.at[target_idx, "PO No."] = po_no_new
#             df_buyer.at[target_idx, "Item"] = item_new
#             df_buyer.at[target_idx, "Delivery Date 廠商承諾交期"] = new_delivery
#             df_buyer.at[target_idx, "SOD Qty 廠商承諾數量"] = new_qty
#             if new_desc:
#                 df_buyer.at[target_idx, "品項"] = new_desc
#             updated_count += 1

#     # 👇 新增：如果有需要確認的項目，回傳給前端
#     if need_confirm_items and not confirm_override:
#         return jsonify({
#             "status": "confirm_needed",
#             "msg": f"發現 {len(need_confirm_items)} 個品名相似但項次不同的項目",
#             "items": need_confirm_items,
#             "updated": updated_count,
#             "inserted": inserted_count
#         })

#     # 儲存回檔案
#     df_buyer.to_csv(BUYER_FILE, index=False, encoding="utf-8-sig")
    
#     # 👇 修改：統一刪除暫存檔案
#     if po_no_new:
#         temp_file = f"uploads/{po_no_new}.csv"
#         if os.path.exists(temp_file):
#             os.remove(temp_file)
    
#     # 👇 修改：改進回傳訊息
#     if new_item == '新增物件':
#         return jsonify({
#             "status": "ok",
#             "msg": f"有新增的物件(item)需要維護，ePR No. 單號為 {epr_no}。更新 {updated_count} 筆，新增 {inserted_count} 筆",
#             "failed": failed
#         })
#     else:
#         return jsonify({
#             "status": "ok",
#             "msg": f"✅ 更新 {updated_count} 筆，新增 {inserted_count} 筆",
#             "failed": failed
#         })

# @app.route("/api/save_override_all", methods=["POST"])
# def save_override_all():
#     data = request.get_json()
#     rows = data.get("rows", [])
#     confirm_override = data.get("confirm_override", False)  # 是否已確認覆蓋

#     if not rows:
#         return jsonify({"status": "error", "msg": "❌ 沒有收到任何資料"}), 400

#     def clean_text(x):
#         return str(x).replace("\n", "").replace("\r", "").strip()
    
#     def calculate_similarity(text1, text2):
#         """計算兩個字串的相似度 (0-100)"""
#         text1_clean = clean_text(text1).lower()
#         text2_clean = clean_text(text2).lower()
#         return SequenceMatcher(None, text1_clean, text2_clean).ratio() * 100

#     df_buyer = pd.read_csv(BUYER_FILE, encoding="utf-8-sig", dtype=str, on_bad_lines="skip").fillna("")
#     df_buyer["PO No."] = df_buyer["PO No."].str.strip()
#     df_buyer["Item"] = (
#         df_buyer["Item"]
#         .str.replace(r"\.0$", "", regex=True)
#         .str.strip()
#         .apply(lambda x: x.zfill(4) if x.isdigit() else x)
#     )

#     updated_count = 0
#     inserted_count = 0
#     failed = []
#     need_confirm_items = []  # 需要確認的項目

#     new_item = ''
#     epr_no = 0
#     po_no_new = ''

#     for row in rows:
#         id_ = row.get("id", "").strip()
#         po_no_new = row.get("po_no", "").strip()
#         item_new = row.get("item", "").strip()
#         new_delivery = row.get("delivery_date", "").strip()
#         new_qty = row.get("sod_qty", "").strip()
#         new_desc = row.get("po_description", "").strip()
#         new_desc_clean = clean_text(new_desc)

#         # 嘗試根據 Id 精確比對
#         candidates = df_buyer[df_buyer["Id"] == id_].copy()
#         target_idx = None

#         if len(candidates) > 1:
#             candidates["品項_clean"] = candidates["品項"].apply(clean_text)
#             exact_match = candidates[candidates["品項_clean"] == new_desc_clean]
#             if len(exact_match) == 1:
#                 target_idx = exact_match.index[0]
#         elif len(candidates) == 1:
#             target_idx = candidates.index[0]

#         # 如果還找不到 → 用 PO No. 和 品項模糊比對
#         if target_idx is None:
#             po_match = df_buyer[df_buyer["PO No."].apply(lambda x: is_po_in_record(x, po_no_new))]
#             po_match = po_match[po_match["品項"].apply(lambda x: fuzzy_in(x, new_desc_clean))]

#             if not po_match.empty:
#                 target_idx = po_match.index[0]

#         # 如果仍然找不到 → 以 id 為單位新增資料
#         if target_idx is None:
#             # 🔍 用 po_no_new 找出相同組的所有資料
#             po_matches = df_buyer[df_buyer["PO No."].apply(lambda x: is_po_in_record(x, po_no_new))]
#             if po_matches.empty:
#                 os.remove(f"uploads/{po_no_new}.csv")
#                 return jsonify({
#                     "status": "error",
#                     "msg": f"❌ 後台找不到相關的 PO No.：{po_no_new}，資料無法寫入，請維護網頁資訊",
#                     "failed": [row]
#                 }), 400
            
#             # 🆔 推測 Id（取首筆）
#             possible_ids = po_matches["Id"].dropna().unique().tolist()
#             id_ = possible_ids[0] if possible_ids else row.get("id") or row.get("Id", "")
#             id_ = str(id_).strip()

#             # 👤 取同組第一筆的 User 和 ePR No.
#             user = po_matches["User"].iloc[0] if not po_matches.empty else ""
#             epr_no = po_matches["ePR No."].iloc[0] if not po_matches.empty else ""
#             wbs_no = po_matches["WBS"].iloc[0] if not po_matches.empty else ""
#             need_day_no = po_matches["需求日"].iloc[0] if not po_matches.empty else ""

#             # ➕ 新增新的一筆資料
#             new_row = {
#                 "Id": id_,
#                 "開單狀態": "V",
#                 "交貨驗證": "",
#                 "User": user,
#                 "ePR No.": epr_no,
#                 "PO No.": po_no_new,
#                 "Item": item_new,
#                 "品項": new_desc,
#                 "規格": "",
#                 "數量": new_qty,
#                 "總數": new_qty,
#                 "單價": "",
#                 "總價": "",
#                 "備註": "",
#                 "字數": "",
#                 "isEditing": "False",
#                 "backup": "{}",
#                 "_alertedItemLimit": "",
#                 "Delivery Date 廠商承諾交期": new_delivery,
#                 "SOD Qty 廠商承諾數量": new_qty,
#                 "驗收數量": "",
#                 "拒收數量": "",
#                 "發票月份": "",
#                 "WBS": wbs_no,
#                 "需求日": need_day_no
#             }

#             # 📌 找這個 id 的最後一筆位置
#             same_id_idx = df_buyer[df_buyer["Id"] == id_].index
#             insert_pos = same_id_idx[-1] + 1 if len(same_id_idx) > 0 else len(df_buyer)

#             # ✨ 插入到原 df_buyer 中指定位置
#             df_buyer = pd.concat([
#                 df_buyer.iloc[:insert_pos],
#                 pd.DataFrame([new_row]),
#                 df_buyer.iloc[insert_pos:]
#             ], ignore_index=True)
#             new_item = '新增物件'
#             updated_count += 1
#             continue

#         # 寫入更新欄位
#         df_buyer.at[target_idx, "PO No."] = po_no_new
#         df_buyer.at[target_idx, "Item"] = item_new
#         df_buyer.at[target_idx, "Delivery Date 廠商承諾交期"] = new_delivery
#         df_buyer.at[target_idx, "SOD Qty 廠商承諾數量"] = new_qty
#         if new_desc:
#             df_buyer.at[target_idx, "品項"] = new_desc
#         updated_count += 1

#     # 儲存回檔案
#     df_buyer.to_csv(BUYER_FILE, index=False, encoding="utf-8-sig")
#     if new_item == '新增物件':
#         os.remove(f"uploads/{po_no_new}.csv")
#         return jsonify({
#             "status": "ok",
#             "msg": f"有新增的物件(item)需要維護，ePR No. 單號為 {epr_no}",
#             "failed": failed
#         })
#     else:
#         os.remove(f"uploads/{po_no_new}.csv")
#         return jsonify({
#             "status": "ok",
#             "msg": f"✅ 更新 {updated_count} 筆，新增 {inserted_count} 筆",
#             "failed": failed
#         })



# eRT 驗收表單
# === 設定 logger ，針對 eRT 驗收表單===
log_file_path = "buyer_detail_update_log.log"
logging.basicConfig(
    filename=log_file_path,
    filemode='a',
    level=logging.INFO,
    format="%(asctime)s %(levelname)s: %(message)s",
    encoding='utf-8'
)
logger = logging.getLogger("BuyerDetailUpdater")


@app.route("/api/update_delivery_receipt", methods=["POST"])
def upload_buyer_detail():
    file = request.files.get('file')
    if not file or not file.filename:
        print("❌ 沒有收到檔案")
        return jsonify({"status": "fail", "message": "No file uploaded"}), 400

    filename = file.filename
    ext = os.path.splitext(filename)[-1].lower()
    print(f"📁 收到檔案：{filename}（副檔名：{ext}）")

    if ext not in ['.xlsx', '.xls']:
        return jsonify({"status": "fail", "message": "Invalid file type"}), 400

    try:
        engine = 'openpyxl' if ext == '.xlsx' else 'xlrd'
        df = pd.read_excel(file, engine=engine)  # 這行最容易報錯
        df.to_csv("static/data/delivery_receipt.csv", index=False, encoding="utf-8-sig")
        print("💾 已儲存為 static/data/delivery_receipt.csv，開始進行膯 Buyer detail 該表數據更新")


        output_df = pd.read_csv("static/data/delivery_receipt.csv", encoding="utf-8-sig", dtype=str)
        buyer_df = pd.read_csv(BUYER_FILE, encoding="utf-8-sig", dtype=str)

        # === 欄位標準化 ===
        output_df.columns = output_df.columns.str.replace("\ufeff", "").str.strip()
        buyer_df.columns = buyer_df.columns.str.strip()


        # === 確認並處理必要的欄位 ===
        required_buyer_cols = ["PO No.", "品項", "驗收數量", "拒收數量", "發票月份"]
        required_output_cols = ["PONO", "品名", "驗收數量", "拒收數量", "收料日期"]

        # 檢查 buyer_df 是否有必要的欄位
        if not all(col in buyer_df.columns for col in required_buyer_cols):
            missing_cols = [col for col in required_buyer_cols if col not in buyer_df.columns]
            print(f"錯誤: {BUYER_FILE} 缺少必要的欄位: {', '.join(missing_cols)}")
            logger.error(f"{BUYER_FILE} 缺少必要的欄位: {', '.join(missing_cols)}")
            exit()

        # 檢查 output_df 是否有必要的欄位
        if not all(col in output_df.columns for col in required_output_cols):
            missing_cols = [col for col in required_output_cols if col not in output_df.columns]
            print(f"錯誤: delivery_receipt.csv 缺少必要的欄位: {', '.join(missing_cols)}")
            logger.error(f"delivery_receipt.csv 缺少必要的欄位: {', '.join(missing_cols)}")
            exit()

        # === 資料清理與預處理 ===
        # 清理 output_df 的 PONO 和 品名
        output_df["PONO_clean"] = output_df["PONO"].astype(str).str.strip().str.upper()
        output_df["品名_clean"] = output_df["品名"].astype(str).str.strip()

        # 根據你的要求，直接複製收料日期到新的發票月份欄位，不進行任何格式更改。
        output_df["發票月份_from_output"] = output_df["收料日期"].astype(str).str.strip()

        output_df.rename(columns={
            "驗收數量": "驗收數量_from_output",
            "拒收數量": "拒收數量_from_output"
        }, inplace=True)

        # 清理 buyer_df 的 PO No. 和 品項
        buyer_df["PO_clean"] = buyer_df["PO No."].astype(str).str.strip().str.upper()
        buyer_df["品項_clean"] = buyer_df["品項"].astype(str).str.strip()

        # 選擇 output_df 需要的欄位進行合併
        output_cols_to_merge = [
            "PONO_clean",
            "品名_clean",
            "驗收數量_from_output",
            "拒收數量_from_output",
            "發票月份_from_output"
        ]
        output_subset = output_df[output_cols_to_merge].copy()

        # === 合併資料 ===
        merged = pd.merge(
            buyer_df,
            output_subset,
            how='left',
            left_on=["PO_clean", "品項_clean"],
            right_on=["PONO_clean", "品名_clean"],
            suffixes=("", "_from_output")
        )

        # === 更新欄位 ===
        columns_to_update = {
            "驗收數量": "驗收數量_from_output",
            "拒收數量": "拒收數量_from_output",
            "發票月份": "發票月份_from_output"
        }

        update_count = 0
        for idx, row in merged.iterrows():
            updated = False
            log_info = {}
            
            po = row.get("PO No.", "N/A")
            item = row.get("Item", "N/A") # 使用 'Item' 欄位
            
            # 這裡確保 '品項' 欄位有值，否則以 'Item' 替代
            item_for_log = row.get("品項", "N/A")
            if item_for_log == 'N/A' or pd.isna(item_for_log):
                item_for_log = item

            for target_col, source_col in columns_to_update.items():
                new_val = row.get(source_col, "")
                old_val = row.get(target_col, "")

                if pd.isna(new_val): new_val = ""
                if pd.isna(old_val): old_val = ""

                clean_new_val = str(new_val).strip()
                clean_old_val = str(old_val).strip()

                if clean_new_val != "" and clean_new_val != clean_old_val:
                    merged.at[idx, target_col] = clean_new_val
                    updated = True
                    log_info[target_col] = {"old": old_val, "new": clean_new_val}

            if updated:
                update_count += 1
                # 使用你要求的日誌格式
                logger.info(
                    f"{{'{po}'}} 更改 -> item: {item_for_log}, "
                    f"驗收數量: {log_info.get('驗收數量', {}).get('new', row.get('驗收數量', ''))}, "
                    f"拒收數量: {log_info.get('拒收數量', {}).get('new', row.get('拒收數量', ''))}, "
                    f"發票月份: {log_info.get('發票月份', {}).get('new', row.get('發票月份', ''))}"
                )

        # === 移除中繼欄位 ===
        merged.drop(columns=[c for c in merged.columns if c.endswith("_clean") or c.endswith("_from_output")], inplace=True)

        # === 最終輸出欄位清單 ===
        final_columns = ['Id', '開單狀態', '交貨驗證', 'User', 'ePR No.', 'PO No.', 'Item', '品項', '規格', '數量', '總數', '單價', '總價', '備註', '字數', 'isEditing', 'backup', '_alertedItemLimit', 'Delivery Date 廠商承諾交期', 'SOD Qty 廠商承諾數量', '驗收數量', '拒收數量', '發票月份']

        # 確保只保留需要的欄位
        final_df = merged[final_columns].copy()

        # === 儲存更新後的檔案 ===
        final_df.to_csv(BUYER_FILE, index=False, encoding="utf-8-sig")

        print(f"總共更新了 {update_count} 筆資料。")
        print(f"檔案已更新。總共更新了 {update_count} 筆資料。")
        os.remove("static/data/delivery_receipt.csv")

        return jsonify({"status": "success", "msg": f"檔案已更新。總共更新了 {update_count} 筆資料。"})
    except Exception as e:
        traceback.print_exc()  # 印出完整錯誤堆疊
        return jsonify({"status": "error", "message": str(e)}), 500
    

@app.route("/api/buyer_detail", methods=["GET"])
def get_buyer_details():
    """
    讀取 Buyer_detail.csv 檔案並以 JSON 格式回傳。
    """
    # 檢查檔案是否存在
    if not os.path.exists(BUYER_FILE):
        print(f"錯誤：找不到檔案 {BUYER_FILE}")
        return jsonify({"error": f"找不到檔案 {BUYER_FILE}"}), 500
        
    try:
        # 使用 pandas 讀取 CSV 檔案
        df = pd.read_csv(BUYER_FILE, encoding="utf-8-sig", dtype=str)
        
        # 確保欄位名稱沒有多餘的空白
        df.columns = df.columns.str.strip()

        # === 修正：將 DataFrame 中的 NaN 值替換為 None ===
        # 讀取 CSV 時 dtype=str 會將 NaN 讀成字串 'nan'。
        df = df.replace({np.nan: None, 'nan': None})
        
        # 將 DataFrame 轉換成 JSON 格式的列表
        data_json = df.to_dict('records')
        
        return jsonify(data_json)
    except Exception as e:
        print(f"處理檔案時發生錯誤: {e}")
        return jsonify({"error": f"處理檔案時發生錯誤: {e}"}), 500

# 在 app.py 中新增以下 API 端點

ACCOUNTING_SUMMARY_FILE = "static/data/accounting_summary.json"
MONTHLY_ACTUAL_ACCOUNTING_FILE = "static/data/monthly_actual_accounting.json"

@app.route('/api/accounting-summary', methods=['GET'])
def get_accounting_summary():
    """
    獲取尚未入帳的月份選項和金額
    """
    try:
        if os.path.exists(ACCOUNTING_SUMMARY_FILE):
            with open(ACCOUNTING_SUMMARY_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return jsonify(data)
        else:
            return jsonify({})
    except Exception as e:
        print(f"❌ 讀取 accounting_summary.json 錯誤: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/monthly-actual-accounting', methods=['GET'])
def get_monthly_actual_accounting():
    """
    獲取每月實際入帳金額
    """
    try:
        if os.path.exists(MONTHLY_ACTUAL_ACCOUNTING_FILE):
            with open(MONTHLY_ACTUAL_ACCOUNTING_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return jsonify(data)
        else:
            return jsonify({})
    except Exception as e:
        print(f"❌ 讀取 monthly_actual_accounting.json 錯誤: {e}")
        return jsonify({'error': str(e)}), 500



# 3.1 在檔案開頭加入 import
import json
import os
# 3.2 在 Flask app 初始化後加入
# 設定儲存篩選狀態的資料夾
FILTERS_DIR = 'user_filters'
if not os.path.exists(FILTERS_DIR):
    os.makedirs(FILTERS_DIR)

# 3.3 新增以下三個路由

@app.route('/api/save-filters-json', methods=['POST'])
def save_filters_json():
    try:
        data = request.json
        username = data.get('username')
        
        if not username:
            return jsonify({'status': 'error', 'message': '缺少使用者名稱'}), 400
        
        # 儲存到 JSON 檔案
        filename = os.path.join(FILTERS_DIR, f'{username}_filters.json')
        
        # 確保目錄存在
        os.makedirs(os.path.dirname(filename), exist_ok=True)
        
        # 寫入檔案
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        return jsonify({'status': 'success', 'message': '篩選狀態已儲存'})
        
    except Exception as e:
        print(f"儲存篩選狀態錯誤: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/get-filters-json/<username>', methods=['GET'])
def get_filters_json(username):
    try:
        filename = os.path.join(FILTERS_DIR, f'{username}_filters.json')
        
        if os.path.exists(filename):
            with open(filename, 'r', encoding='utf-8') as f:
                filters = json.load(f)
            return jsonify(filters)
        else:
            return jsonify({'message': '找不到篩選設定'}), 404
            
    except Exception as e:
        print(f"載入篩選狀態錯誤: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/clear-filters-json/<username>', methods=['DELETE'])
def clear_filters_json(username):
    try:
        filename = os.path.join(FILTERS_DIR, f'{username}_filters.json')
        
        if os.path.exists(filename):
            os.remove(filename)
            return jsonify({'status': 'success', 'message': '篩選狀態已清除'})
        else:
            return jsonify({'status': 'success', 'message': '沒有需要清除的篩選狀態'})
            
    except Exception as e:
        print(f"清除篩選狀態錯誤: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)