const app = Vue.createApp({
    data() {
        return {
            username: '',
            admins: [],
            data: [],
            items: [],
            tableHeaders: [
                "交貨驗證",
                "驗收狀態",
                "ePR No.",
                "PO No.",
                "Item",
                "品項",
                "規格",
                "數量",
                "總數",
                "單價",
                "總價",
                "RT金額",
                "RT總金額",
                "備註",
                "Delivery Date 廠商承諾交期",
                "SOD Qty 廠商承諾數量",
                "驗收數量",
                "拒收數量",
                "發票月份",
                "WBS",
            ],
            globalSearch: '',
            dateFilterActive: false,

            showAcceptanceFilter: false,
            showEPRFilter: false,
            showPOFilter: false,
            showITEMFilter: false,
            showNAMEilter: false,
            showSPECFilter: false,
            showQTYFilter: false,
            showTOTALQTYFilter: false,
            showPRICEFilter: false,
            showTOTALFilter: false,
            showREMARKFilter: false,
            showDELIVERYSFilter: false,
            showSODFilter: false,
            showACCEPTFilter: false,
            showREJECTFilter: false,
            showINVOICEFilter: false,
            checkedAcceptances: [],
            checkedEPRs: [],
            checkedPOs: [],
            checkedItems: [],
            checkedNames: [],
            checkedSpecs: [],
            checkedQtys: [],
            checkedTotalQtys: [],
            checkedPrices: [],
            checkedTotals: [],
            checkedRemarks: [],
            checkedDeliverys: [],
            checkedSods: [],
            checkedAccepts: [],
            checkedRejects: [],
            checkedInvoices: [],
            selectedFile: null,


            // 新增的資料屬性
            accountingSummary: {},
            monthlyActualAccounting: {},
            invoiceMonthOptions: [],
            
            // 選擇器相關
            selectedUnInvoicedMonth: '',
            selectedInvoiceMonth: '',
            selectedCurrentUnInvoicedMonth: '',
            selectedCurrentMonth: '',
            selectedBudgetMonth: '',
            
            // 金額相關
            currentUnInvoicedAmount: 0,
            selectedMonthlyInvoiceAmount: 0,
            currentMonthUnInvoicedAmount: 0,
            selectedCurrentMonthInvoiceAmount: 0,
            budgetLimit: 0,
            budgetControl: 0,

            uninvoicedMonthOptions: [], // 尚未入帳月份選項 (來自 accounting_summary.json)
            invoiceMonthOptions: [],    // 實際入帳月份選項 (來自 monthly_actual_accounting.json)
            budgetMonthOptions: [],     // 預算月份選項
        };
    },

    computed: {
        filteredData() {
            const baseData = this.dateFilterActive ? this.dateFilteredItems : this.items;
            return baseData.filter(i => {
                const keyword = this.globalSearch.trim().toLowerCase();
                if (keyword) {
                    const matched = Object.values(i).some(val =>
                        String(val).toLowerCase().includes(keyword)
                    );
                    if (!matched) return false;
                }
                // const matchAcceptance = this.checkedAcceptances.length === 0 || this.checkedAcceptances.includes(i['交貨驗證']);
                // 修改交貨驗證的匹配邏輯
                let matchAcceptance = false;
                if (this.checkedAcceptances.length === 0) {
                    matchAcceptance = true;
                } else {
                    const actualValue = i['交貨驗證'];
                    if ((actualValue === null || actualValue === undefined || actualValue === '') 
                        && this.checkedAcceptances.includes('(空白)')) {
                        matchAcceptance = true;
                    } else if (this.checkedAcceptances.includes(actualValue)) {
                        matchAcceptance = true;
                    }
                }
                const matchEPR = this.checkedEPRs.length === 0 || this.checkedEPRs.includes(i['ePR No.']);
                const matchPO = this.checkedPOs.length === 0 || this.checkedPOs.includes(i['PO No.']);
                const matchItem = this.checkedItems.length === 0 || this.checkedItems.includes(i['Item']);
                const matchName = this.checkedNames.length === 0 || this.checkedNames.includes(i['品項']);
                const matchSpec = this.checkedSpecs.length === 0 || this.checkedSpecs.includes(i['規格']);
                const matchQty = this.checkedQtys.length === 0 || this.checkedQtys.includes(i['數量']);
                const matchTotalQty = this.checkedTotalQtys.length === 0 || this.checkedTotalQtys.includes(i['總數']);
                const matchPrice = this.checkedPrices.length === 0 || this.checkedPrices.includes(i['單價']);
                const matchTotal = this.checkedTotals.length === 0 || this.checkedTotals.includes(i['總價']);
                const matchRemark = this.checkedRemarks.length === 0 || this.checkedRemarks.includes(i['備註']);
                const matchDelivery = this.checkedDeliverys.length === 0 || this.checkedDeliverys.includes(i['Delivery Date 廠商承諾交期']);
                const matchSod = this.checkedSods.length === 0 || this.checkedSods.includes(i['SOD Qty 廠商承諾數量']);
                const matchAccept = this.checkedAccepts.length === 0 || this.checkedAccepts.includes(i['驗收數量']);
                const matchReject = this.checkedRejects.length === 0 || this.checkedRejects.includes(i['拒收數量']);
                const matchInvoice = this.checkedInvoices.length === 0 || this.checkedInvoices.includes(i['發票月份']);
                
                return matchAcceptance && matchEPR && matchPO && matchItem && matchName && matchSpec && matchQty && matchTotalQty && matchPrice 
                    && matchTotal && matchRemark && matchDelivery && matchDelivery && matchSod && matchAccept && matchReject
                    && matchInvoice;
            });
        },

        uniqueAcceptance(){
                const baseData = this.dateFilterActive ? this.dateFilteredItems : this.items;
                return Array.from(new Set(
                    baseData
                        .filter(i => {
                            const matchEPR = this.checkedEPRs.length === 0 || this.checkedEPRs.includes(i['ePR No.']);
                            const matchPO = this.checkedPOs.length === 0 || this.checkedPOs.includes(i['PO No.']);
                            const matchItem = this.checkedItems.length === 0 || this.checkedItems.includes(i['Item']);
                            const matchName = this.checkedNames.length === 0 || this.checkedNames.includes(i['品項']);
                            const matchSpec = this.checkedSpecs.length === 0 || this.checkedSpecs.includes(i['規格']);
                            const matchQty = this.checkedQtys.length === 0 || this.checkedQtys.includes(i['數量']);
                            const matchTotalQty = this.checkedTotalQtys.length === 0 || this.checkedTotalQtys.includes(i['總數']);
                            const matchPrice = this.checkedPrices.length === 0 || this.checkedPrices.includes(i['單價']);
                            const matchTotal = this.checkedTotals.length === 0 || this.checkedTotals.includes(i['總價']);
                            const matchRemark = this.checkedRemarks.length === 0 || this.checkedRemarks.includes(i['備註']);
                            const matchDelivery = this.checkedDeliverys.length === 0 || this.checkedDeliverys.includes(i['Delivery Date 廠商承諾交期']);
                            const matchSod = this.checkedSods.length === 0 || this.checkedSods.includes(i['SOD Qty 廠商承諾數量']);
                            const matchAccept = this.checkedAccepts.length === 0 || this.checkedAccepts.includes(i['驗收數量']);
                            const matchReject = this.checkedRejects.length === 0 || this.checkedRejects.includes(i['拒收數量']);
                            const matchInvoice = this.checkedInvoices.length === 0 || this.checkedInvoices.includes(i['發票月份']);

                            return matchPO && matchItem && matchName && matchSpec && matchQty && matchTotalQty && matchPrice &&
                                matchTotal && matchRemark && matchDelivery && matchSod && matchAccept && matchReject && matchInvoice;
                        })
                        .map(i => {
                            const value = i['交貨驗證'];
                            // 將 null、undefined、空字串統一顯示為 "(空白)"
                            if (value === null || value === undefined || value === '') {
                                return '(空白)';
                            }
                            return value;
                        })
            )).sort();
        },


        uniqueEpr() {
            const baseData = this.dateFilterActive ? this.dateFilteredItems : this.items;
                return Array.from(new Set(
                    baseData
                        .filter(i => {
                            const matchAcceptance = this.checkedAcceptances.length === 0 || this.checkedAcceptances.includes(i['交貨驗證']);
                            const matchPO = this.checkedPOs.length === 0 || this.checkedPOs.includes(i['PO No.']);
                            const matchItem = this.checkedItems.length === 0 || this.checkedItems.includes(i['Item']);
                            const matchName = this.checkedNames.length === 0 || this.checkedNames.includes(i['品項']);
                            const matchSpec = this.checkedSpecs.length === 0 || this.checkedSpecs.includes(i['規格']);
                            const matchQty = this.checkedQtys.length === 0 || this.checkedQtys.includes(i['數量']);
                            const matchTotalQty = this.checkedTotalQtys.length === 0 || this.checkedTotalQtys.includes(i['總數']);
                            const matchPrice = this.checkedPrices.length === 0 || this.checkedPrices.includes(i['單價']);
                            const matchTotal = this.checkedTotals.length === 0 || this.checkedTotals.includes(i['總價']);
                            const matchRemark = this.checkedRemarks.length === 0 || this.checkedRemarks.includes(i['備註']);
                            const matchDelivery = this.checkedDeliverys.length === 0 || this.checkedDeliverys.includes(i['Delivery Date 廠商承諾交期']);
                            const matchSod = this.checkedSods.length === 0 || this.checkedSods.includes(i['SOD Qty 廠商承諾數量']);
                            const matchAccept = this.checkedAccepts.length === 0 || this.checkedAccepts.includes(i['驗收數量']);
                            const matchReject = this.checkedRejects.length === 0 || this.checkedRejects.includes(i['拒收數量']);
                            const matchInvoice = this.checkedInvoices.length === 0 || this.checkedInvoices.includes(i['發票月份']);

                            return matchAcceptance && matchPO && matchItem && matchName && matchSpec && matchQty && matchTotalQty && matchPrice &&
                                matchTotal && matchRemark && matchDelivery && matchSod && matchAccept && matchReject && matchInvoice;
                        })
                .map(i => i['ePR No.'] || '')
            )).sort();
        },


        uniquePo() {
            const baseData = this.dateFilterActive ? this.dateFilteredItems : this.items;
                return Array.from(new Set(
                    baseData
                        .filter(i => {
                            const matchAcceptance = this.checkedAcceptances.length === 0 || this.checkedAcceptances.includes(i['交貨驗證']);
                            const matchEPR = this.checkedEPRs.length === 0 || this.checkedEPRs.includes(i['ePR No.']);
                            const matchItem = this.checkedItems.length === 0 || this.checkedItems.includes(i['Item']);
                            const matchName = this.checkedNames.length === 0 || this.checkedNames.includes(i['品項']);
                            const matchSpec = this.checkedSpecs.length === 0 || this.checkedSpecs.includes(i['規格']);
                            const matchQty = this.checkedQtys.length === 0 || this.checkedQtys.includes(i['數量']);
                            const matchTotalQty = this.checkedTotalQtys.length === 0 || this.checkedTotalQtys.includes(i['總數']);
                            const matchPrice = this.checkedPrices.length === 0 || this.checkedPrices.includes(i['單價']);
                            const matchTotal = this.checkedTotals.length === 0 || this.checkedTotals.includes(i['總價']);
                            const matchRemark = this.checkedRemarks.length === 0 || this.checkedRemarks.includes(i['備註']);
                            const matchDelivery = this.checkedDeliverys.length === 0 || this.checkedDeliverys.includes(i['Delivery Date 廠商承諾交期']);
                            const matchSod = this.checkedSods.length === 0 || this.checkedSods.includes(i['SOD Qty 廠商承諾數量']);
                            const matchAccept = this.checkedAccepts.length === 0 || this.checkedAccepts.includes(i['驗收數量']);
                            const matchReject = this.checkedRejects.length === 0 || this.checkedRejects.includes(i['拒收數量']);
                            const matchInvoice = this.checkedInvoices.length === 0 || this.checkedInvoices.includes(i['發票月份']);

                            return matchAcceptance && matchEPR && matchItem && matchName && matchSpec && matchQty && matchTotalQty && matchPrice &&
                                matchTotal && matchRemark && matchDelivery && matchSod && matchAccept && matchReject && matchInvoice;
                        })
                .map(i => i['PO No.'] || '')
            )).sort();
        },

        // Item
        uniqueItem() {
            const baseData = this.dateFilterActive ? this.dateFilteredItems : this.items;
                return Array.from(new Set(
                    baseData
                        .filter(i => {
                            const matchAcceptance = this.checkedAcceptances.length === 0 || this.checkedAcceptances.includes(i['交貨驗證']);
                            const matchEPR = this.checkedEPRs.length === 0 || this.checkedEPRs.includes(i['ePR No.']);
                            const matchPO = this.checkedPOs.length === 0 || this.checkedEPRs.includes(i['PO No.']);
                            const matchName = this.checkedNames.length === 0 || this.checkedNames.includes(i['品項']);
                            const matchSpec = this.checkedSpecs.length === 0 || this.checkedSpecs.includes(i['規格']);
                            const matchQty = this.checkedQtys.length === 0 || this.checkedQtys.includes(i['數量']);
                            const matchTotalQty = this.checkedTotalQtys.length === 0 || this.checkedTotalQtys.includes(i['總數']);
                            const matchPrice = this.checkedPrices.length === 0 || this.checkedPrices.includes(i['單價']);
                            const matchTotal = this.checkedTotals.length === 0 || this.checkedTotals.includes(i['總價']);
                            const matchRemark = this.checkedRemarks.length === 0 || this.checkedRemarks.includes(i['備註']);
                            const matchDelivery = this.checkedDeliverys.length === 0 || this.checkedDeliverys.includes(i['Delivery Date 廠商承諾交期']);
                            const matchSod = this.checkedSods.length === 0 || this.checkedSods.includes(i['SOD Qty 廠商承諾數量']);
                            const matchAccept = this.checkedAccepts.length === 0 || this.checkedAccepts.includes(i['驗收數量']);
                            const matchReject = this.checkedRejects.length === 0 || this.checkedRejects.includes(i['拒收數量']);
                            const matchInvoice = this.checkedInvoices.length === 0 || this.checkedInvoices.includes(i['發票月份']);
                            

                            return matchAcceptance && matchEPR && matchPO && matchName && matchSpec && matchQty && matchTotalQty && matchPrice &&
                            matchTotal && matchRemark && matchDelivery && matchSod && matchAccept && matchReject && matchInvoice;
                        })
                .map(i => i['Item'] || '')
            )).sort();
        },

        // 品項
        uniqueName() {
            const baseData = this.dateFilterActive ? this.dateFilteredItems : this.items;
                return Array.from(new Set(
                    baseData
                        .filter(i => {
                            const matchAcceptance = this.checkedAcceptances.length === 0 || this.checkedAcceptances.includes(i['交貨驗證']);
                            const matchEPR = this.checkedEPRs.length === 0 || this.checkedEPRs.includes(i['ePR No.']);
                            const matchPO = this.checkedPOs.length === 0 || this.checkedPOs.includes(i['PO No.']);
                            const matchItem = this.checkedItems.length === 0 || this.checkedItems.includes(i['Item']);
                            const matchSpec = this.checkedSpecs.length === 0 || this.checkedSpecs.includes(i['規格']);
                            const matchQty = this.checkedQtys.length === 0 || this.checkedQtys.includes(i['數量']);
                            const matchTotalQty = this.checkedTotalQtys.length === 0 || this.checkedTotalQtys.includes(i['總數']);
                            const matchPrice = this.checkedPrices.length === 0 || this.checkedPrices.includes(i['單價']);
                            const matchTotal = this.checkedTotals.length === 0 || this.checkedTotals.includes(i['總價']);
                            const matchRemark = this.checkedRemarks.length === 0 || this.checkedRemarks.includes(i['備註']);
                            const matchDelivery = this.checkedDeliverys.length === 0 || this.checkedDeliverys.includes(i['Delivery Date 廠商承諾交期']);
                            const matchSod = this.checkedSods.length === 0 || this.checkedSods.includes(i['SOD Qty 廠商承諾數量']);
                            const matchAccept = this.checkedAccepts.length === 0 || this.checkedAccepts.includes(i['驗收數量']);
                            const matchReject = this.checkedRejects.length === 0 || this.checkedRejects.includes(i['拒收數量']);
                            const matchInvoice = this.checkedInvoices.length === 0 || this.checkedInvoices.includes(i['發票月份']);

                            return matchAcceptance && matchEPR && matchPO && matchItem && matchSpec && matchQty && matchTotalQty && matchPrice &&
                                matchTotal && matchRemark && matchDelivery && matchSod && matchAccept && matchReject && matchInvoice;
                        })
                .map(i => i['品項'] || '')
            )).sort();
        },

        // 規格
        uniqueSpec() {
            const baseData = this.dateFilterActive ? this.dateFilteredItems : this.items;
                return Array.from(new Set(
                    baseData
                        .filter(i => {
                            const matchAcceptance = this.checkedAcceptances.length === 0 || this.checkedAcceptances.includes(i['交貨驗證']);
                            const matchEPR = this.checkedEPRs.length === 0 || this.checkedEPRs.includes(i['ePR No.']);
                            const matchPO = this.checkedPOs.length === 0 || this.checkedPOs.includes(i['PO No.']);
                            const matchItem = this.checkedItems.length === 0 || this.checkedItems.includes(i['Item']);
                            const matchName = this.checkedNames.length === 0 || this.checkedNames.includes(i['品項']);
                            const matchQty = this.checkedQtys.length === 0 || this.checkedQtys.includes(i['數量']);
                            const matchTotalQty = this.checkedTotalQtys.length === 0 || this.checkedTotalQtys.includes(i['總數']);
                            const matchPrice = this.checkedPrices.length === 0 || this.checkedPrices.includes(i['單價']);
                            const matchTotal = this.checkedTotals.length === 0 || this.checkedTotals.includes(i['總價']);
                            const matchRemark = this.checkedRemarks.length === 0 || this.checkedRemarks.includes(i['備註']);
                            const matchDelivery = this.checkedDeliverys.length === 0 || this.checkedDeliverys.includes(i['Delivery Date 廠商承諾交期']);
                            const matchSod = this.checkedSods.length === 0 || this.checkedSods.includes(i['SOD Qty 廠商承諾數量']);
                            const matchAccept = this.checkedAccepts.length === 0 || this.checkedAccepts.includes(i['驗收數量']);
                            const matchReject = this.checkedRejects.length === 0 || this.checkedRejects.includes(i['拒收數量']);
                            const matchInvoice = this.checkedInvoices.length === 0 || this.checkedInvoices.includes(i['發票月份']);

                            return matchAcceptance && matchEPR && matchPO &&matchItem && matchName && matchQty && matchTotalQty && matchPrice &&
                                matchTotal && matchRemark && matchDelivery && matchSod && matchAccept && matchReject && matchInvoice;
                        })
                .map(i => i['規格'] || '')
            )).sort();
        },

        // 數量
        uniqueQty() {
            const baseData = this.dateFilterActive ? this.dateFilteredItems : this.items;
                return Array.from(new Set(
                    baseData
                        .filter(i => {
                            const matchAcceptance = this.checkedAcceptances.length === 0 || this.checkedAcceptances.includes(i['交貨驗證']);
                            const matchEPR = this.checkedEPRs.length === 0 || this.checkedEPRs.includes(i['ePR No.']);
                            const matchPO = this.checkedPOs.length === 0 || this.checkedPOs.includes(i['PO No.']);
                            const matchItem = this.checkedItems.length === 0 || this.checkedItems.includes(i['Item']);
                            const matchName = this.checkedNames.length === 0 || this.checkedNames.includes(i['品項']);
                            const matchSpec = this.checkedSpecs.length === 0 || this.checkedSpecs.includes(i['規格']);
                            const matchTotalQty = this.checkedTotalQtys.length === 0 || this.checkedTotalQtys.includes(i['總數']);
                            const matchPrice = this.checkedPrices.length === 0 || this.checkedPrices.includes(i['單價']);
                            const matchTotal = this.checkedTotals.length === 0 || this.checkedTotals.includes(i['總價']);
                            const matchRemark = this.checkedRemarks.length === 0 || this.checkedRemarks.includes(i['備註']);
                            const matchDelivery = this.checkedDeliverys.length === 0 || this.checkedDeliverys.includes(i['Delivery Date 廠商承諾交期']);
                            const matchSod = this.checkedSods.length === 0 || this.checkedSods.includes(i['SOD Qty 廠商承諾數量']);
                            const matchAccept = this.checkedAccepts.length === 0 || this.checkedAccepts.includes(i['驗收數量']);
                            const matchReject = this.checkedRejects.length === 0 || this.checkedRejects.includes(i['拒收數量']);
                            const matchInvoice = this.checkedInvoices.length === 0 || this.checkedInvoices.includes(i['發票月份']);


                            return matchAcceptance && matchEPR && matchPO &&matchItem && matchName && matchSpec && matchTotalQty && matchPrice &&
                                matchTotal && matchRemark && matchDelivery && matchSod && matchAccept && matchReject && matchInvoice;
                        })
                .map(i => i['數量'] || '')
            )).sort();
        },

        // 總數
        uniqueTotalQty() {
            const baseData = this.dateFilterActive ? this.dateFilteredItems : this.items;
                return Array.from(new Set(
                    baseData
                        .filter(i => {
                            const matchAcceptance = this.checkedAcceptances.length === 0 || this.checkedAcceptances.includes(i['交貨驗證']);
                            const matchEPR = this.checkedEPRs.length === 0 || this.checkedEPRs.includes(i['ePR No.']);
                            const matchPO = this.checkedPOs.length === 0 || this.checkedPOs.includes(i['PO No.']);
                            const matchItem = this.checkedItems.length === 0 || this.checkedItems.includes(i['Item']);
                            const matchName = this.checkedNames.length === 0 || this.checkedNames.includes(i['品項']);
                            const matchSpec = this.checkedSpecs.length === 0 || this.checkedSpecs.includes(i['規格']);
                            const matchQty = this.checkedQtys.length === 0 || this.checkedQtys.includes(i['數量']);
                            const matchPrice = this.checkedPrices.length === 0 || this.checkedPrices.includes(i['單價']);
                            const matchTotal = this.checkedTotals.length === 0 || this.checkedTotals.includes(i['總價']);
                            const matchRemark = this.checkedRemarks.length === 0 || this.checkedRemarks.includes(i['備註']);
                            const matchDelivery = this.checkedDeliverys.length === 0 || this.checkedDeliverys.includes(i['Delivery Date 廠商承諾交期']);
                            const matchSod = this.checkedSods.length === 0 || this.checkedSods.includes(i['SOD Qty 廠商承諾數量']);
                            const matchAccept = this.checkedAccepts.length === 0 || this.checkedAccepts.includes(i['驗收數量']);
                            const matchReject = this.checkedRejects.length === 0 || this.checkedRejects.includes(i['拒收數量']);
                            const matchInvoice = this.checkedInvoices.length === 0 || this.checkedInvoices.includes(i['發票月份']);

                            return matchAcceptance && matchEPR && matchPO &&matchItem && matchName && matchSpec && matchQty && matchPrice &&
                                matchTotal && matchRemark && matchDelivery && matchSod && matchAccept && matchReject && matchInvoice;
                        })
                .map(i => i['總數'] || '')
            )).sort();
        },

        // 單價
        uniquePrice() {
            const baseData = this.dateFilterActive ? this.dateFilteredItems : this.items;
                return Array.from(new Set(
                    baseData
                        .filter(i => {
                            const matchAcceptance = this.checkedAcceptances.length === 0 || this.checkedAcceptances.includes(i['交貨驗證']);
                            const matchEPR = this.checkedEPRs.length === 0 || this.checkedEPRs.includes(i['ePR No.']);
                            const matchPO = this.checkedPOs.length === 0 || this.checkedPOs.includes(i['PO No.']);
                            const matchItem = this.checkedItems.length === 0 || this.checkedItems.includes(i['Item']);
                            const matchName = this.checkedNames.length === 0 || this.checkedNames.includes(i['品項']);
                            const matchSpec = this.checkedSpecs.length === 0 || this.checkedSpecs.includes(i['規格']);
                            const matchQty = this.checkedQtys.length === 0 || this.checkedQtys.includes(i['數量']);
                            const matchTotalQty = this.checkedTotalQtys.length === 0 || this.checkedTotalQtys.includes(i['總數']);
                            const matchTotal = this.checkedTotals.length === 0 || this.checkedTotals.includes(i['總價']);
                            const matchRemark = this.checkedRemarks.length === 0 || this.checkedRemarks.includes(i['備註']);
                            const matchDelivery = this.checkedDeliverys.length === 0 || this.checkedDeliverys.includes(i['Delivery Date 廠商承諾交期']);
                            const matchSod = this.checkedSods.length === 0 || this.checkedSods.includes(i['SOD Qty 廠商承諾數量']);
                            const matchAccept = this.checkedAccepts.length === 0 || this.checkedAccepts.includes(i['驗收數量']);
                            const matchReject = this.checkedRejects.length === 0 || this.checkedRejects.includes(i['拒收數量']);
                            const matchInvoice = this.checkedInvoices.length === 0 || this.checkedInvoices.includes(i['發票月份']);

                            return matchAcceptance && matchEPR && matchPO &&matchItem && matchName && matchSpec && matchQty && matchTotalQty &&
                                matchTotal && matchRemark && matchDelivery && matchSod && matchAccept && matchReject && matchInvoice;
                        })
                .map(i => i['單價'] || '')
            )).sort();
        },

        // 總價
        uniqueTotal() {
            const baseData = this.dateFilterActive ? this.dateFilteredItems : this.items;
                return Array.from(new Set(
                    baseData
                        .filter(i => {
                            const matchAcceptance = this.checkedAcceptances.length === 0 || this.checkedAcceptances.includes(i['交貨驗證']);
                            const matchEPR = this.checkedEPRs.length === 0 || this.checkedEPRs.includes(i['ePR No.']);
                            const matchPO = this.checkedPOs.length === 0 || this.checkedPOs.includes(i['PO No.']);
                            const matchItem = this.checkedItems.length === 0 || this.checkedItems.includes(i['Item']);
                            const matchName = this.checkedNames.length === 0 || this.checkedNames.includes(i['品項']);
                            const matchSpec = this.checkedSpecs.length === 0 || this.checkedSpecs.includes(i['規格']);
                            const matchQty = this.checkedQtys.length === 0 || this.checkedQtys.includes(i['數量']);
                            const matchTotalQty = this.checkedTotalQtys.length === 0 || this.checkedTotalQtys.includes(i['總數']);
                            const matchPrice = this.checkedPrices.length === 0 || this.checkedPrices.includes(i['單價']);
                            const matchRemark = this.checkedRemarks.length === 0 || this.checkedRemarks.includes(i['備註']);
                            const matchDelivery = this.checkedDeliverys.length === 0 || this.checkedDeliverys.includes(i['Delivery Date 廠商承諾交期']);
                            const matchSod = this.checkedSods.length === 0 || this.checkedSods.includes(i['SOD Qty 廠商承諾數量']);
                            const matchAccept = this.checkedAccepts.length === 0 || this.checkedAccepts.includes(i['驗收數量']);
                            const matchReject = this.checkedRejects.length === 0 || this.checkedRejects.includes(i['拒收數量']);
                            const matchInvoice = this.checkedInvoices.length === 0 || this.checkedInvoices.includes(i['發票月份']);

                            return matchAcceptance && matchEPR && matchPO &&matchItem && matchName && matchSpec && matchQty && matchTotalQty && matchPrice &&
                                matchRemark && matchDelivery && matchSod && matchAccept && matchReject && matchInvoice;
                        })
                .map(i => String(i['總價']).trim()) 
                .filter(v => v !== '')
            )).sort((a, b) => Number(a) - Number(b));
        },

        // 備註
        uniqueRemark() {
            const baseData = this.dateFilterActive ? this.dateFilteredItems : this.items;
                return Array.from(new Set(
                    baseData
                        .filter(i => {
                            const matchAcceptance = this.checkedAcceptances.length === 0 || this.checkedAcceptances.includes(i['交貨驗證']);
                            const matchEPR = this.checkedEPRs.length === 0 || this.checkedEPRs.includes(i['ePR No.']);
                            const matchPO = this.checkedPOs.length === 0 || this.checkedPOs.includes(i['PO No.']);
                            const matchItem = this.checkedItems.length === 0 || this.checkedItems.includes(i['Item']);
                            const matchName = this.checkedNames.length === 0 || this.checkedNames.includes(i['品項']);
                            const matchSpec = this.checkedSpecs.length === 0 || this.checkedSpecs.includes(i['規格']);
                            const matchQty = this.checkedQtys.length === 0 || this.checkedQtys.includes(i['數量']);
                            const matchTotalQty = this.checkedTotalQtys.length === 0 || this.checkedTotalQtys.includes(i['總數']);
                            const matchPrice = this.checkedPrices.length === 0 || this.checkedPrices.includes(i['單價']);
                            const matchTotal = this.checkedTotals.length === 0 || this.checkedTotals.includes(i['總價']);
                            const matchDelivery = this.checkedDeliverys.length === 0 || this.checkedDeliverys.includes(i['Delivery Date 廠商承諾交期']);
                            const matchSod = this.checkedSods.length === 0 || this.checkedSods.includes(i['SOD Qty 廠商承諾數量']);
                            const matchAccept = this.checkedAccepts.length === 0 || this.checkedAccepts.includes(i['驗收數量']);
                            const matchReject = this.checkedRejects.length === 0 || this.checkedRejects.includes(i['拒收數量']);
                            const matchInvoice = this.checkedInvoices.length === 0 || this.checkedInvoices.includes(i['發票月份']);

                            return matchAcceptance && matchEPR && matchPO &&matchItem && matchName && matchSpec && matchQty && matchTotalQty && matchPrice && 
                                matchTotal && matchDelivery && matchSod && matchAccept && matchReject && matchInvoice;
                        })
                .map(i => i['備註'] || '')
            )).sort();
        },

        // Delivery Date 廠商承諾交期
        uniqueDelivery() {
            const baseData = this.dateFilterActive ? this.dateFilteredItems : this.items;
                return Array.from(new Set(
                    baseData
                        .filter(i => {
                            const matchAcceptance = this.checkedAcceptances.length === 0 || this.checkedAcceptances.includes(i['交貨驗證']);
                            const matchEPR = this.checkedEPRs.length === 0 || this.checkedEPRs.includes(i['ePR No.']);
                            const matchPO = this.checkedPOs.length === 0 || this.checkedPOs.includes(i['PO No.']);
                            const matchItem = this.checkedItems.length === 0 || this.checkedItems.includes(i['Item']);
                            const matchName = this.checkedNames.length === 0 || this.checkedNames.includes(i['品項']);
                            const matchSpec = this.checkedSpecs.length === 0 || this.checkedSpecs.includes(i['規格']);
                            const matchQty = this.checkedQtys.length === 0 || this.checkedQtys.includes(i['數量']);
                            const matchTotalQty = this.checkedTotalQtys.length === 0 || this.checkedTotalQtys.includes(i['總數']);
                            const matchPrice = this.checkedPrices.length === 0 || this.checkedPrices.includes(i['單價']);
                            const matchTotal = this.checkedTotals.length === 0 || this.checkedTotals.includes(i['總價']);
                            const matchRemark = this.checkedRemarks.length === 0 || this.checkedRemarks.includes(i['備註']);
                            const matchSod = this.checkedSods.length === 0 || this.checkedSods.includes(i['SOD Qty 廠商承諾數量']);
                            const matchAccept = this.checkedAccepts.length === 0 || this.checkedAccepts.includes(i['驗收數量']);
                            const matchReject = this.checkedRejects.length === 0 || this.checkedRejects.includes(i['拒收數量']);
                            const matchInvoice = this.checkedInvoices.length === 0 || this.checkedInvoices.includes(i['發票月份']);

                            return matchAcceptance && matchEPR && matchPO &&matchItem && matchName && matchSpec && matchQty && matchTotalQty && matchPrice && 
                                matchTotal && matchRemark && matchSod && matchAccept && matchReject && matchInvoice;
                        })
                .map(i => i['Delivery Date 廠商承諾交期'] || '')
            )).sort();
        },

        // SOD Qty 廠商承諾數量
        uniqueSod() {
            const baseData = this.dateFilterActive ? this.dateFilteredItems : this.items;
                return Array.from(new Set(
                    baseData
                        .filter(i => {
                            const matchAcceptance = this.checkedAcceptances.length === 0 || this.checkedAcceptances.includes(i['交貨驗證']);
                            const matchEPR = this.checkedEPRs.length === 0 || this.checkedEPRs.includes(i['ePR No.']);
                            const matchPO = this.checkedPOs.length === 0 || this.checkedPOs.includes(i['PO No.']);
                            const matchItem = this.checkedItems.length === 0 || this.checkedItems.includes(i['Item']);
                            const matchName = this.checkedNames.length === 0 || this.checkedNames.includes(i['品項']);
                            const matchSpec = this.checkedSpecs.length === 0 || this.checkedSpecs.includes(i['規格']);
                            const matchQty = this.checkedQtys.length === 0 || this.checkedQtys.includes(i['數量']);
                            const matchTotalQty = this.checkedTotalQtys.length === 0 || this.checkedTotalQtys.includes(i['總數']);
                            const matchPrice = this.checkedPrices.length === 0 || this.checkedPrices.includes(i['單價']);
                            const matchTotal = this.checkedTotals.length === 0 || this.checkedTotals.includes(i['總價']);
                            const matchRemark = this.checkedRemarks.length === 0 || this.checkedRemarks.includes(i['備註']);
                            const matchDelivery = this.checkedDeliverys.length === 0 || this.checkedDeliverys.includes(i['Delivery Date 廠商承諾交期']);
                            const matchAccept = this.checkedAccepts.length === 0 || this.checkedAccepts.includes(i['驗收數量']);
                            const matchReject = this.checkedRejects.length === 0 || this.checkedRejects.includes(i['拒收數量']);
                            const matchInvoice = this.checkedInvoices.length === 0 || this.checkedInvoices.includes(i['發票月份']);

                            return matchAcceptance && matchEPR && matchPO &&matchItem && matchName && matchSpec && matchQty && matchTotalQty && matchPrice && 
                                matchTotal && matchRemark && matchDelivery && matchAccept && matchReject && matchInvoice;
                        })
                .map(i => i['SOD Qty 廠商承諾數量'] || '')
            )).sort();
        },

        // 驗收數量
        uniqueAccept() {
            const baseData = this.dateFilterActive ? this.dateFilteredItems : this.items;
                return Array.from(new Set(
                    baseData
                        .filter(i => {
                            const matchAcceptance = this.checkedAcceptances.length === 0 || this.checkedAcceptances.includes(i['交貨驗證']);
                            const matchEPR = this.checkedEPRs.length === 0 || this.checkedEPRs.includes(i['ePR No.']);
                            const matchPO = this.checkedPOs.length === 0 || this.checkedPOs.includes(i['PO No.']);
                            const matchItem = this.checkedItems.length === 0 || this.checkedItems.includes(i['Item']);
                            const matchName = this.checkedNames.length === 0 || this.checkedNames.includes(i['品項']);
                            const matchSpec = this.checkedSpecs.length === 0 || this.checkedSpecs.includes(i['規格']);
                            const matchQty = this.checkedQtys.length === 0 || this.checkedQtys.includes(i['數量']);
                            const matchTotalQty = this.checkedTotalQtys.length === 0 || this.checkedTotalQtys.includes(i['總數']);
                            const matchPrice = this.checkedPrices.length === 0 || this.checkedPrices.includes(i['單價']);
                            const matchTotal = this.checkedTotals.length === 0 || this.checkedTotals.includes(i['總價']);
                            const matchRemark = this.checkedRemarks.length === 0 || this.checkedRemarks.includes(i['備註']);
                            const matchDelivery = this.checkedDeliverys.length === 0 || this.checkedDeliverys.includes(i['Delivery Date 廠商承諾交期']);
                            const matchSod = this.checkedSods.length === 0 || this.checkedSods.includes(i['SOD Qty 廠商承諾數量']);
                            const matchReject = this.checkedRejects.length === 0 || this.checkedRejects.includes(i['拒收數量']);
                            const matchInvoice = this.checkedInvoices.length === 0 || this.checkedInvoices.includes(i['發票月份']);

                            return matchAcceptance && matchEPR && matchPO &&matchItem && matchName && matchSpec && matchQty && matchTotalQty && matchPrice && 
                                matchTotal && matchRemark && matchDelivery && matchSod && matchReject && matchInvoice;
                        })
                .map(i => i['驗收數量'] || '')
            )).sort();
        },

        // 拒收數量
        uniqueReject() {
            const baseData = this.dateFilterActive ? this.dateFilteredItems : this.items;
                return Array.from(new Set(
                    baseData
                        .filter(i => {
                            const matchAcceptance = this.checkedAcceptances.length === 0 || this.checkedAcceptances.includes(i['交貨驗證']);
                            const matchEPR = this.checkedEPRs.length === 0 || this.checkedEPRs.includes(i['ePR No.']);
                            const matchPO = this.checkedPOs.length === 0 || this.checkedPOs.includes(i['PO No.']);
                            const matchItem = this.checkedItems.length === 0 || this.checkedItems.includes(i['Item']);
                            const matchName = this.checkedNames.length === 0 || this.checkedNames.includes(i['品項']);
                            const matchSpec = this.checkedSpecs.length === 0 || this.checkedSpecs.includes(i['規格']);
                            const matchQty = this.checkedQtys.length === 0 || this.checkedQtys.includes(i['數量']);
                            const matchTotalQty = this.checkedTotalQtys.length === 0 || this.checkedTotalQtys.includes(i['總數']);
                            const matchPrice = this.checkedPrices.length === 0 || this.checkedPrices.includes(i['單價']);
                            const matchTotal = this.checkedTotals.length === 0 || this.checkedTotals.includes(i['總價']);
                            const matchRemark = this.checkedRemarks.length === 0 || this.checkedRemarks.includes(i['備註']);
                            const matchDelivery = this.checkedDeliverys.length === 0 || this.checkedDeliverys.includes(i['Delivery Date 廠商承諾交期']);
                            const matchSod = this.checkedSods.length === 0 || this.checkedSods.includes(i['SOD Qty 廠商承諾數量']);
                            const matchAccept = this.checkedAccepts.length === 0 || this.checkedAccepts.includes(i['驗收數量']);
                            const matchInvoice = this.checkedInvoices.length === 0 || this.checkedInvoices.includes(i['發票月份']);

                            return matchAcceptance && matchEPR && matchPO &&matchItem && matchName && matchSpec && matchQty && matchTotalQty && matchPrice && 
                                matchTotal && matchRemark && matchDelivery && matchSod && matchAccept && matchInvoice;
                        })
                .map(i => i['拒收數量'] || '')
            )).sort();
        },

        // 發票月份
        uniqueInvoice() {
            const baseData = this.dateFilterActive ? this.dateFilteredItems : this.items;
            return Array.from(new Set(
                baseData
                    .filter(i => {
                            const matchAcceptance = this.checkedAcceptances.length === 0 || this.checkedAcceptances.includes(i['交貨驗證']);
                            const matchEPR = this.checkedEPRs.length === 0 || this.checkedEPRs.includes(i['ePR No.']);
                            const matchPO = this.checkedPOs.length === 0 || this.checkedPOs.includes(i['PO No.']);
                            const matchItem = this.checkedItems.length === 0 || this.checkedItems.includes(i['Item']);
                            const matchName = this.checkedNames.length === 0 || this.checkedNames.includes(i['品項']);
                            const matchSpec = this.checkedSpecs.length === 0 || this.checkedSpecs.includes(i['規格']);
                            const matchQty = this.checkedQtys.length === 0 || this.checkedQtys.includes(i['數量']);
                            const matchTotalQty = this.checkedTotalQtys.length === 0 || this.checkedTotalQtys.includes(i['總數']);
                            const matchPrice = this.checkedPrices.length === 0 || this.checkedPrices.includes(i['單價']);
                            const matchTotal = this.checkedTotals.length === 0 || this.checkedTotals.includes(i['總價']);
                            const matchRemark = this.checkedRemarks.length === 0 || this.checkedRemarks.includes(i['備註']);
                            const matchDelivery = this.checkedDeliverys.length === 0 || this.checkedDeliverys.includes(i['Delivery Date 廠商承諾交期']);
                            const matchSod = this.checkedSods.length === 0 || this.checkedSods.includes(i['SOD Qty 廠商承諾數量']);
                            const matchAccept = this.checkedAccepts.length === 0 || this.checkedAccepts.includes(i['驗收數量']);
                            const matchReject = this.checkedRejects.length === 0 || this.checkedRejects.includes(i['拒收數量']);

                            return matchAcceptance && matchEPR && matchPO &&matchItem && matchName && matchSpec && matchQty && matchTotalQty && matchPrice && 
                                matchTotal && matchRemark && matchDelivery && matchSod && matchAccept && matchReject;
                    })
                    .map(i => {
                        const date = String(i['發票月份']);
                        return date.length === 8 ? `${date.slice(0, 4)}/${date.slice(4, 6)}/${date.slice(6, 8)}` : date;
                    })
                .filter(Boolean)
            )).sort((a, b) => new Date(b) - new Date(a));
        },

        // 安全取值計算
        safeCurrentUnInvoicedAmount() {
            return Number(this.currentUnInvoicedAmount) || 0;
        },
        safeSelectedMonthlyInvoiceAmount() {
            return Number(this.selectedMonthlyInvoiceAmount) || 0;
        },
        safeCurrentMonthUnInvoicedAmount() {
            return Number(this.currentMonthUnInvoicedAmount) || 0;
        },
        safeSelectedCurrentMonthInvoiceAmount() {
            return Number(this.selectedCurrentMonthInvoiceAmount) || 0;
        },
        safeBudgetLimit() {
            return Number(this.budgetLimit) || 0;
        },

        // 修正：上限管制 = 預算上限 - 100,000 (預留管制額度)
        budgetControlAmount() {
            const limit = this.safeBudgetLimit;           // 1,500,000
            const controlReserve = 100000;               // 預留 10 萬管制額度
            const controlLimit = limit - controlReserve; // 1,400,000
            return Math.max(0, controlLimit);
        },

        // 修正後的 currentMonthBalance 計算：只有當兩個月份選擇一致時才計算餘額
        currentMonthBalance() {
            console.log('🔍 開始計算本月入帳餘額...');
            console.log('selectedCurrentMonth:', this.selectedCurrentMonth);
            console.log('selectedBudgetMonth:', this.selectedBudgetMonth);
            console.log('budgetMonthOptions:', this.budgetMonthOptions);
            console.log('safeSelectedCurrentMonthInvoiceAmount:', this.safeSelectedCurrentMonthInvoiceAmount);
            
            // 檢查兩個月份選擇是否一致
            if (!this.selectedCurrentMonth || !this.selectedBudgetMonth) {
                console.log('❌ 未選擇完整月份，返回 0');
                return 0;
            }

            if (this.selectedCurrentMonth !== this.selectedBudgetMonth) {
                console.log('❌ 兩個月份選擇不一致，返回 0');
                console.log('- 本月實際入帳月份:', this.selectedCurrentMonth);
                console.log('- 預算月份:', this.selectedBudgetMonth);
                return 0;
            }

            // 根據選擇的月份找到對應的預算上限
            const selectedBudget = this.budgetMonthOptions.find(
                item => item.month === this.selectedCurrentMonth
            );
            
            console.log('找到的預算資料:', selectedBudget);
            
            if (!selectedBudget) {
                console.log('❌ 找不到對應月份的預算資料，返回 0');
                console.log('可用的預算月份:', this.budgetMonthOptions.map(item => item.month));
                return 0;
            }

            const monthlyBudgetLimit = selectedBudget.money;  // 該月份的預算上限
            const monthlyActualAmount = this.safeSelectedCurrentMonthInvoiceAmount; // 該月份的實際入帳
            const balance = monthlyBudgetLimit - monthlyActualAmount;
            
            console.log('💰 餘額計算詳情:');
            console.log('- 月份:', this.selectedCurrentMonth);
            console.log('- 該月預算上限:', monthlyBudgetLimit);
            console.log('- 該月實際入帳:', monthlyActualAmount);
            console.log('- 計算:', monthlyBudgetLimit, '-', monthlyActualAmount, '=', balance);
            
            return Math.max(0, balance);
        },

        // 新增：檢查兩個月份是否一致的計算屬性
        isMonthSelectionValid() {
            return this.selectedCurrentMonth && 
                   this.selectedBudgetMonth && 
                   this.selectedCurrentMonth === this.selectedBudgetMonth;
        },
    },

    methods: {
        /**
         * 從後端獲取尚未入帳資料
         */
        async fetchAccountingSummary() {
            try {
                const response = await axios.get('http://127.0.0.1:5000/api/accounting-summary');
                this.accountingSummary = response.data;
                console.log('📊 載入尚未入帳資料:', this.accountingSummary);
                
                // 更新尚未入帳月份選項
                this.updateUninvoicedMonthOptions();
            } catch (error) {
                console.error('❌ 載入尚未入帳資料失敗:', error);
                this.accountingSummary = {};
            }
        },

        /**
         * 從後端獲取實際入帳資料
         */
        async fetchMonthlyActualAccounting() {
            try {
                const response = await axios.get('http://127.0.0.1:5000/api/monthly-actual-accounting');
                this.monthlyActualAccounting = response.data;
                console.log('💰 載入實際入帳資料:', this.monthlyActualAccounting);
                
                // 更新實際入帳月份選項
                this.updateInvoiceMonthOptions();
            } catch (error) {
                console.error('❌ 載入實際入帳資料失敗:', error);
                this.monthlyActualAccounting = {};
            }
        },

        /**
         * 更新尚未入帳月份選項 (只處理 accounting_summary.json)
         */
        updateUninvoicedMonthOptions() {
            const months = new Set();
            
            // 只從尚未入帳資料中提取月份
            Object.keys(this.accountingSummary).forEach(monthStr => {
                const match = monthStr.match(/(\d{4})年(\d{1,2})月/);
                if (match) {
                    const year = match[1];
                    const month = match[2].padStart(2, '0');
                    months.add(`${year}${month}`);
                }
            });
            
            this.uninvoicedMonthOptions = Array.from(months)
                .filter(month => /^\d{6}$/.test(month))
                .sort((a, b) => b.localeCompare(a))
                .map(month => ({
                    month: month,
                    label: `${month.slice(0, 4)}年${month.slice(4, 6)}月`
                }));
                
            console.log('📅 更新尚未入帳月份選項:', this.uninvoicedMonthOptions);
        },

        /**
         * 更新發票月份選項 - 修正版：同時處理兩個數據源
         */
        updateInvoiceMonthOptions() {
            const months = new Set();
            
            // 從尚未入帳資料中提取月份（格式：2025年8月）
            Object.keys(this.accountingSummary).forEach(monthStr => {
                // monthStr 格式: "2025年8月"
                const match = monthStr.match(/(\d{4})年(\d{1,2})月/);
                if (match) {
                    const year = match[1];
                    const month = match[2].padStart(2, '0'); // 補零：8 → 08
                    months.add(`${year}${month}`); // 202508
                }
            });
            
            // 從實際入帳資料中提取月份（格式：2025年8月）
            Object.keys(this.monthlyActualAccounting).forEach(monthStr => {
                // monthStr 格式: "2025年8月"  
                const match = monthStr.match(/(\d{4})年(\d{1,2})月/);
                if (match) {
                    const year = match[1];
                    const month = match[2].padStart(2, '0'); // 補零：8 → 08
                    months.add(`${year}${month}`); // 202508
                }
            });
            
            // 轉換為選項格式並排序
            this.invoiceMonthOptions = Array.from(months)
                .filter(month => /^\d{6}$/.test(month)) // 確保格式正確
                .sort((a, b) => b.localeCompare(a)) // 降序排列，最新的在前
                .map(month => ({
                    month: month,
                    label: `${month.slice(0, 4)}年${month.slice(4, 6)}月`
                }));
                
            console.log('📅 更新月份選項:', this.invoiceMonthOptions);
        },

        /**
         * 獲取尚未入帳金額
         */
        getUnInvoicedAmount(month) {
            if (!month) return 0;
            // month 格式：202508 → 轉換為 2025年8月
            const year = month.slice(0, 4);
            const monthNum = parseInt(month.slice(4, 6)); // 去掉前導零
            const yearMonth = `${year}年${monthNum}月`;
            return this.accountingSummary[yearMonth] || 0;
        },

        /**
         * 獲取實際入帳金額
         */
        getActualInvoiceAmount(month) {
            if (!month) return 0;
            // month 格式：202508 → 轉換為 2025年8月
            const year = month.slice(0, 4);
            const monthNum = parseInt(month.slice(4, 6)); // 去掉前導零
            const yearMonth = `${year}年${monthNum}月`;
            return this.monthlyActualAccounting[yearMonth] || 0;
        },

        /**
         * 獲取發票月份標籤
         */
        getInvoiceMonthLabel() {
            if (!this.selectedInvoiceMonth) return '';
            const year = this.selectedInvoiceMonth.slice(0, 4);
            const month = this.selectedInvoiceMonth.slice(4, 6);
            return `${year}年${month}月`;
        },

        /**
         * 獲取當前月份尚未入帳標籤
         */
        getCurrentMonthUnInvoicedLabel() {
            if (!this.selectedCurrentUnInvoicedMonth) return '';
            const year = this.selectedCurrentUnInvoicedMonth.slice(0, 4);
            const month = this.selectedCurrentUnInvoicedMonth.slice(4, 6);
            return `${year}年${month}月`;
        },

        /**
         * 從後端獲取預算月份選項
         */
        async fetchBudgetMonths() {
            try {
                const response = await axios.get('http://127.0.0.1:5000/api/budget_months');
                if (response.data.success) {
                    this.budgetMonthOptions = response.data.budget_list.map(item => ({
                        month: item.month,
                        label: `${item.month.slice(0, 4)}年${item.month.slice(4, 6)}月`,
                        money: item.money,
                        當月請購預算: item.當月請購預算,
                        當月追加預算: item.當月追加預算
                    }));
                    console.log('📅 載入預算月份選項:', this.budgetMonthOptions);
                }
            } catch (error) {
                console.error('❌ 載入預算月份選項失敗:', error);
                this.budgetMonthOptions = [];
            }
        },

        /**
         * 更新預算限制 - 當選擇預算月份時觸發
         */
        updateBudgetLimit() {
            if (!this.selectedBudgetMonth) {
                this.budgetLimit = 0;
                return;
            }

            // 從 budgetMonthOptions 中找到對應月份的預算資料
            const selectedBudget = this.budgetMonthOptions.find(
                item => item.month === this.selectedBudgetMonth
            );

            if (selectedBudget) {
                this.budgetLimit = selectedBudget.money;
                console.log(`💰 設定預算上限: ${this.budgetLimit.toLocaleString()} 元`);
            } else {
                this.budgetLimit = 0;
                console.log('❌ 找不到對應的預算資料');
            }
        },

        async fetchData() {
            try {
                const res = await axios.get('http://127.0.0.1:5000/api/buyer_detail');
                this.data = res.data;
                this.items = res.data;
                console.log('📊 載入資料:', this.items.length, '筆');
                
            } catch (error) {
                console.error('❌ 載入資料失敗:', error);
            }
        },

        handleClickOutside(event) {
            const isACCEPTANCE = this.$refs.ACCEPTANCEFilter?.contains(event.target);
            const isEPR = this.$refs.EPRFilter?.contains(event.target);
            const isPO = this.$refs.POFilter?.contains(event.target);
            const isITEM = this.$refs.ITEMFilter?.contains(event.target);
            const isNAME = this.$refs.NAMEFilter?.contains(event.target);
            const isSPEC = this.$refs.SPECFilter?.contains(event.target);
            const isQTY = this.$refs.QTYFilter?.contains(event.target);
            const isTOTALQTY = this.$refs.TOTALQTYFilter?.contains(event.target);
            const isPRICE = this.$refs.PRICEFilter?.contains(event.target);
            const isTOTAL = this.$refs.TOTALFilter?.contains(event.target);
            const isREMARK = this.$refs.REMARKFilter?.contains(event.target);
            const isDELIVERY = this.$refs.DELIVERYFilter?.contains(event.target);
            const isSOD = this.$refs.SODFilter?.contains(event.target);
            const isACCEPT = this.$refs.ACCEPTFilter?.contains(event.target);
            const isREJECT = this.$refs.REJECTFilter?.contains(event.target);
            const isINVOICE = this.$refs.INVOICEFilter?.contains(event.target);

            if (!isACCEPTANCE) this.showAcceptanceFilter = false;
            if (!isEPR) this.showEPRFilter = false;
            if (!isPO) this.showPOFilter = false;
            if (!isITEM) this.showITEMFilter = false;
            if (!isNAME) this.showNAMEilter = false;
            if (!isSPEC) this.showSPECFilter = false;
            if (!isQTY) this.showQTYFilter = false;
            if (!isTOTALQTY) this.showTOTALQTYFilter = false;
            if (!isPRICE) this.showPRICEFilter = false;
            if (!isTOTAL) this.showTOTALFilter = false;
            if (!isREMARK) this.showREMARKFilter = false;
            if (!isDELIVERY) this.showDELIVERYSFilter = false;
            if (!isSOD) this.showSODFilter = false;
            if (!isACCEPT) this.showACCEPTFilter = false;
            if (!isREJECT) this.showREJECTFilter = false;
            if (!isINVOICE) this.showINVOICEFilter = false;
        },

        beforeUnmount() {
            document.removeEventListener('click', this.handleClickOutside);
        },

        closeAllDropdowns() {            
            // 關閉所有篩選下拉選單
            this.showAcceptanceFilter = false;
            this.showEPRFilter = false;
            this.showPOFilter = false;
            this.showITEMFilter = false;
            this.showNAMEilter = false;
            this.showSPECFilter = false;
            this.showQTYFilter = false;
            this.showTOTALQTYFilter = false;
            this.showPRICEFilter = false;
            this.showTOTALFilter = false;
            this.showREMARKFilter = false;
            this.showDELIVERYSFilter = false;
            this.showSODFilter = false;
            this.showACCEPTFilter = false;
            this.showREJECTFilter = false;
            this.showINVOICEFilter = false;
        },

        toggleDropdown(target) {
            const wasOpen = this[target];
            this.closeAllDropdowns();
            this[target] = !wasOpen;
        },

        autoUpload(e) {
            const file = e.target.files[0];
            if (!file) return;

            const formData = new FormData();
            formData.append("file", file);

            fetch("http://127.0.0.1:5000/api/update_delivery_receipt", {
                method: "POST",
                body: formData,
            })
            .then(response => {
                if (!response.ok) throw new Error("上傳失敗");
                return response.json();
            })
            .then(result => {
                console.log("✅ 上傳完成", result);
                alert(`✅ 上傳成功，${result.msg}`);
                this.fetchData();
            })
            .catch(error => {
                console.error("❌ 上傳失敗", error);
                alert("❌ 上傳失敗");
            });
        },

        async fetchAdmins() {
            try {
                const res = await fetch('http://127.0.0.1:5000/api/admins');
                this.admins = await res.json();
                console.log("有權限者工號", this.admins)
            } catch (e) {
                console.error("取得需求者清單失敗", e);
            }
        },

        goDashboard(){
            localStorage.setItem('username', this.username);
            window.location.href = 'Procurement_Dynamic_360_Dashboard.html'; 
        },
        goMaterialReceivingNoteUpload(){
            if(!this.admins.includes(this.username)){
                alert("你沒有權限進入！");
                return
            }
            localStorage.setItem('username', this.username);
            window.location.href = 'MaterialReceivingNoteUpload.html'; 
        },
        
        async goEHubpageInfo(){
            if(!this.admins.includes(this.username)){
                alert("你沒有權限進入！");
                return
            }
            localStorage.setItem('username', this.username);
            window.location.href = 'eHubUploadFile.html';
        },
    },

    async mounted(){
        const username = localStorage.getItem('username');
        this.username = username
        console.log("👤 使用者名稱：", this.username);
        await this.fetchAdmins();
        await this.fetchData();
        
        // 新增：載入會計相關資料
        await this.fetchAccountingSummary();
        await this.fetchMonthlyActualAccounting();
        await this.fetchBudgetMonths(); // 新增：載入預算月份選項
        
        document.addEventListener('click', this.handleClickOutside);
    },

    // 修改 watch 監聽器：
    watch: {
        selectedUnInvoicedMonth(newMonth) {
            this.currentUnInvoicedAmount = this.getUnInvoicedAmount(newMonth);
        },
        
        selectedInvoiceMonth(newMonth) {
            this.selectedMonthlyInvoiceAmount = this.getActualInvoiceAmount(newMonth);
        },
        
        selectedCurrentUnInvoicedMonth(newMonth) {
            this.currentMonthUnInvoicedAmount = this.getUnInvoicedAmount(newMonth);
        },
        
        selectedCurrentMonth(newMonth) {
            console.log('🔄 selectedCurrentMonth 變更:', newMonth);
            this.selectedCurrentMonthInvoiceAmount = this.getActualInvoiceAmount(newMonth);
            console.log('📈 更新後的實際入帳金額:', this.selectedCurrentMonthInvoiceAmount);
        },

        // 新增：監聽預算月份變更
        selectedBudgetMonth(newMonth) {
            console.log('🔄 selectedBudgetMonth 變更:', newMonth);
            this.updateBudgetLimit();
        },
    },

})
app.mount('#app');