  const app = Vue.createApp({
    data() {
        return {
            headers: [
                "PO NO<br>採購單號碼",
                "PO Item<br>採購單項次",
                "PN.<br>料號",
                "Description<br>品名",
                "Vendor Code<br>供應商代碼",
                "Vendor Name<br>供應商",
                "SOD Qty<br>廠商承諾數量",
                "Unit<br>單位",
                "Request Date<br>需求日期",
                "Delivery Date<br>廠商承諾交期",
                "Buyer<br>採購姓名/分機",
                "Badge No<br>請購者工號",
                "Initiator<br>請購者姓名/分機"
            ],
            ignoreHeaderWords: [
                "PO NO","PO Item","PN.","Description","Vendor Code","Vendor Name",
                "SOD Qty","Unit","Request Date","Delivery Date","Buyer","Badge No","Initiator",
                "採購單號碼","採購單項次","料號","品名","供應商代碼","供應商",
                "廠商承諾數量","單位","需求日期","Delievery Date","廠商承諾交期","採購姓名/分機",
                "請購者工號","請購者姓名/分機"
            ],
            tableData: [],
            currentEditing: null,
            matched: [],
            conflict: [],
            allGroups: [],  // ✅ 這個是合併後的資料
            groupedRows: {},    // ⬅ 依照 PO No 分組後的結果
            showUploadButton: true,
            // 追蹤覆蓋進度（已存在）
            totalPoGroups: 0,           // 總共需要覆蓋的 PO 組數
            overriddenPoGroups: 0,      // 已經覆蓋的 PO 組數
            overriddenPoSet: new Set(), // 已覆蓋的 PO 編號集合
            // 新增：一鍵覆蓋控制
            isOverridingAll: false,  // 是否正在執行一鍵覆蓋
        }
    },
    computed: {
      // 計算覆蓋進度百分比
      overrideProgress() {
          if (this.totalPoGroups === 0) return 0;
          return Math.round((this.overriddenPoGroups / this.totalPoGroups) * 100);
      },
      
      // 檢查是否所有 PO 都已覆蓋
      allPoGroupsOverridden() {
          return this.totalPoGroups > 0 && this.overriddenPoGroups >= this.totalPoGroups;
      },
      
      // 控制上傳按鈕顯示（修改現有的 showUploadButton）
      showUploadButtonComputed() {
          // 沒有待覆蓋的資料，或所有資料都已覆蓋完成
          return this.totalPoGroups === 0 || this.allPoGroupsOverridden;
      }
  },
    methods: {
        saveCellContent(rowIndex, colIndex) {
            const refName = `cell-${rowIndex}-${colIndex}`;
            const el = this.$refs[refName][0]; // 因為 v-for 同 key 會變陣列
            if (el) {
                this.tableData[rowIndex][colIndex] = el.innerText.trim();
            }
        },

        convertToTable() {
            const raw = this.rawPasteContent.trim();
            if (!raw) return;

            const rows = raw.split(/\r?\n/).filter(r => r.trim() !== '');

            const filtered = rows.filter(line => {
                const parts = line.split(/\t|\s{2,}/).map(p => p.trim());
                // 如果每個欄位都在 ignoreHeaderWords 裡，就視為表頭 -> 忽略
                const allHeader = parts.every(p => this.ignoreHeaderWords.includes(p));
                return !allHeader;
            });

            const parsedData = filtered.map(row => {
            let cols = row.split(/\t|\s{2,}/).map(c => c.trim());
            while (cols.length < this.headers.length) {
                    cols.push('');
                }
                return cols;
            });

            this.tableData = parsedData;
        },

        submitData() {
          console.log("✅ 資料 JSON：", JSON.stringify(this.tableData));

          const headerRow = this.headers.map(h => h.replace(/<br>/g, " "));
          const csvRows = [headerRow.join(",")];

          this.tableData.forEach(row => {
            csvRows.push(
              row.map(v => {
                const val = String(v ?? '').trim();
                if (val === '') return '';
                if (val.includes(',') || val.includes('"') || val.includes('\n')) {
                  return `"${val.replace(/"/g, '""')}"`;
                }
                return val;
              }).join(",")
            );
          });

          const csvContent = csvRows.join("\n");

          fetch("http://127.0.0.1:5000/api/save_csv", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              filename: `upload_${Date.now()}.csv`,
              content: csvContent
            })
          })
          .then(res => res.json())
          .then(data => {
            console.log("後端回傳:", data);
            this.showUploadButton = false; // ⬅️ 加這行
            // // ✅ 合併 matched + conflict
            // const mergedRows = [...(data.matched || []), ...(data.conflict || [])];

            // // ✅ 依照 po_no 分組
            // this.groupedRows = mergedRows.reduce((acc, row) => {
            //   const key = row.po_no || "未指定 PO";
            //   if (!acc[key]) acc[key] = [];
            //   acc[key].push(row);
            //   return acc;
            // }, {});

            // console.log("📦 分組結果：", this.groupedRows);
            if (data.status === "ok" && Array.isArray(data.groups)) {
              // ✅ 把 matched + conflict 合併成同一組
              this.allGroups = data.groups.map(g => {
                return {
                  po_no: g.po_no,
                  rows: [...(g.matched || []), ...(g.conflict || [])]
                }
              });
              // 這段程式碼會執行到
              this.totalPoGroups = this.allGroups.length;
              this.overriddenPoGroups = 0;
              this.overriddenPoSet.clear();
              
              console.log(`📊 需要覆蓋 ${this.totalPoGroups} 組 PO`);
            } else {
              alert("⚠️ 後端沒有返回正確的分組資料");
            }

          })
          .catch(err => {
            console.error("❌ 上傳失敗", err);
            alert("❌ 上傳失敗，請查看 console");
          });
         
        },
        fetchConflict(poNo) {
            fetch("http://127.0.0.1:5000/api/save_csv", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ filename: "xxx.csv", content: "..." })
            })
            .then(res => res.json())
            .then(data => {
            this.poNo = data.po_no;
            this.conflictCards = data.buyer_related;  // 顯示卡片
            })
            .catch(err => console.error("❌ 錯誤", err));
        },

        // ✅ 保留目前的 PO No（只保留 6100793865）
        keepCurrentPo(card) {
            let cleaned = card["PO No."].split("<br />").map(v => v.trim());
            card["PO No."] = this.poNo;  // 只保留當前 poNo
            alert(`✅ 已保留 ${this.poNo}`);
        },

        // ❌ 刪除這筆紀錄（如果真的多餘）
        removeExtraPo(card) {
            this.conflictCards = this.conflictCards.filter(c => c.Id !== card.Id);
            alert(`已刪除多餘紀錄 ID=${card.Id}`);
        },
        clearAll() {
            this.rawPasteContent = '';
            this.tableData = [];
        },
        async handleFileUpload(event) {
            const file = event.target.files[0];
            if (!file) return;

            const filename = file.name;
            // ✅ 使用正規表達式驗證檔名格式
            const pattern = /^sendMailforBadgeMailNoticeApproveESD_\d{8}\d{6}_\(Security C\)\.xls$/;
            if (!pattern.test(filename)) {
              alert("❌ 檔名格式錯誤！\n正確格式為：sendMailforBadgeMailNoticeApproveESD_yyyymmdd_六碼_(Security C).xls");
              return;
            }


            const reader = new FileReader();
            reader.onload = (e) => {
                const data = new Uint8Array(e.target.result);
                const workbook = XLSX.read(data, { type: 'array' });

                // 讀取第一個工作表
                const sheetName = workbook.SheetNames[0];
                const sheet = workbook.Sheets[sheetName];

                let rows = XLSX.utils.sheet_to_json(sheet, { header: 1 });

                // 過濾空白行
                rows = rows.filter(r => Array.isArray(r) && r.some(cell => cell !== undefined && cell !== null && String(cell).trim() !== ""));

                // 固定刪掉前兩行
                if (rows.length > 2) {
                    rows = rows.slice(2);
                }

                console.log("刪掉前兩行後 rows:", rows);

                // 補滿欄位數
                const parsedData = rows.map(r => {
                    let cols = r.map(c => String(c ?? '').trim());
                    while (cols.length < this.headers.length) cols.push('');
                    return cols;
                });

                this.tableData = parsedData;
            };

            reader.readAsArrayBuffer(file);
        },
            // 檢查特定 PO 組是否已覆蓋
        isPoGroupOverridden(po_no) {
            return this.overriddenPoSet.has(po_no);
        },

        saveOverrideGroup(group) {
          // 單獨儲存該 PO No 的修改
          const payload = {
            po_no: group.po_no, // 只處理這個 PO No
            rows: group.rows    // 只送這一組資料
          };

          console.log("要覆蓋的資料:", payload);

          fetch("http://127.0.0.1:5000/api/save_override_all", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
          })
          .then(res => res.json())
          .then(data => {
            if(data.status === "ok"){
              // 檢查是否為新覆蓋的 PO
              if (!this.overriddenPoSet.has(group.po_no)) {
                  this.overriddenPoSet.add(group.po_no);
                  this.overriddenPoGroups++;
                  console.log(`✅ 已覆蓋 ${this.overriddenPoGroups}/${this.totalPoGroups} 組`);
              }

              // ✅ 覆蓋成功後，可以選擇把這組從畫面移除，避免重複送
              this.allGroups = this.allGroups.filter(g => g.po_no !== group.po_no);
                          // 如果全部覆蓋完成
              if (this.allPoGroupsOverridden) {
                  setTimeout(() => {
                      // 清空表格資料
                      this.tableData = [];
                      this.showUploadButton = true; // 重新顯示上傳按鈕
                      this.totalPoGroups = 0;
                      this.overriddenPoGroups = 0;
                      this.overriddenPoSet.clear();
                      alert("🎉 所有 PO 已覆蓋完成！現在可以上傳新檔案。");
                  }, 1000);
              }
              alert(data.msg);
            }else{
              alert(data.msg || "❌ 發生錯誤");
            }

          })
          .catch(err => {
            console.error("❌ 覆蓋失敗", err);
            alert("❌ 覆蓋失敗，請查看 console");
          });
        },
            // 一鍵覆蓋全部
    async overrideAllGroups() {
        if (!confirm(`確定要覆蓋全部 ${this.totalPoGroups - this.overriddenPoGroups} 組 PO 嗎？`)) {
            return;
        }

        this.isOverridingAll = true;
        
        // 過濾出尚未覆蓋的 PO 組
        const groupsToOverride = this.allGroups.filter(
            group => !this.overriddenPoSet.has(group.po_no)
        );
        
        console.log(`🚀 開始一鍵覆蓋 ${groupsToOverride.length} 組 PO`);
        
        // 依序處理每個 PO 組
        for (let i = 0; i < groupsToOverride.length; i++) {
            const group = groupsToOverride[i];
            console.log(`正在處理第 ${i + 1}/${groupsToOverride.length} 組: ${group.po_no}`);
            
            try {
                // 呼叫覆蓋 API
                const response = await fetch("http://127.0.0.1:5000/api/save_override_all", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        po_no: group.po_no,
                        rows: group.rows
                    })
                });
                
                const data = await response.json();
                
                if (data.status === "ok") {
                    // 標記為已覆蓋
                    if (!this.overriddenPoSet.has(group.po_no)) {
                        this.overriddenPoSet.add(group.po_no);
                        this.overriddenPoGroups++;
                        console.log(`✅ 成功覆蓋 ${group.po_no} (${this.overriddenPoGroups}/${this.totalPoGroups})`);
                    }
                    
                    // 從列表中移除
                    this.allGroups = this.allGroups.filter(g => g.po_no !== group.po_no);
                } else {
                    console.error(`❌ 覆蓋 ${group.po_no} 失敗:`, data.msg);
                    // 發生錯誤時詢問是否繼續
                    if (!confirm(`覆蓋 ${group.po_no} 失敗：${data.msg}\n\n是否繼續覆蓋其他 PO？`)) {
                        break;
                    }
                }
                
                // 加入短暫延遲，避免請求過快
                await new Promise(resolve => setTimeout(resolve, 500));
                
            } catch (error) {
                console.error(`❌ 覆蓋 ${group.po_no} 發生錯誤:`, error);
                if (!confirm(`覆蓋 ${group.po_no} 發生錯誤：${error}\n\n是否繼續覆蓋其他 PO？`)) {
                    break;
                }
            }
        }
        
        this.isOverridingAll = false;
        
        // 檢查是否全部完成
        if (this.overriddenPoGroups >= this.totalPoGroups && this.totalPoGroups > 0) {
            // 清空表格資料
            this.tableData = [];
            
            // 重置所有狀態
            this.showUploadButton = true;
            this.totalPoGroups = 0;
            this.overriddenPoGroups = 0;
            this.overriddenPoSet.clear();
            
            setTimeout(() => {
                alert("🎉 所有 PO 已覆蓋完成！現在可以上傳新檔案。");
            }, 500);
        } else {
            alert(`覆蓋完成！成功 ${this.overriddenPoGroups} 組，剩餘 ${this.totalPoGroups - this.overriddenPoGroups} 組。`);
        }
    },
        back_Dashboard(){
          localStorage.setItem('username', this.username);
          window.location.href = 'eRT_page.html';
        },
    },
    async mounted(){
        const username = localStorage.getItem('username');
        this.username = username
        console.log("👤 使用者名稱：", this.username);
        document.addEventListener('click', this.handleClickOutside);
    },
})
app.mount("#app");