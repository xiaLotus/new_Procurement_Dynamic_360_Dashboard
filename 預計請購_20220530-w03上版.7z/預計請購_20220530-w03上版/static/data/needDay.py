import pandas as pd
import numpy as np

def update_buyer_demand_date():
    """
    將 Planned_Purchase_Request_List.csv 的需求日資料
    根據 ID 對應更新到 Buyer_detail.csv
    """
    
    print("="*60)
    print("開始更新 Buyer_detail.csv 的需求日資料")
    print("="*60)
    
    # 1. 讀取兩個 CSV 檔案
    print("\n1. 讀取資料檔案...")
    
    # 讀取 Buyer_detail.csv
    buyer_df = pd.read_csv('Buyer_detail.csv', encoding='utf-8-sig', dtype='str')
    print(f"   Buyer_detail.csv 讀取完成: {len(buyer_df)} 筆資料")
    
    # 讀取 Planned_Purchase_Request_List.csv
    planned_df = pd.read_csv('Planned_Purchase_Request_List.csv', encoding='utf-8-sig', dtype='str')
    print(f"   Planned_Purchase_Request_List.csv 讀取完成: {len(planned_df)} 筆資料")
    
    # 2. 檢查原始資料狀況
    print("\n2. 檢查原始資料狀況...")
    
    # 檢查 Buyer_detail 的需求日欄位
    buyer_demand_not_null = buyer_df['需求日'].notna() & (buyer_df['需求日'] != '')
    print(f"   Buyer_detail 原始需求日有值: {buyer_demand_not_null.sum()} 筆")
    
    # 檢查 Planned 的需求日欄位
    planned_demand_not_null = planned_df['需求日'].notna() & (planned_df['需求日'] != '')
    print(f"   Planned_Purchase_Request_List 需求日有值: {planned_demand_not_null.sum()} 筆")
    
    # 3. 建立 ID 對應的需求日字典
    print("\n3. 建立 ID 與需求日的對應關係...")
    
    # 從 Planned 建立 ID -> 需求日 的對應字典
    id_to_demand_date = {}
    duplicate_ids = []
    
    for idx, row in planned_df.iterrows():
        plan_id = row['Id']
        demand_date = row['需求日']
        
        # 只處理有需求日的資料
        if pd.notna(demand_date) and str(demand_date) != '' and pd.notna(plan_id):
            if plan_id in id_to_demand_date:
                # 如果 ID 重複，記錄下來
                duplicate_ids.append(plan_id)
            id_to_demand_date[plan_id] = demand_date
    
    print(f"   建立了 {len(id_to_demand_date)} 筆 ID 對應關係")
    if duplicate_ids:
        print(f"   警告: 發現 {len(set(duplicate_ids))} 個重複的 ID")
    
    # 4. 更新 Buyer_detail 的需求日
    print("\n4. 更新 Buyer_detail 的需求日...")
    
    updated_count = 0
    already_has_value = 0
    no_match = 0
    
    # 備份原始需求日
    buyer_df['需求日_原始'] = buyer_df['需求日'].copy()
    
    for idx, row in buyer_df.iterrows():
        buyer_id = row['Id']
        
        if buyer_id in id_to_demand_date:
            new_demand_date = id_to_demand_date[buyer_id]
            old_demand_date = row['需求日']
            
            # 檢查原本是否有值
            if pd.notna(old_demand_date) and str(old_demand_date) != '':
                already_has_value += 1
                print(f"   警告: ID {buyer_id} 原本已有需求日 {old_demand_date}，將更新為 {new_demand_date}")
            
            # 更新需求日
            buyer_df.at[idx, '需求日'] = new_demand_date
            updated_count += 1
        else:
            if pd.isna(row['需求日']) or str(row['需求日']) == '':
                no_match += 1
    
    print(f"   成功更新: {updated_count} 筆")
    print(f"   原本已有值被覆蓋: {already_has_value} 筆")
    print(f"   找不到對應 ID: {no_match} 筆")
    
    # 5. 儲存更新後的檔案
    print("\n5. 儲存更新後的檔案...")
    
    # 儲存更新後的 Buyer_detail.csv（保留原始備份）
    buyer_df_output = buyer_df.drop(columns=['需求日_原始'])
    buyer_df_output.to_csv('Buyer_detail_updated.csv', index=False, encoding='utf-8-sig')
    print(f"   已儲存至: Buyer_detail_updated.csv")
    
    # 儲存含原始值的完整版本（供比對用）
    buyer_df.to_csv('Buyer_detail_with_original.csv', index=False, encoding='utf-8-sig')
    print(f"   含原始值版本儲存至: Buyer_detail_with_original.csv")
    
    # 6. 驗證更新結果
    print("\n6. 驗證更新結果...")
    
    # 重新檢查更新後的需求日狀況
    updated_demand_not_null = buyer_df['需求日'].notna() & (buyer_df['需求日'] != '')
    print(f"   更新後需求日有值: {updated_demand_not_null.sum()} 筆")
    print(f"   新增的需求日資料: {updated_demand_not_null.sum() - buyer_demand_not_null.sum()} 筆")
    
    # 7. 產生更新報告
    print("\n7. 產生更新報告...")
    
    report_filename = "demand_date_update_report.txt"
    with open(report_filename, 'w', encoding='utf-8') as f:
        f.write("需求日更新報告\n")
        f.write("="*60 + "\n\n")
        
        f.write("一、資料統計\n")
        f.write(f"Buyer_detail.csv 總筆數: {len(buyer_df)}\n")
        f.write(f"Planned_Purchase_Request_List.csv 總筆數: {len(planned_df)}\n")
        f.write(f"建立的 ID 對應關係: {len(id_to_demand_date)} 筆\n\n")
        
        f.write("二、更新統計\n")
        f.write(f"成功更新: {updated_count} 筆\n")
        f.write(f"原本已有值被覆蓋: {already_has_value} 筆\n")
        f.write(f"找不到對應 ID: {no_match} 筆\n\n")
        
        f.write("三、更新前後比較\n")
        f.write(f"更新前需求日有值: {buyer_demand_not_null.sum()} 筆\n")
        f.write(f"更新後需求日有值: {updated_demand_not_null.sum()} 筆\n")
        f.write(f"新增需求日資料: {updated_demand_not_null.sum() - buyer_demand_not_null.sum()} 筆\n\n")
        
        # 列出被更新的 ID 清單（前20筆）
        f.write("四、被更新的資料範例（前20筆）\n")
        f.write("-"*40 + "\n")
        
        updated_rows = buyer_df[buyer_df['Id'].isin(id_to_demand_date.keys())].head(20)
        for idx, row in updated_rows.iterrows():
            f.write(f"ID: {row['Id']}\n")
            f.write(f"  ePR No.: {row['ePR No.']}\n")
            f.write(f"  品項: {row['品項']}\n")
            f.write(f"  原始需求日: {row['需求日_原始']}\n")
            f.write(f"  新需求日: {row['需求日']}\n")
            f.write("-"*20 + "\n")
    
    print(f"   報告已儲存至: {report_filename}")
    
    # 8. 顯示部分更新結果
    print("\n8. 更新結果範例（前5筆）:")
    print("-"*60)
    
    sample_updated = buyer_df[buyer_df['Id'].isin(id_to_demand_date.keys())].head(5)
    for idx, row in sample_updated.iterrows():
        print(f"ID: {row['Id']}")
        print(f"  品項: {row['品項']}")
        print(f"  新需求日: {row['需求日']}")
        print(f"  原需求日: {row['需求日_原始']}")
        print("-"*30)
    
    print("\n" + "="*60)
    print("更新完成！")
    print("="*60)
    
    return buyer_df

# 執行主程式
if __name__ == "__main__":
    try:
        updated_df = update_buyer_demand_date()
        
        # 可選：顯示更新後可以重新執行 1_3.py 的提示
        print("\n提示：")
        print("1. 更新後的檔案已儲存為 'Buyer_detail_updated.csv'")
        print("2. 您可以將此檔案重新命名為 'Buyer_detail.csv' 來取代原檔案")
        print("3. 然後重新執行 1_3.py 來計算更新後的未入帳金額")
        
    except FileNotFoundError as e:
        print(f"\n錯誤: 找不到檔案 - {e}")
        print("請確認以下檔案都在同一目錄下：")
        print("  - Buyer_detail.csv")
        print("  - Planned_Purchase_Request_List.csv")
    except Exception as e:
        print(f"\n發生錯誤: {e}")
        import traceback
        traceback.print_exc()