# app.py - Flask 後端主程式
from flask import Flask, request, jsonify
from flask_cors import CORS
from werkzeug.utils import secure_filename
import os
import re
import base64
import quopri
from datetime import datetime
import hashlib
from bs4 import BeautifulSoup
import email
from email import policy
from email.parser import BytesParser
import json
import traceback
import logging
import pandas as pd

app = Flask(__name__)
CORS(app)

# 設定日誌
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Buyer CSV 路徑設定（與 app.py 同層級）
BUYER_CSV_PATH = 'Buyer_detail.csv'

# 設定
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB 檔案大小限制
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['PROCESSED_FOLDER'] = 'processed'
app.config['ALLOWED_EXTENSIONS'] = {'mhtml', 'mht', 'csv'}  # 新增 CSV 支援

# 確保資料夾存在
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['PROCESSED_FOLDER'], exist_ok=True)

def allowed_file(filename):
    """檢查檔案是否為允許的格式"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def generate_unique_filename(original_name, new_name):
    """生成唯一的檔名"""
    # 取得副檔名
    ext = original_name.rsplit('.', 1)[1].lower()
    
    # 如果新檔名沒有副檔名，加上原始副檔名
    if not new_name.endswith(f'.{ext}'):
        new_name = f"{new_name}.{ext}"
    
    # 生成唯一識別碼
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    unique_id = hashlib.md5(f"{new_name}{timestamp}".encode()).hexdigest()[:8]
    
    # 組合最終檔名
    name_without_ext = new_name.rsplit('.', 1)[0]
    final_name = f"{name_without_ext}_{unique_id}.{ext}"
    
    return secure_filename(final_name)

class MHTMLParser:
    """MHTML 檔案解析器"""
    
    def __init__(self, file_path):
        self.file_path = file_path
        self.boundary = None
        self.parts = []
        self.html_content = None
        self.metadata = {}
        self.gridview_data = None
        
    def parse(self):
        """解析 MHTML 檔案"""
        try:
            with open(self.file_path, 'rb') as f:
                # 使用 email 模組解析 MHTML
                try:
                    msg = BytesParser(policy=policy.default).parse(f)
                except Exception as e:
                    logger.error(f"Email parser error: {str(e)}")
                    # 如果 email 解析失敗，嘗試直接讀取為 HTML
                    f.seek(0)
                    content = f.read()
                    self.html_content = content.decode('utf-8', errors='ignore')
                    
                    if self.html_content:
                        result = self._extract_html_info()
                        gridview_data = self._parse_gridview()
                        if gridview_data:
                            result['gridview_data'] = gridview_data
                        return result
                    return {'error': f'無法解析檔案: {str(e)}'}
                
                # 提取基本資訊
                self.metadata['subject'] = msg.get('Subject', '')
                self.metadata['date'] = msg.get('Date', '')
                self.metadata['from'] = msg.get('From', '')
                self.metadata['content_type'] = msg.get_content_type()
                
                # 處理多部分內容
                if msg.is_multipart():
                    self._parse_multipart(msg)
                else:
                    # 單一部分 MHTML
                    content = msg.get_payload(decode=True)
                    if content:
                        self.html_content = content.decode('utf-8', errors='ignore')
                
                # 解析 HTML 內容
                if self.html_content:
                    result = self._extract_html_info()
                    
                    # 特別處理 GridView 表格
                    gridview_data = self._parse_gridview()
                    if gridview_data:
                        result['gridview_data'] = gridview_data
                    
                    return result
                    
            return self.metadata
            
        except Exception as e:
            logger.error(f"解析錯誤: {str(e)}")
            logger.error(traceback.format_exc())
            return {'error': str(e)}
    
    def _parse_multipart(self, msg):
        """解析多部分 MHTML"""
        for part in msg.walk():
            content_type = part.get_content_type()
            
            # 尋找 HTML 內容
            if content_type == 'text/html':
                content = part.get_payload(decode=True)
                if content:
                    self.html_content = content.decode('utf-8', errors='ignore')
                    
            # 收集其他資源
            elif not part.is_multipart():
                self.parts.append({
                    'content_type': content_type,
                    'content_location': part.get('Content-Location', ''),
                    'content_id': part.get('Content-ID', ''),
                    'size': len(part.get_payload())
                })
    
    def _extract_html_info(self):
        """從 HTML 內容提取資訊"""
        soup = BeautifulSoup(self.html_content, 'html.parser')
        
        # 提取標題
        title_tag = soup.find('title')
        self.metadata['title'] = title_tag.string if title_tag else ''
        
        # 提取 meta 標籤
        meta_tags = {}
        for meta in soup.find_all('meta'):
            name = meta.get('name') or meta.get('property')
            content = meta.get('content')
            if name and content:
                meta_tags[name] = content
            
            # 特別處理 charset
            if meta.get('charset'):
                self.metadata['encoding'] = meta.get('charset')
            elif meta.get('http-equiv', '').lower() == 'content-type':
                content = meta.get('content', '')
                if 'charset=' in content:
                    self.metadata['encoding'] = content.split('charset=')[-1].strip()
        
        self.metadata['meta_tags'] = meta_tags
        
        # 統計資訊
        self.metadata['statistics'] = {
            'total_parts': len(self.parts),
            'html_size': len(self.html_content) if self.html_content else 0
        }
        
        # 提取文字內容摘要（前500字）
        text_content = soup.get_text(strip=True)
        self.metadata['content_preview'] = text_content[:500] if text_content else ''
        
        return self.metadata
    
    def _parse_gridview(self):
        """解析 GridView 表格資料"""
        if not self.html_content:
            return None
        
        try:
            soup = BeautifulSoup(self.html_content, 'html.parser')
            
            # 尋找 GridView Wrapper
            wrapper = soup.find('div', {'id': 'ContentPlaceHolder1_GridView2Wrapper'})
            if not wrapper:
                logger.debug("No GridView wrapper found")
                return None
            
            gridview_data = {
                'headers': [],
                'rows': [],
                'statistics': {}
            }
            
            # 解析表頭
            header_table = wrapper.find('table', {'id': 'ContentPlaceHolder1_GridView2Copy'})
            if header_table:
                header_row = header_table.find('tr', {'id': lambda x: x and 'HeaderCopy' in x})
                if header_row:
                    for th in header_row.find_all('th'):
                        # 清理表頭文字
                        header_text = th.get_text(strip=True)
                        header_text = header_text.replace('\n', ' ').replace('\r', '')
                        # 分離中英文
                        if 'br' in str(th):
                            parts = [t.strip() for t in th.strings]
                            header_dict = {
                                'zh': parts[0] if len(parts) > 0 else '',
                                'en': parts[1] if len(parts) > 1 else '',
                                'full': header_text
                            }
                        else:
                            header_dict = {
                                'zh': header_text,
                                'en': '',
                                'full': header_text
                            }
                        gridview_data['headers'].append(header_dict)
            
            # 解析資料行
            data_table = wrapper.find('table', {'id': 'ContentPlaceHolder1_GridView2'})
            if data_table:
                # 找所有的 tr，排除表頭
                all_rows = data_table.find_all('tr')
                data_rows = []
                
                for row in all_rows:
                    # 跳過表頭行（通常有特定的 style 或 id）
                    if row.get('id') and 'Header' in row.get('id', ''):
                        continue
                    if row.get('style') and 'display: none' in row.get('style', ''):
                        continue
                    # 確保有 td 元素
                    if row.find_all('td'):
                        data_rows.append(row)
                
                for row in data_rows:
                    row_data = []
                    cells = row.find_all('td')
                    
                    for idx, td in enumerate(cells):
                        cell_data = {
                            'value': '',
                            'inputs': [],
                            'spans': []
                        }
                        
                        # 提取 input 元素
                        inputs = td.find_all('input')
                        for inp in inputs:
                            input_data = {
                                'type': inp.get('type', ''),
                                'name': inp.get('name', ''),
                                'id': inp.get('id', ''),
                                'title': inp.get('title', ''),
                                'src': inp.get('src', '')
                            }
                            # 標記按鈕類型，不依賴外部圖片
                            if input_data['src']:
                                if 'edit' in input_data['src'].lower() or '編輯' in input_data.get('title', ''):
                                    input_data['button_type'] = 'edit'
                                elif 'delete' in input_data['src'].lower() or '刪除' in input_data.get('title', ''):
                                    input_data['button_type'] = 'delete'
                                else:
                                    input_data['button_type'] = 'unknown'
                            
                            cell_data['inputs'].append(input_data)
                        
                        # 提取 span 元素
                        spans = td.find_all('span')
                        for span in spans:
                            span_text = span.get_text(strip=True)
                            cell_data['spans'].append({
                                'id': span.get('id', ''),
                                'class': span.get('class', []),
                                'text': span_text
                            })
                            if not cell_data['value']:  # 使用第一個 span 的文字作為值
                                cell_data['value'] = span_text
                        
                        # 如果沒有 span，取整個 td 的文字
                        if not cell_data['value']:
                            cell_data['value'] = td.get_text(strip=True)
                        
                        row_data.append(cell_data)
                    
                    # 將資料行加入結果
                    if row_data:
                        # 建立結構化的資料物件
                        structured_row = {}
                        for i, header in enumerate(gridview_data['headers']):
                            if i < len(row_data):
                                # 建立更安全的欄位名稱
                                if header.get('en'):
                                    field_name = re.sub(r'[^a-zA-Z0-9_]', '_', header['en'].lower())
                                else:
                                    field_name = f'field_{i}'
                                structured_row[field_name] = row_data[i]['value']
                        
                        # 加入原始資料和結構化資料
                        gridview_data['rows'].append({
                            'raw_data': row_data,
                            'structured_data': structured_row
                        })
            
            # 統計資訊
            gridview_data['statistics'] = {
                'total_columns': len(gridview_data['headers']),
                'total_rows': len(gridview_data['rows']),
                'has_data': len(gridview_data['rows']) > 0
            }
            
            return gridview_data
            
        except Exception as e:
            logger.error(f"GridView parsing error: {str(e)}")
            logger.error(traceback.format_exc())
            return None

@app.route('/api/upload-mhtml', methods=['POST'])
def upload_mhtml():
    """處理 MHTML 檔案上傳並自動與 Buyer CSV 比對"""
    try:
        # 檢查是否有檔案
        if 'file' not in request.files:
            logger.error("No file in request")
            return jsonify({'success': False, 'error': '沒有檔案被上傳'}), 400
        
        file = request.files['file']
        new_name = request.form.get('newName', '')
        
        # 檢查檔案是否為空
        if file.filename == '':
            logger.error("Empty filename")
            return jsonify({'success': False, 'error': '沒有選擇檔案'}), 400
        
        # 檢查檔案格式
        if not allowed_file(file.filename):
            logger.error(f"Invalid file type: {file.filename}")
            return jsonify({'success': False, 'error': '不支援的檔案格式'}), 400
        
        # 生成新的唯一檔名
        if new_name:
            filename = generate_unique_filename(file.filename, new_name)
        else:
            filename = generate_unique_filename(file.filename, file.filename)
        
        logger.info(f"Processing file: {filename}")
        
        # 儲存檔案到上傳資料夾
        upload_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(upload_path)
        
        # 移動並重新命名檔案到處理資料夾
        processed_path = os.path.join(app.config['PROCESSED_FOLDER'], filename)
        
        # 如果目標檔案已存在，先刪除
        if os.path.exists(processed_path):
            os.remove(processed_path)
        
        os.rename(upload_path, processed_path)
        
        # 解析 MHTML 檔案
        parser = MHTMLParser(processed_path)
        extracted_info = parser.parse()
        
        # 檢查是否有解析錯誤
        if 'error' in extracted_info:
            logger.error(f"Parser error: {extracted_info['error']}")
            # 即使有錯誤，還是返回部分資訊
        
        # 加入檔案資訊
        file_stats = os.stat(processed_path)
        extracted_info.update({
            'original_filename': file.filename,
            'saved_filename': filename,
            'file_size': file_stats.st_size,
            'upload_time': datetime.now().isoformat(),
            'file_path': processed_path
        })
        
        # 格式化檔案大小
        size = file_stats.st_size
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024.0:
                extracted_info['file_size_formatted'] = f"{size:.2f} {unit}"
                break
            size /= 1024.0
        
        # 如果有 GridView 資料，另外儲存為 JSON
        if 'gridview_data' in extracted_info and extracted_info['gridview_data']:
            json_filename = filename.rsplit('.', 1)[0] + '_gridview.json'
            json_path = os.path.join(app.config['PROCESSED_FOLDER'], json_filename)
            
            try:
                with open(json_path, 'w', encoding='utf-8') as f:
                    json.dump(extracted_info['gridview_data'], f, ensure_ascii=False, indent=2)
                
                extracted_info['gridview_json_file'] = json_filename
                logger.info(f"GridView data saved to: {json_filename}")
                
                # 自動與 Buyer_detail.csv 比對
                if os.path.exists(BUYER_CSV_PATH):
                    logger.info("開始與 Buyer_detail.csv 比對...")
                    comparison_result = compare_with_buyer_csv(extracted_info['gridview_data'])
                    extracted_info['comparison_result'] = comparison_result
                else:
                    logger.warning(f"找不到 {BUYER_CSV_PATH}")
                    extracted_info['comparison_result'] = {
                        'error': f'找不到 {BUYER_CSV_PATH} 檔案',
                        'needs_buyer_csv': True
                    }
                    
            except Exception as e:
                logger.error(f"Failed to save GridView JSON or compare: {str(e)}")
        
        return jsonify({
            'success': True,
            'message': '檔案上傳並解析成功',
            'data': extracted_info
        })
        
    except Exception as e:
        logger.error(f"上傳錯誤: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': f'處理檔案時發生錯誤: {str(e)}'
        }), 500

def compare_with_buyer_csv(gridview_data):
    """與 Buyer CSV 比對 PO No. 和品名"""
    try:
        # 讀取 Buyer CSV
        try:
            buyer_df = pd.read_csv(BUYER_CSV_PATH, encoding='utf-8-sig')
        except:
            try:
                buyer_df = pd.read_csv(BUYER_CSV_PATH, encoding='utf-8')
            except:
                buyer_df = pd.read_csv(BUYER_CSV_PATH, encoding='big5')
        
        logger.info(f"Buyer CSV columns: {list(buyer_df.columns)}")
        logger.info(f"Buyer CSV shape: {buyer_df.shape}")
        
        # 解析 GridView 資料
        headers = gridview_data.get('headers', [])
        rows = gridview_data.get('rows', [])
        
        logger.info(f"GridView headers: {headers}")
        logger.info(f"GridView rows count: {len(rows)}")
        
        # 找出關鍵欄位的索引
        po_index = -1
        desc_index = -1
        qty_index = -1
        accept_qty_index = -1
        amount_index = -1
        
        for i, header in enumerate(headers):
            header_text = header.get('en', '').lower() or header.get('zh', '').lower() or header.get('full', '').lower()
            # PO No. 欄位（避免匹配到 Demo PO號）
            if ('po' in header_text and 'no' in header_text) or 'po號碼' in header_text:
                if 'demo' not in header_text.lower():  # 排除 Demo PO號
                    po_index = i
                    logger.info(f"Found PO index at {i}: {header}")
            elif 'description' in header_text or '品名' in header_text:
                desc_index = i
                logger.info(f"Found Description index at {i}: {header}")
            elif 'accept' in header_text and 'qty' in header_text or '驗收數量' in header_text:
                accept_qty_index = i
            elif 'qty' in header_text or '數量' in header_text or '收貨數量' in header_text:
                if accept_qty_index == -1:
                    qty_index = i
            elif 'amount' in header_text or '總金額' in header_text:
                amount_index = i
        
        # 先提取所有 PO 號碼，檢查是否有多個不同的 PO
        po_numbers = []
        for row_idx, row in enumerate(rows):
            raw_data = row.get('raw_data', [])
            
            if po_index >= 0 and po_index < len(raw_data):
                po_no = str(raw_data[po_index].get('value', '')).strip()
                logger.info(f"Row {row_idx} - Extracted PO: '{po_no}'")
                if po_no:  # 只記錄非空的 PO 號碼
                    po_numbers.append(po_no)
            else:
                logger.warning(f"Row {row_idx} - PO index {po_index} out of range")
        
        # 檢查 PO 號碼的唯一性
        unique_pos = list(set(po_numbers))
        logger.info(f"發現的唯一 PO 號碼: {unique_pos}")
        
        if len(unique_pos) > 1:
            # 有多個不同的 PO 號碼，計算每個 PO 的出現次數
            po_counts = {}
            for po in po_numbers:
                po_counts[po] = po_counts.get(po, 0) + 1
            
            # 按出現次數排序，找出最多的 PO
            sorted_pos = sorted(po_counts.items(), key=lambda x: x[1], reverse=True)
            most_common_po = sorted_pos[0][0]
            most_common_count = sorted_pos[0][1]
            
            logger.warning(f"發現多個不同的 PO 號碼: {po_counts}")
            logger.warning(f"最常出現的 PO: {most_common_po} (出現 {most_common_count} 次)")
            
            # 判斷是否應該報錯 - 如果沒有明顯的多數，就報錯
            total_count = len(po_numbers)
            majority_threshold = total_count / 2
            
            if most_common_count <= majority_threshold:
                # 沒有明顯多數，報錯
                error_msg = f"發現多個不同的 PO 號碼，無法確定正確的 PO: {dict(po_counts)}"
                logger.error(error_msg)
                return {
                    'error': error_msg,
                    'error_type': 'multiple_po_no_majority',
                    'po_counts': po_counts,
                    'items': [],
                    'summary': {}
                }
            else:
                # 有明顯多數，發出警告但繼續處理
                logger.warning(f"使用多數決 PO 號碼: {most_common_po}")
        
        # 如果只有一個 PO 或有明顯多數，繼續原來的比對邏輯
        # 讀取 Buyer CSV
        try:
            buyer_df = pd.read_csv(BUYER_CSV_PATH, encoding='utf-8-sig')
        except:
            try:
                buyer_df = pd.read_csv(BUYER_CSV_PATH, encoding='utf-8')
            except:
                buyer_df = pd.read_csv(BUYER_CSV_PATH, encoding='big5')
        
        logger.info(f"Buyer CSV columns: {list(buyer_df.columns)}")
        logger.info(f"Buyer CSV shape: {buyer_df.shape}")
        
        # 建立比對結果
        comparison_items = []
        total_amount = 0
        
        # 列出第一筆資料的原始內容以除錯
        if len(rows) > 0:
            first_row = rows[0].get('raw_data', [])
            logger.info(f"First row raw data length: {len(first_row)}")
            for i, cell in enumerate(first_row[:10]):  # 只列前10個欄位
                logger.info(f"Cell {i}: {cell.get('value', 'NO VALUE')}")
        
        for row_idx, row in enumerate(rows):
            item = {}
            raw_data = row.get('raw_data', [])
            
            # 提取資料
            if po_index >= 0 and po_index < len(raw_data):
                item['po_no'] = str(raw_data[po_index].get('value', '')).strip()
                logger.info(f"Row {row_idx} - Extracted PO from index {po_index}: '{item['po_no']}'")
            else:
                logger.warning(f"Row {row_idx} - PO index {po_index} out of range (row has {len(raw_data)} cells)")
                
            if desc_index >= 0 and desc_index < len(raw_data):
                item['description'] = str(raw_data[desc_index].get('value', '')).strip()
                logger.info(f"Row {row_idx} - Extracted Description from index {desc_index}: '{item['description']}'")
                
            if qty_index >= 0 and qty_index < len(raw_data):
                item['qty'] = raw_data[qty_index].get('value', '')
                
            if accept_qty_index >= 0 and accept_qty_index < len(raw_data):
                item['accept_qty'] = raw_data[accept_qty_index].get('value', '')
            elif qty_index >= 0:
                item['accept_qty'] = item.get('qty', '0')
                
            if amount_index >= 0 and amount_index < len(raw_data):
                item['amount'] = raw_data[amount_index].get('value', '')
            
            # 計算 RT 金額和 RT 總金額
            try:
                amount_str = str(item.get('amount', '0'))
                amount_str = amount_str.replace(',', '').replace('$', '').replace('TWD', '').strip()
                amount_value = float(amount_str) if amount_str and amount_str != '-' else 0
                
                accept_qty_str = str(item.get('accept_qty', '0'))
                accept_qty_str = accept_qty_str.replace(',', '').strip()
                accept_qty_value = float(accept_qty_str) if accept_qty_str and accept_qty_str != '0' and accept_qty_str != '-' else 1
                
                item['rt_amount'] = amount_value / accept_qty_value if accept_qty_value > 0 else 0
                item['rt_total_amount'] = amount_value
                
                total_amount += amount_value
            except Exception as e:
                logger.error(f"計算 RT 金額錯誤: {str(e)}")
                item['rt_amount'] = 0
                item['rt_total_amount'] = 0
            
            # 在 Buyer CSV 中尋找匹配
            matched_in_buyer = False
            buyer_row_index = -1
            
            if item.get('po_no'):
                # 在 Buyer CSV 的 PO No. 欄位中尋找
                for idx, buyer_row in buyer_df.iterrows():
                    buyer_po = str(buyer_row.get('PO No.', '')).strip()
                    
                    if buyer_po == item['po_no']:
                        matched_in_buyer = True
                        buyer_row_index = idx
                        logger.info(f"✓ Matched PO {item['po_no']} at Buyer CSV row {idx}")
                        logger.debug(f"所有欄位: {buyer_row.to_dict()}")
                        # 檢查品名是否也匹配
                        col_item = next((col for col in buyer_row.index if col.strip().replace(' ', '') in ['Item']), 'Item')
                        col_desc = next((col for col in buyer_row.index if col.strip().replace(' ', '') in ['品項', '品名']), '品項')

                        buyer_item = str(buyer_row.get(col_item, '')).strip()
                        buyer_desc = str(buyer_row.get(col_desc, '')).strip()
                        
                        if item.get('description'):
                            if buyer_item != item['description'] and buyer_desc != item['description']:
                                logger.warning(f"PO matched but description different: Buyer='{buyer_item}' or '{buyer_desc}', GridView='{item['description']}'")
                        break
                
                if not matched_in_buyer:
                    logger.warning(f"✗ PO {item['po_no']} not found in Buyer CSV")
            else:
                logger.warning(f"Row {row_idx} has no PO number")
            
            item['matched_in_buyer'] = matched_in_buyer
            item['buyer_row_index'] = buyer_row_index
            comparison_items.append(item)
        
        # 統計結果
        matched_count = sum(1 for item in comparison_items if item['matched_in_buyer'])
        unmatched_count = len(comparison_items) - matched_count
        
        logger.info(f"比對結果: 總項目={len(comparison_items)}, 匹配={matched_count}, 未匹配={unmatched_count}")
        
        return {
            'items': comparison_items,
            'summary': {
                'total_items': len(comparison_items),
                'matched_count': matched_count,
                'unmatched_count': unmatched_count,
                'total_amount': total_amount,
                'buyer_csv_rows': len(buyer_df),
                'buyer_csv_columns': list(buyer_df.columns)
            }
        }
        
    except Exception as e:
        logger.error(f"比對錯誤: {str(e)}")
        logger.error(traceback.format_exc())
        return {
            'error': str(e),
            'items': [],
            'summary': {}
        }
    

    
# 在 app.py 中新增以下路由和功能

import shutil

@app.route('/api/cleanup-processed', methods=['POST'])
def cleanup_processed():
    """清理 processed 資料夾中的所有文件"""
    try:
        processed_folder = app.config['PROCESSED_FOLDER']
        upload_folder = app.config['UPLOAD_FOLDER']
        
        total_files_removed = 0
        
        # 清理 processed 資料夾
        if os.path.exists(processed_folder):
            files_before = os.listdir(processed_folder)
            if files_before:
                for filename in files_before:
                    file_path = os.path.join(processed_folder, filename)
                    try:
                        if os.path.isfile(file_path) or os.path.islink(file_path):
                            os.unlink(file_path)
                            total_files_removed += 1
                            logger.info(f"已刪除 processed 文件: {filename}")
                        elif os.path.isdir(file_path):
                            shutil.rmtree(file_path)
                            total_files_removed += 1
                            logger.info(f"已刪除 processed 目錄: {filename}")
                    except Exception as e:
                        logger.error(f"無法刪除 processed 文件 {file_path}: {str(e)}")
        
        # 同時清理 upload 資料夾（預防措施）
        if os.path.exists(upload_folder):
            upload_files = os.listdir(upload_folder)
            if upload_files:
                for filename in upload_files:
                    file_path = os.path.join(upload_folder, filename)
                    try:
                        if os.path.isfile(file_path) or os.path.islink(file_path):
                            os.unlink(file_path)
                            total_files_removed += 1
                            logger.info(f"已刪除 upload 文件: {filename}")
                        elif os.path.isdir(file_path):
                            shutil.rmtree(file_path)
                            total_files_removed += 1
                            logger.info(f"已刪除 upload 目錄: {filename}")
                    except Exception as e:
                        logger.error(f"無法刪除 upload 文件 {file_path}: {str(e)}")
        
        # 驗證清理結果
        processed_files_after = os.listdir(processed_folder) if os.path.exists(processed_folder) else []
        upload_files_after = os.listdir(upload_folder) if os.path.exists(upload_folder) else []
        
        logger.info(f"清理完成: 刪除了 {total_files_removed} 個文件")
        
        return jsonify({
            'success': True,
            'message': f'成功清理 {total_files_removed} 個文件',
            'files_removed': total_files_removed,
            'remaining_processed_files': len(processed_files_after),
            'remaining_upload_files': len(upload_files_after)
        })
        
    except Exception as e:
        logger.error(f"清理資料夾錯誤: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': f'清理失敗: {str(e)}'
        }), 500

# 修改現有的 update_buyer_csv 函數，在成功更新後自動觸發清理
@app.route('/api/update-buyer-csv', methods=['POST'])
def update_buyer_csv():
    """更新 Buyer CSV 檔案中的 RT 金額"""
    try:
        data = request.json
        items_to_update = data.get('items', [])
        
        if not items_to_update:
            return jsonify({'success': False, 'error': '沒有要更新的項目'}), 400
        
        logger.info(f"準備更新 {len(items_to_update)} 筆資料")
        
        # 讀取 Buyer CSV
        try:
            buyer_df = pd.read_csv(BUYER_CSV_PATH, encoding='utf-8-sig', dtype=str)
        except:
            try:
                buyer_df = pd.read_csv(BUYER_CSV_PATH, encoding='utf-8', dtype=str)
            except:
                buyer_df = pd.read_csv(BUYER_CSV_PATH, encoding='big5', dtype=str)
        
        logger.info(f"Buyer CSV 原始欄位: {list(buyer_df.columns)}")
        
        # 確保有 RT 相關欄位
        if 'RT金額' not in buyer_df.columns:
            buyer_df['RT金額'] = ''
            logger.info("新增 RT金額 欄位")
        if 'RT總金額' not in buyer_df.columns:
            buyer_df['RT總金額'] = ''
            logger.info("新增 RT總金額 欄位")
        
        updated_count = 0
        
        # 更新每個項目
        for item in items_to_update:
            logger.info(items_to_update)
            po_no = str(item.get('po_no', '')).strip()
            description = str(item.get('description', '')).strip()
            
            # 將金額轉換為整數字串（移除小數點）
            rt_amount = item.get('rt_amount', 0)
            rt_total_amount = item.get('rt_total_amount', 0)
            
            try:
                rt_amount_str = str(int(round(float(rt_amount))))
                rt_total_amount_str = str(int(round(float(rt_total_amount))))
            except:
                rt_amount_str = '0'
                rt_total_amount_str = '0'
            
            logger.info(f"嘗試更新: PO={po_no}, 品名={description}, RT金額={rt_amount_str}, RT總金額={rt_total_amount_str}")
            
            if po_no:
                mask_po = buyer_df['PO No.'].astype(str).str.strip() == po_no

                if '品項' in buyer_df.columns:
                    mask_desc = buyer_df['品項'].astype(str).str.strip() == description
                    mask_both = mask_po & mask_desc
                else:
                    mask_desc = pd.Series([False] * len(buyer_df))
                    mask_both = mask_po  # fallback

                if mask_both.sum() > 0:
                    buyer_df.loc[mask_both, 'RT金額'] = rt_amount_str
                    buyer_df.loc[mask_both, 'RT總金額'] = rt_total_amount_str
                    updated_count += mask_both.sum()
                    logger.info(f"✓ 完整匹配 PO={po_no}, 品項={description} → 成功更新")
                elif mask_po.sum() > 0:
                    buyer_df.loc[mask_po, 'RT金額'] = rt_amount_str
                    buyer_df.loc[mask_po, 'RT總金額'] = rt_total_amount_str
                    updated_count += mask_po.sum()
                    logger.warning(f"⚠️ PO={po_no} 在 Buyer CSV 中有 {mask_po.sum()} 筆，但品項不同 (GridView: {description}, Buyer: {buyer_df.loc[mask_po, '品項'].unique().tolist()})，仍強制更新 RT 金額")
                else:
                    logger.warning(f"✗ 在 Buyer CSV 中找不到 PO {po_no}")
        
        # 儲存更新後的 CSV
        if updated_count > 0:
            try:
                buyer_df.to_csv(BUYER_CSV_PATH, index=False, encoding='utf-8-sig', na_rep='')
                logger.info(f"成功儲存更新後的 Buyer CSV，共更新 {updated_count} 筆資料")
                
                # 驗證更新是否成功
                verify_df = pd.read_csv(BUYER_CSV_PATH, encoding='utf-8-sig', dtype=str)
                logger.info(f"驗證: 更新後的 CSV 有 {len(verify_df)} 筆資料")
                
                # 檢查特定 PO 的更新結果
                for item in items_to_update[:3]:
                    po_no = str(item.get('po_no', '')).strip()
                    if po_no:
                        verify_rows = verify_df[verify_df['PO No.'].astype(str).str.strip() == po_no]
                        if len(verify_rows) > 0:
                            logger.info(f"驗證 PO {po_no}：共有 {len(verify_rows)} 筆資料")
                            for idx, row in verify_rows.iterrows():
                                logger.info(f"- 品項={row.get('品項', '')}, RT金額={row.get('RT金額', '')}, RT總金額={row.get('RT總金額', '')}")
                                
                return jsonify({
                    'success': True,
                    'message': f'成功更新 {int(updated_count)} 筆資料',
                    'updated_count': int(updated_count),
                    'total_items': int(len(items_to_update)),
                    'should_cleanup': True,  # 確保添加標記告訴前端需要清理
                    'cleanup_required': True  # 額外的清理標記
                })
                
            except Exception as e:
                logger.error(f"儲存 CSV 失敗: {str(e)}")
                return jsonify({
                    'success': False,
                    'error': f'儲存檔案失敗: {str(e)}'
                }), 500
        else:
            # 提供更詳細的錯誤資訊
            logger.warning("沒有任何資料被更新")
            
            # 統計各種情況
            empty_po_count = sum(1 for item in items_to_update if not str(item.get('po_no', '')).strip())
            valid_po_count = len(items_to_update) - empty_po_count
            
            error_details = {
                'total_items': len(items_to_update),
                'valid_po_count': valid_po_count,
                'empty_po_count': empty_po_count,
                'updated_count': 0
            }
            
            if empty_po_count > 0:
                error_message = f'共 {len(items_to_update)} 筆資料中有 {empty_po_count} 筆缺少 PO 號碼，{valid_po_count} 筆在 Buyer CSV 中找不到匹配項目'
            else:
                error_message = f'在 Buyer CSV 中找不到任何匹配的 PO 號碼 (共檢查 {len(items_to_update)} 筆)'
            
            return jsonify({
                'success': False,
                'message': error_message,
                'error': '後台查無此資料，請檢查 PO 號碼是否正確',
                'details': error_details,
                'updated_count': 0
            })
        
    except Exception as e:
        logger.error(f"更新 Buyer CSV 錯誤: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({'success': False, 'error': str(e)}), 500
    
    

@app.route('/api/health', methods=['GET'])
def health_check():
    """健康檢查端點"""
    return jsonify({
        'status': 'healthy',
        'server': 'Flask MHTML Parser',
        'version': '1.0.0',
        'timestamp': datetime.now().isoformat()
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)